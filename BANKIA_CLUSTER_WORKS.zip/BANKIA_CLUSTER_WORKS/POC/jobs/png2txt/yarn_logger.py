import os
import logging
import sys
import configparser

class YarnLogger:

    @staticmethod
    def setup_logger(self):

        file = '/spark/logs/PNG2TXT.log'
        logging.basicConfig(filename=file, level=logging.INFO,
                            format='%(asctime)s [%(levelname)s] %(module)s %(funcName)s - %(message)s')

    def __getattr__(self, key):
        return getattr(logging, key)

#YarnLogger.setup_logger()
