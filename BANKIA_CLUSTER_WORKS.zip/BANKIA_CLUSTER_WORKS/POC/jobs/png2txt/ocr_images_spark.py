from __future__ import print_function
import sys
from operator import add
from pyspark.sql import SparkSession
from pyspark import SparkContext
#from ocr_utils import image2hocr
#from ocr_utils import join_pages
import ocr_utils
import uuid
import os
import re
import json
import numpy as np
#from pyspark.sql.types import StructType
#from pyspark.sql.types import StructField
#from pyspark.sql.types import StringType
import configparser
import yarn_logger
import time
import subprocess



def get_filename(filename):
    return os.path.basename(filename)

def get_raw_filename(filename):
    return "_".join(get_filename(filename).split("_")[:-1])
    
def check_file(filename):
    
    checkFile = subprocess.Popen(['hadoop', 'fs', '-test', '-e', filename])
    checkFile.wait()
    if checkFile.returncode:
        #print (filename+' not exist')
        logger.error(filename+' not exist')
        return False
    return True

def move_in_hdfs(input_filename, output_filename):
    
    out_dir = "/".join(output_filename.split("/")[:-1])
    mkdir = subprocess.Popen(["hdfs", "dfs", "-mkdir", "-p", out_dir])
    mkdir.wait()

    rename = subprocess.Popen(["hdfs", "dfs", "-mv",input_filename, output_filename])
    rename.wait()
    
    delete = subprocess.Popen(["hdfs", "dfs", "-rm",input_filename])
    delete.wait()

    if not check_file(output_filename):
        return False
    return True

def extract_origin_path(image_path):
    
    import yarn_logger
    import time
    logger = yarn_logger.YarnLogger()
    logger.setup_logger(logger)
    start_time = time.time()
    
    logger.info("extract_origin_path BEGIN : "+image_path)
    
    t = re.match("(.*)\_\d+\.png$", image_path)
    
    logger.info ("BEGIN extract_origin_path :: IMAGE PATH : "+t.group(1)+" "+image_path)
    #log.info("EXTRACT "+t.group(1)+"")
    
    if(t):
        group = t.group(1)
        txt = group.rsplit('/', 1)[-1]
        pdf_input = config.get('general', 'path-pdf-input')
        logger.info ("extract_origin_path :: FILE_IS____"+pdf_input+"/{}.pdf".format(txt))
        logger.info ("END extract_origin_path ")
        logger.info("extract_origin_path END : "+image_path+"---TIME %s seconds ---" % (time.time() - start_time)) 
        #log.info("FILE_IS____"+pdf_input+"/{}.pdf".format(txt))
        return pdf_input+"/{}.pdf".format(txt)
    else:
        raise Exception("<o>======================= Invalid image path: {}".format(image_path))

def extract_origin_path_raw(image_path):
    
    import yarn_logger
    import time
    logger = yarn_logger.YarnLogger()
    logger.setup_logger(logger)
    start_time = time.time()
    logger.info("extract_origin_path_raw BEGIN : "+image_path)
    
    
    t = re.match("(.*)\_\d+\.png$", image_path)
    
    logger.info ("extract_origin_path_raw:: IMAGE PATH : "+t.group(1)+" "+image_path)
    #log.info("EXTRACT RAW"+t.group(1)+"")
    
    if(t):
        group = t.group(1)
        txt = group.rsplit('/', 1)[-1]
        logger.info("extract_origin_path END : "+image_path+"---TIME %s seconds ---" % (time.time() - start_time)) 
        return txt
    else:
        raise Exception("<o>======================= Invalid image path: {}".format(image_path))

def generate_out_json(in_rdd):
    pdf_name = in_rdd[0]
    
    import yarn_logger
    import time
    logger = yarn_logger.YarnLogger()
    logger.setup_logger(logger)
    start_time = time.time()
    
    logger.info("generate_out_json BEGIN : ")
    logger.info("generate_out_json <o>======================= pdf name: {}".format(pdf_name))
   
    pages = []
    for content in in_rdd[1]:
        image_processed = content[0]
        out_hocr = content[1][1]
        t = re.match(".*\_(\d+)\.png$",image_processed)
        if t:
            page_number = t.group(1)
        else:
            page_number = "unknown"
        
        #filename = extract_origin_path_raw(image_processed)   
        #print("<o>======================= image processed: {}".format(image_processed))
        logger.info("generate_out_json<o>======================= image processed: {}".format(image_processed))
        #print("<o>======================= page number: {}".format(page_number))
        logger.info("generate_out_json<o>======================= page number: {}".format(page_number))
        #print("<o>======================= hocr output: {}".format(out_hocr))
        logger.info("generate_out_json<o>======================= hocr output: {}".format(out_hocr))
        pages.append({"num": page_number, "image": image_processed, "hocr": out_hocr})
    
    
    logger.info("generate_out_json END : ---TIME %s seconds ---" % (time.time() - start_time)) 
    return {"pdf": pdf_name, "pages": pages}

def generate_text_tsv(in_rdd):
    pdf_name = in_rdd[0]
    
    import yarn_logger
    import time
    logger = yarn_logger.YarnLogger()
    logger.setup_logger(logger)
    start_time = time.time()
    logger.info("generate_text_tsv BEGIN : ")
    logger.info("generate_text_tsv<o>======================= pdf name: {}".format(pdf_name))
    
    #log.info("<o>======================= pdf name: {}".format(pdf_name))
    max_page = 0
    min_page = 1
    ocr_document_text = ""
    for num_page, content in enumerate(in_rdd[1]):
        ocr_text = content[1][0]
        image_processed = content[0]
        out_hocr = content[1][1]
        t = re.match(".*\_(\d+)\.png$",image_processed)
        if t:
            page_number = t.group(1)
            max_page = max(max_page, int(page_number))
            min_page = min(min_page, int(page_number))
        else:
            page_number = "unknown"
        #ocr_document_text += "<<<<<<< {} >>>>>>>> \n {}".format(page_number, ocr_text)
        filename = extract_origin_path_raw(image_processed)   
        ocr_document_text += "<<<<<<< {} >>>>>>>> {}".format(page_number, ocr_text.replace("\n", " "))
    out_img_dir = "/".join(image_processed.split("/")[:-1])
    out_hocr_dir = "/".join(out_hocr.split("/")[:-1])
    
    logger.info("generate_text_tsv END : ---TIME %s seconds ---" % (time.time() - start_time)) 
    return("{} \t {} \t {} \t {}-{} \t {} \t {}-{}\n".format(pdf_name, ocr_document_text, 
                                out_hocr_dir+"/"+filename, min_page, max_page,
                                out_img_dir+"/"+filename, min_page, max_page))
    

def main():
    
    start_time = time.time()
    #uuid_key = str(uuid.uuid4())
    
    images_input = config.get('general', 'path-images-input')
    images = sparkSession.sparkContext.binaryFiles(images_input)
    
    #print (images_input)
    #print(images.map(lambda x:x[0]).collect())
    result = images.map(lambda x : (x[0], ocr_utils.image2hocr((x[0],x[1]),config)))
    logger.info("AFTER IMAGE2HOCR:::::::::::::::::::::::::::::::::::::::::::::::::::")
    pair_name_hocr = result.map(lambda x: (extract_origin_path(x[0]), x)).cache()
    logger.info("AFTER EXTRACT ORIGIN PATH:::::::::::::::::::::::::::::::::::::::::::::::::::")
    #pair_name_hocr = result.map(lambda x: (extract_origin_path(x[0]), x))
    json = pair_name_hocr.groupByKey().map(lambda x: generate_out_json(x)).cache()
    logger.info("AFTER GENERATE OUT JSON:::::::::::::::::::::::::::::::::::::::::::::::::::")
    tsv = pair_name_hocr.groupByKey().map(lambda x: generate_text_tsv(x)).cache()
    logger.info("AFTER GENERATE TXT TSV:::::::::::::::::::::::::::::::::::::::::::::::::::")

    #schema = StructType([StructField(str(i), StringType(), True) for i in range(6)])
    #df = sparkSession.createDataFrame(tsv, schema)
    test = tsv.isEmpty()
    if test:
            logger.info("-------------------END PNG2TXT EXECUTION PART RDD IS EMPTY------KEY: "+uuid_key+"-------------------TIME %s seconds ---" % (time.time() - start_time))
    else:
        df = tsv.map(lambda x: x.split('\t')).toDF(["PdfPath", "Ocr", "HocrPath", "HocrPages", "ImagesPath", "ImagesPages"])
        logger.info("AFTER MAPPING CSV:::::::::::::::::::::::::::::::::::::::::::::::::::")

        df.write.csv(config.get('general', 'path-ocr-output')+str(uuid.uuid4()),sep='\t')
        #df.write.csv(config.get('general', 'path-ocr-output')+str(uuid.uuid4()),sep='\t')

        logger.info("AFTER WRITING CSV::::::::::::::::::::::::::::::::::::::::::::::::::"+" --- KEY: "+uuid_key+"-------------------TIME %s seconds ---" % (time.time() - start_time))

        ### HDFS
        path_images_output = config.get('general', 'path-images-output')
        logger.info("<o>=============== MOVING IMAGES PROCESSED FROM "+images_input+" TO : "+path_images_output+"")
        #print("<o>=============== MOVING IMAGES PROCESSED FROM "+images_input+" TO : "+path_images_output+"")
        move_in_hdfs(images_input+"/*",path_images_output)
        #print("<o>=============== IMAGES MODED : TO "+path_images_output+"")
        logger.info("<o>=============== IMAGES MOVED : TO "+path_images_output+" --- KEY: "+uuid_key+"-------------------TIME %s seconds ---" % (time.time() - start_time))
    
        logger.info("-------------------END PNG2TXT EXECUTION -> PART 1/3------KEY: "+uuid_key+"-------------------TIME %s seconds ---" % (time.time() - start_time))

        ## Save to a txt
        #print("<o>PROCESS SECOND PART, TXT IMAGES JOIN IMAGES FROM "+config.get('general', 'path-txt-pages')+"")
        logger.info("<o>PROCESS SECOND PART, TXT IMAGES JOIN IMAGES FROM "+config.get('general', 'path-txt-pages')+"")
        txts = sparkSession.sparkContext.binaryFiles(config.get('general', 'path-txt-pages')) # Look for pages already processed
        txt_original_names=txts.map(lambda x: get_filename(x[0])).collect() # Get original names
        txt_names=txts.map(lambda x: get_raw_filename(x[0])).collect() # Gets the names of the txts without the number of page
        txt_uniques=np.unique(txt_names)#.tolist() # Get unique elements

        logger.info("-------------------PNG2TXT BEFORE JOING PAGES -> PART 2/3------KEY: "+uuid_key+"-------------------TIME %s seconds ---" % (time.time() - start_time))
    
        rdd_to_join = sparkSession.sparkContext.parallelize(txt_uniques) # Create a RDD to parallelize
        output= rdd_to_join.map(lambda x: ocr_utils.join_pages(x, # Name of the pdf without the extension
                                       txt_original_names, # List of txt (pages processed by ocr)
                                       config.get('general', 'path-txt-pages'), # Path of the txt's (pages processed by ocr)
                                       config.get('general', 'path-txt-complete'), # Path to store the final txt
                                       config.get('general', 'path-txt-complete'),config)).count() # Path to store the txt's (pages processed by ocr) already joined
        logger.info("-------------------END PNG2TXT EXECUTION OUTPUT "+str(output) )
        logger.info("-------------------END PNG2TXT EXECUTION -> PART 3/3------KEY: "+uuid_key+"-------------------TIME %s seconds ---" % (time.time() - start_time)+" ---- MASTER: "+the_master)
#################################
#################################

if len(sys.argv) > 1:
    env = sys.argv[1]
    print("<o>=============== sent parameters:env "+env+"")
else :
    print("<o>======================= Usage:  spark-submit ocr_images_spark.py  <env> (\"local\", \"dev\",...)", file=sys.stderr)
    exit(-1)

config = configparser.RawConfigParser()
config.read(env)

#master=config.get('general', 'spark-master')
#app_name=config.get('general', 'app_name')

#sparkSession = SparkSession.builder.master(master).appName(app_name).getOrCreate()
app_name=config.get('general', 'app_name')

#sparkSession = SparkSession.builder.master(master).appName(app_name).getOrCreate()
sparkSession = SparkSession.builder.appName(app_name).getOrCreate()
sparkSession.sparkContext._jsc.hadoopConfiguration().set("mapreduce.input.fileinputformat.input.dir.recursive","true")

#Logger = sparkSession.sparkContext._jvm.org.apache.log4j.Logger
#logger = Logger.getLogger("PNG2TXT") 

logger = yarn_logger.YarnLogger()
logger.setup_logger(logger)

iterator = sparkSession.sparkContext.getConf().getAll()

str1 = ''.join(str(e) for e in iterator)

#current_path = os.path.dirname(os.path.abspath(__file__))

#for file in os.listdir(current_path):
#    if file.endswith(".py"):
#        print(os.path.join(current_path, file))
#        sparkSession.sparkContext.addPyFile(os.path.join(current_path, file))

#    sc._jsc.hadoopConfiguration().set("mapreduce.input.fileinputformat.input.dir.recursive","true")
#    images = sc.binaryFiles(config.get('general', 'path-images-input'))
uuid_key = sparkSession.sparkContext.getConf().get("spark.app.id")
the_master = sparkSession.sparkContext.getConf().get("spark.master")
the_client = sparkSession.sparkContext.getConf().get("spark.submit.deployMode")

logger.info("-------------------BEGIN PNG2TXT EXECUTION------KEY: "+uuid_key+"-------------------MASTER: "+the_master)


logger.info("PNG2TXT: SPARK PARAMETERS : MASTER : "+the_master )
logger.info("PNG2TXT: SPARK PARAMETERS : DEPLOY_MODE : "+the_client )
logger.info("PNG2TXT: SPARK PARAMETERS : SPARK_ID : "+uuid_key )


logger.info("PNG2TXT: SPARK PARAMETERS : "+str1+"------KEY: "+uuid_key+"-------------------" )
    
if __name__ == "__main__":
    main()
