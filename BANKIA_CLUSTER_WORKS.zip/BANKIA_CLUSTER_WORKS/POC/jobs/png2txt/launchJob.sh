#!/bin/sh
# /spark/bin/spark-submit --num-executors 4 --executor-cores 4 ${JOBS_PATH}/png2txt/ocr_images_spark.py $1
echo /spark/bin/spark-submit ${SPARK_PARAMS} --py-files ${JOBS_PATH}/png2txt/yarn_logger.py,${JOBS_PATH}/png2txt/ocr_utils.py --files ${JOBS_PATH}/png2txt/$1 ${JOBS_PATH}/png2txt/ocr_images_spark.py ${JOBS_PATH}/png2txt/$1
/spark/bin/spark-submit ${SPARK_PARAMS} --py-files ${JOBS_PATH}/png2txt/yarn_logger.py,${JOBS_PATH}/png2txt/ocr_utils.py --files ${JOBS_PATH}/png2txt/$1 ${JOBS_PATH}/png2txt/ocr_images_spark.py ${JOBS_PATH}/png2txt/$1
