#!/bin/sh
echo /spark/bin/spark-submit --master yarn --deploy-mode cluster --num-executors 4 --executor-cores 1 --executor-memory 756m  --py-files ${JOBS_PATH}/png2txt/yarn_logger.py,${JOBS_PATH}/png2txt/ocr_utils.py --files ${JOBS_PATH}/png2txt/$1 ${JOBS_PATH}/png2txt/ocr_images_spark.py $1
/spark/bin/spark-submit --master yarn --deploy-mode cluster --num-executors 4 --executor-cores 1 --executor-memory 756m  --py-files ${JOBS_PATH}/png2txt/yarn_logger.py,${JOBS_PATH}/png2txt/ocr_utils.py --files ${JOBS_PATH}/png2txt/$1 ${JOBS_PATH}/png2txt/ocr_images_spark.py $1
