import pytesseract
import tempfile
import os
from PIL import Image
import re
import subprocess
from hdfs import InsecureClient


#os.environ["TESSDATA_PREFIX"] = "/usr/local/share/tessdata/"


def save_to_hdfs(in_filename, hdfs_filename):
    
    import yarn_logger
    import time
    logger = yarn_logger.YarnLogger()
    logger.setup_logger(logger)
    start_time = time.time()
    
    logger.info("save_to_hdfs BEGIN : "+in_filename+" "+hdfs_filename)
    
    out_dir = "/".join(hdfs_filename.split("/")[:-1])
    #print("<o>======================= creating {}".format(out_dir))
    logger.info("<o>======================= creating {}".format(out_dir))
    mkdir = subprocess.Popen(["hdfs", "dfs", "-mkdir", "-p", out_dir])
    mkdir.wait()
    #print("<o>======================= putting {} to {}".format(in_filename, out_dir))
    logger.info("<o>======================= putting {} to {}".format(in_filename, out_dir))
    put = subprocess.Popen(["hdfs", "dfs", "-put", in_filename, out_dir])
    put.wait()
    rm = subprocess.Popen(["hdfs", "dfs", "-rm", "{}/{}".format(out_dir,os.path.basename(hdfs_filename))])
    rm.wait()
    #print("<o>======================= renaming {} to {}".format("{}/{}".format(out_dir,os.path.basename(in_filename)), "{}/{}".format(out_dir,os.path.basename(hdfs_filename))))
    logger.info("<o>======================= renaming {} to {}".format("{}/{}".format(out_dir,os.path.basename(in_filename)), "{}/{}".format(out_dir,os.path.basename(hdfs_filename))))
    rename = subprocess.Popen(["hdfs", "dfs", "-mv", "{}/{}".format(out_dir,os.path.basename(in_filename)), "{}/{}".format(out_dir,os.path.basename(hdfs_filename))])
    rename.wait()
    
    logger.info("save_to_hdfs END : ---TIME %s seconds ---" % (time.time() - start_time)) 
    
def image2hocr(file_img_tuple, config, wrapper="pytesseract"):
    
    import yarn_logger
    import time
    logger = yarn_logger.YarnLogger()
    logger.setup_logger(logger)
    start_time = time.time()
    
    path_hocr_output= config.get('general', 'path-hocr-output')
    path_txt_pages=config.get('general', 'path-txt-pages')
    
    
    filename = file_img_tuple[0]
    img = file_img_tuple[1]

    #print("FILENAME :"+filename+"")
    logger.info("image2hocr BEGIN : ")

    splitted_path = filename.split("/")
    doc_id = splitted_path[-2]
    doc_name = os.path.basename(filename)

    #print("DOCNAME :"+doc_name.split(".")[0]+"")
    logger.info("image2hocr :: DOCNAME :"+doc_name.split(".")[0]+"")

    doc_name_raw = doc_name.split(".")[0];
    
    
    hocr_outfile = path_hocr_output+"/{}.hocr".format(doc_name_raw)
    txt_outfile = path_txt_pages+"{}.txt".format(".".join(doc_name.split(".")[:-1]))
    if wrapper == "pytesseract":
        with tempfile.NamedTemporaryFile(delete=True) as temp:
            #print("<o>======================= processing file {} extension {}".format(doc_id, doc_name))
            logger.info("<o>======================= processing file {} extension {}".format(doc_id, doc_name))
            temp.write(img)
            temp.flush()
            with tempfile.NamedTemporaryFile(delete=True) as temp_hocr:
                partial_time = time.time()
                hocr = pytesseract.pytesseract.run_tesseract(temp.name, temp_hocr.name, lang="spa", config="hocr", extension="box")
                logger.info("RUN TESSERACT RUN TIME : ---TIME %s seconds ---" % (time.time() - partial_time)) 
                if hocr:
                    save_to_hdfs(".".join([temp_hocr.name,"hocr"]), hocr_outfile)
                    partial_time = time.time()
                    ocr_text = pytesseract.image_to_string(Image.open(temp.name), lang='spa')
                    logger.info("RUN TESSERACT IMAGE TO STRING RUN TIME : ---TIME %s seconds ---" % (time.time() - partial_time)) 
                    with tempfile.NamedTemporaryFile(mode="w",delete=True, encoding='utf-8') as temp_txt:
                        #print("<o>======================= Writting OCR text to temp file.."+temp_txt.name)
                        logger.info("<o>======================= Writting OCR text to temp file.."+temp_txt.name)
                        temp_txt.write(ocr_text) ## Write OCR text to a txt
                        temp_txt.flush()
                        #print("<o>======================= Save to hdfs.."+temp_txt.name+" as "+txt_outfile)
                        logger.info("<o>======================= Save to hdfs.."+temp_txt.name+" as "+txt_outfile)
                        save_to_hdfs(temp_txt.name,txt_outfile)
                    with open(".".join([temp_hocr.name,"hocr"]), "r",encoding='utf-8') as f:
                        hocr_content = f.read()
                    os.remove(".".join([temp_hocr.name,"hocr"]))
                else:
                    raise Exception("<o>======================= Tesseract [pytesseract wrapper] cannot convert image to hocr")
        logger.info("image2hocr END : ---TIME %s seconds ---" % (time.time() - start_time)) 
        return (ocr_text, hocr_outfile,doc_name_raw)
                
def join_pages(txt_name,txt_list,path_ocr_output,path_destination_txt,path_destination_processed_txt,config):
   
    import yarn_logger
    import time
    logger = yarn_logger.YarnLogger()
    logger.setup_logger(logger)
    start_time = time.time()
    
    logger.info("join_pages BEGIN : ")
    logger.info("<o>======================= Joining files of {} document ...".format(txt_name))
    #log.info("<o>======================= Joining files of {} document ...".format(txt_name))
  
    files_to_join=[x for x in txt_list if x.startswith(txt_name)]
    files_to_join.sort()
    text_to_write=[]
    
    hdfs_file_path=path_destination_txt+txt_name+".txt"
    
    # Temp file and get txt from hdfs
    client_hdfs = InsecureClient('http://' + config.get('general', 'hdfs_ip') + ':' +config.get('general', 'hdfs_port'))
    
    with tempfile.NamedTemporaryFile(mode="w",delete=True, encoding='utf-8') as temp_txt:
        for file_txt in files_to_join:
            with client_hdfs.read(path_ocr_output+file_txt, encoding='utf-8') as reader:
                text_to_write.append(reader.read())
        
        temp_txt.write("\x0c".join(text_to_write))
        save_to_hdfs(temp_txt.name,hdfs_file_path)
    
    #print("<o>======================= {} document joined.".format(txt_name))
    logger.info("<o>======================= {} document joined.".format(txt_name))
    logger.info("join_pages END : ---TIME %s seconds ---" % (time.time() - start_time))
    return 1
    
    #for file_i in files_to_join:
    #    print("Moving {} file to {}".format(path_ocr_output+file_i,path_destination_processed_txt))
    #    move_to_hdfs(path_ocr_output+file_i,path_destination_processed_txt)
    

