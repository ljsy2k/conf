# -*- coding: utf-8 -*-
"""
PNG2TXT spark job
Ghostscript


DONE:
“Listens” /data/png and converts into txt at /data/txt and /data/hocr
Moves the converted png from /data/png to /data/png-processed


TODO:
Adds the text into the lawsuit document at ElasticSearch
Adds a functional log entry at ElasticSearch

@author: dlri
"""

### Libraries

import pytesseract
import tempfile
import os
from PIL import Image
import re
import subprocess
import numpy as np
import collections

import sys
from operator import add
from pyspark.sql import SparkSession
from pyspark import SparkContext
#from ocr_utils import image2hocr
import uuid
import os
import re
import json

import configparser

import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

import tools
import tools_elastic

from elasticsearch import Elasticsearch

os.environ["TESSDATA_PREFIX"] = "/usr/share/tesseract-ocr/4.00/tessdata/"

### Paths definitions

#path_input = "spark-warehouse/data/input-pdf/"
#path_output = "spark-warehouse/data/pdf/"
#path_png = "spark-warehouse/data/png/"

#path_input = "hdfs://data/input-pdf/"
#path_output = "hdfs://data/pdf/"
#path_png = "hdfs://data/png/"


### main function

def main():
    w = Watcher()
    w.run()
    
   
def join_pages(txt_name,txt_list,path_ocr_output,path_destination_txt,path_destination_processed_txt):
    print("Joining files of {} document ...".format(txt_name))
    
    # Elastic configuration
    ip=config.get('elastic', 'ip')
    port=config.get('elastic', 'port')
    index=config.get('elastic', 'index')
    doc_type=config.get('elastic', 'doc_type')

    es = Elasticsearch([{'host': ip, 'port': port}]) # Elastic connection

    files_to_join=[x for x in txt_list if x.startswith(txt_name)]
    files_to_join.sort()
    text_to_write=[]
    
    with open(file=path_destination_txt+txt_name+".txt", mode="w",encoding="utf8") as output:
        for file_txt in files_to_join:
            with open(file=path_ocr_output+file_txt,mode="r",encoding="utf8") as input_f:
                text_to_write.append(input_f.read())
        
        output.write("\x0c".join(text_to_write))
        
    tools_elastic.addDataDoc(es,index,doc_type,"pdf_filename",txt_name+".pdf","creation_datetimes.text",tools.getTime()) # Store the time of creation of the pdf
    tools_elastic.addDataDoc(es,index,doc_type,"pdf_filename",txt_name+".pdf","text","\x0c".join(text_to_write)) # Store the time of creation of the pdf
    
    print("{} document joined.".format(txt_name))
    
    for file_i in files_to_join:
        print("Moving {} file to {}".format(path_ocr_output+file_i,path_destination_processed_txt))
        tools.move_to_hdfs(path_ocr_output+file_i,path_destination_processed_txt)
    

### pdf2png function

def image2hocr(file_img_tuple, wrapper="pytesseract"):
    
    # Elastic configuration
    ip=config.get('elastic', 'ip')
    port=config.get('elastic', 'port')
    index=config.get('elastic', 'index')
    doc_type=config.get('elastic', 'doc_type')

    es = Elasticsearch([{'host': ip, 'port': port}]) # Elastic connection
    
    filename = file_img_tuple[0]
    img = file_img_tuple[1]
    print("LOOKING FOR: "+"_".join(".".join(os.path.basename(filename).split(".")[:-1]).split("_")[:-1])+".pdf")
    tools_elastic.addDataDoc(es,index,doc_type,
                             "pdf_filename",
                             "_".join(".".join(os.path.basename(filename).split(".")[:-1]).split("_")[:-1])+".pdf",
                             "txt_prefix",
                             "_".join(".".join(os.path.basename(filename).split(".")[:-1]).split("_")[:-1])) # Store the time of creation of the pdf
    
    splitted_path = filename.split("/")
    doc_id = splitted_path[-2]
    doc_name = os.path.basename(filename)
    hocr_outfile = config.get('general', 'path-hocr')+"{}.hocr".format(".".join(doc_name.split(".")[:-1]))
    txt_outfile = config.get('general', 'path-ocr-output')+"{}.txt".format(".".join(doc_name.split(".")[:-1]))
    if wrapper == "pytesseract":
        with tempfile.NamedTemporaryFile(delete=True) as temp:
            print("processing file {}".format(doc_name))
            temp.write(img)
            temp.flush()
            with tempfile.NamedTemporaryFile(delete=True) as temp_hocr:
                hocr = pytesseract.pytesseract.run_tesseract(temp.name, temp_hocr.name, lang="spa", config="hocr", extension="box")
                if hocr:
                    tools.save_to_hdfs(".".join([temp_hocr.name,"hocr"]), hocr_outfile)
                    ocr_text = pytesseract.image_to_string(Image.open(temp.name), lang='spa')
                    with tempfile.NamedTemporaryFile(mode="w",delete=True) as temp_txt:
                        print("Writting OCR text to temp file.."+temp_txt.name)
                        temp_txt.write(ocr_text) ## Write OCR text to a txt
                        temp_txt.flush()
                        print("Save to hdfs.."+temp_txt.name)
                        tools.save_to_hdfs(temp_txt.name,txt_outfile)
                    if (os.path.isfile(temp_txt.name)): # It seems that the file is deleted automatically, this is only to be sure that no temporal data is stored
                        os.remove(temp_txt.name)
                        
                    with open(".".join([temp_hocr.name,"hocr"]), "r") as f:
                        hocr_content = f.read()
                    os.remove(".".join([temp_hocr.name,"hocr"]))
                    
                else:
                    raise Exception("Tesseract [pytesseract wrapper] cannot convert image to hocr")
        
        #Move png to png_processed
        tools.move_to_hdfs(config.get('general', 'path-images-input')+doc_name,config.get('general', 'path-images-output'))
        return (ocr_text, hocr_outfile)


### Watchdog
    
class Watcher:
    env="local"
    config = configparser.RawConfigParser()
    config.read(env+'.config.properties')
    DIRECTORY_TO_WATCH = config.get('general', 'path-images-input')

    def __init__(self):
        self.observer = Observer()

    def run(self):
        event_handler = Handler()
        self.observer.schedule(event_handler, self.DIRECTORY_TO_WATCH, recursive=True)
        self.observer.start()
        try:
            while True:
                time.sleep(5)
        except:
            self.observer.stop()
            print("Error")

        self.observer.join()


class Handler(FileSystemEventHandler):

    @staticmethod
    def on_any_event(event):
        if event.is_directory:
            return None

        elif (event.event_type == 'created') or (event.event_type == 'modified'):
            time.sleep(0.5) 
            # Take any action here when a file is first created.
            print("Received created event - %s." % event.src_path)
            images = sparkSession.sparkContext.binaryFiles(config.get('general', 'path-images-input')) # Look for PNG images
            print("Mapping process for files in",config.get('general', 'path-images-input'))
            images.map(lambda x : (x[0], image2hocr((x[0],x[1])))).count() #Send to workers the png2txt job
            
            #### Join PDFS if all pages are processed
            txts = sparkSession.sparkContext.binaryFiles(config.get('general', 'path-ocr-output')) # Look for pages already processed
            txt_original_names=txts.map(lambda x: tools.get_filename(x[0])).collect() # Get original names
            txt_names=txts.map(lambda x: tools.get_raw_filename(x[0])).collect() # Gets the names of the txts without the number of page
            txt_uniques=np.unique(txt_names)#.tolist() # Get unique elements
            counter=collections.Counter(txt_names) # Count the number of pages already processed
            
            # Start an elasticsearch connection to get the total number of pages of the pdf
            ip=config.get('elastic', 'ip')
            port=config.get('elastic', 'port')
            index=config.get('elastic', 'index')
            doc_type=config.get('elastic', 'doc_type')

            es=Elasticsearch([{'host': ip, 'port': port}])
            
            # Check how many pdfs are already translated to txt completely
            already_processed=np.where([True if counter.get(x)==int(tools_elastic.getKeyFromDoc(es,index,"pdf_filename",x+".pdf","pdf_num_pages")) else False for x in txt_uniques])[0]
            
            if len(already_processed)>0: # If there are pdfs with all pages in txt, execute the txt2doc job
                rdd_to_join = sparkSession.sparkContext.parallelize(txt_uniques[already_processed]) # Create a RDD to parallelize
                rdd_to_join.map(lambda x: join_pages(x, # Name of the pdf without the extension
                                                           txt_original_names, # List of txt (pages processed by ocr)
                                                           config.get('general', 'path-ocr-output'), # Path of the txt's (pages processed by ocr)
                                                           config.get('general', 'path-txt-output'), # Path to store the final txt
                                                           config.get('general', 'path-txt-processed'))).count() # Path to store the txt's (pages processed by ocr) already joined
            else:
                print("No files to join")
            
            
########################################################################
env="local"
config = configparser.RawConfigParser()
config.read(env+'.config.properties')
sparkSession = SparkSession.builder.master(config.get('general', 'spark-master')).appName("png2txt-job").getOrCreate()
sparkSession.sparkContext._jsc.hadoopConfiguration().set("mapreduce.input.fileinputformat.input.dir.recursive","true")


if __name__ == "__main__":
    main()
