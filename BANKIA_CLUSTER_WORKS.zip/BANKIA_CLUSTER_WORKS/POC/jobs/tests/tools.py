import subprocess
import os

from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfinterp import resolve1

import csv

import datetime
import time

import elasticsearch

def getTime():
 return datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3]+'{}{:0>2}:{:0>2}'.format('-' if time.altzone > 0 else '+', abs(time.altzone) // 3600, abs(time.altzone // 60) % 60)

def get_filename(filename):
    return(os.path.basename(filename))

def get_raw_filename(filename):
    return "_".join(get_filename(filename).split("_")[:-1])

def save_to_hdfs(in_filename, hdfs_filename):
    out_dir = "/".join(hdfs_filename.split("/")[:-1])
    print("creating {}".format(out_dir))
    #mkdir = subprocess.Popen(["hdfs", "dfs", "-mkdir", "-p", out_dir])
    #mkdir.wait()
    mkdir = subprocess.Popen(["mkdir", "-p", out_dir])
    mkdir.wait()
    print("putting {} to {}".format(in_filename, out_dir))
    #put = subprocess.Popen(["hdfs", "dfs", "-put", in_filename, out_dir])
    #put.wait()
    #rm = subprocess.Popen(["hdfs", "dfs", "-rm", "{}/{}".format(out_dir,os.path.basename(hdfs_filename))])
    #rm.wait()
    put = subprocess.Popen(["cp", in_filename, out_dir])
    print("renaming {} to {}".format("{}/{}".format(out_dir,os.path.basename(in_filename)), "{}/{}".format(out_dir,os.path.basename(hdfs_filename))))
    put.wait()
    #rename = subprocess.Popen(["hdfs", "dfs", "-mv", "{}/{}".format(out_dir,os.path.basename(in_filename)), "{}/{}".format(out_dir,os.path.basename(hdfs_filename))])
    #rename.wait()
    rename = subprocess.Popen(["mv", "{}/{}".format(out_dir,os.path.basename(in_filename)), "{}/{}".format(out_dir,os.path.basename(hdfs_filename))])
    rename.wait()

def move_to_hdfs(in_filename, hdfs_filename):
    #out_dir = "/".join(hdfs_filename.split("/")[:-1])
    #rename = subprocess.Popen(["hdfs", "dfs", "-mv", "{}/{}".format(out_dir,os.path.basename(in_filename)), "{}/{}".format(out_dir,os.path.basename(hdfs_filename))])
    #rename.wait()
    rename = subprocess.Popen(["mv", in_filename, hdfs_filename])
    rename.wait()

def get_numpages_pdf(csv_path,file_name):
    csv_file = csv.reader(open(csv_path, "r"), delimiter=",")
    for row in csv_file:
    #if current rows 2nd value is equal to input, print that row
        if file_name == row[0]:
            return(int(row[1]))

def PDFminer_get_numpages_pdf(file_name):
    file = open(file_name, 'rb')
    parser = PDFParser(file)
    document = PDFDocument(parser)
    return resolve1(document.catalog['Pages'])['Count']

def store_numpages_pdf(csv_path,file_path):
    file = open(file_path, 'rb')
    parser = PDFParser(file)
    document = PDFDocument(parser)

    if os.path.isfile(csv_path):
        with open(csv_path, 'a') as f:
            writer = csv.writer(f)
            writer.writerow([file_path,resolve1(document.catalog['Pages'])['Count']])
    else:
        with open(csv_path, 'w') as f:
            writer = csv.writer(f)
            writer.writerow(["file","num_pages"])
            writer.writerow([file_path,resolve1(document.catalog['Pages'])['Count']])
