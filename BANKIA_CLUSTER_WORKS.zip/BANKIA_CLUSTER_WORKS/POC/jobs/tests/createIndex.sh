IP=elasticsearch
port=9200
curl -X POST "$IP:$port/bankia_lawsuit_test/lawsuit" -H 'Content-Type: application/json' -d'
{
  "pdf_filename": "test.pdf",
  "png_prefix": "test",
  "txt_prefix": "test",
  "text": "lorem ipsum dolor amet lorem ipsum dolor amet lorem ipsum dolor amet",
  "txt_filename": "test.txt",
  "pdf_num_pages": 2,
  "lawsuit_clasifications": "test",
  "lawsuit_entities": {
    "entity_type": "nombre",
    "entity_value": "juan perez"
  },
  "creation_datetimes": {
    "pdf": "2018-12-31T23:59:59.999+01:00",
    "png": "2018-12-31T23:59:59.999+01:00",
    "text": "2018-12-31T23:59:59.999+01:00",
    "lawsuit_clasifications": "2018-12-31T23:59:59.999+01:00",          
    "lawsuit_entities": "2018-12-31T23:59:59.999+01:00"
  }
}
'
