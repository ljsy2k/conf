# -*- coding: utf-8 -*-
"""
PDF2PNG spark job
Ghostscript


DONE:
“Listens” /data/input-pdf and converts into PNG at /data/png
Moves the converted PDF from /data/input-pdf to /data/pdf


TODO:
Creates a lawsuit document at ElasticSearch
Adds a functional log entry at ElasticSearch

@author: dlri
"""

### Libraries

import pyspark
from pyspark import SparkContext
from pyspark.sql import SparkSession

import sys
import locale
import ghostscript
import subprocess

import os

import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

import configparser

from elasticsearch import Elasticsearch
import tools
import tools_elastic

### Paths definitions

#path_input = "spark-warehouse/data/input-pdf/"
#path_output = "spark-warehouse/data/pdf/"
#path_png = "spark-warehouse/data/png/"

#path_input = "hdfs://data/input-pdf/"
#path_output = "hdfs://data/pdf/"
#path_png = "hdfs://data/png/"


### main function

def main():
    w = Watcher()
    w.run()


### pdf2png function

def pdf2png(file_path):
    # Elastic configuration
    ip=config.get('elastic', 'ip')
    port=config.get('elastic', 'port')
    index=config.get('elastic', 'index')
    doc_type=config.get('elastic', 'doc_type')

    es = Elasticsearch([{'host': ip, 'port': port}]) # Elastic connection

    print("PDF2PNG for file: "+file_path)
    file_path=config.get('general', 'path-pdf-input')+os.path.basename(file_path)
    print("#####################"+os.path.basename(file_path)+"########################")
    tools_elastic.createDoc(es,index,doc_type,"pdf_filename",os.path.basename(file_path)) # Store the PDF name on elastic search
    tools_elastic.addDataDoc(es,index,doc_type,"pdf_filename",os.path.basename(file_path),"creation_datetimes.pdf",tools.getTime()) # Store the time of creation of the pdf
    tools_elastic.addDataDoc(es,index,doc_type,"pdf_filename",os.path.basename(file_path),"pdf_num_pages",tools.PDFminer_get_numpages_pdf(file_path)) # Store the number of pages
    tools.store_numpages_pdf(csv_path,file_path)



    args = ["pdf2png",
        "-sDEVICE=pnggray",
        "-r300", # Resolution
        "-dNOPAUSE", # Don't ask to continue
        "-dQUIET", # Don't print in cmd the information
        "-sProcessColorModel=DeviceGray", # Gray color
        "-sColorConversionStrategy=Gray", # Gray color
        "-dOverrideICC",
        "-sOutputFile=" + config.get('general', 'path-images-input')+".".join(os.path.basename(file_path).split(".")[:-1])+"_%04d.png","-f",  file_path] # File names

#    args = ["pdf2jpg",
#        "-sDEVICE=pnggray",
#        "-dNOPAUSE",
#            "-dBATCH","-dQUIET","-dSAFER","-dGraphicsAlphaBits=4","-dAlignToPixels=0","-dPDFFitPage",
#        "-sProcessColorModel=DeviceGray",
#        "-sColorConversionStrategy=Gray",
#        "-dOverrideICC -r300","-dNOGC",
#        "-sOutputFile=" + path_png+file_path.split("/")[-1][:-4]+"_%03d.png","-f",  file_path]


    # arguments have to be bytes, encode them
    encoding = locale.getpreferredencoding()
    args = [a.encode(encoding) for a in args]

    try:
        ghostscript.Ghostscript(*args) # Execute the ghostscript process
    except:
        if(file_path.lower().endswith(".pdf")):
            print("Unexpected error in file: "+file_path)
        else:
            print("Not a PDF file: "+file_path)

    tools_elastic.addDataDoc(es,index,doc_type,"pdf_filename",os.path.basename(file_path),"creation_datetimes.png",tools.getTime()) # Store the time of creation of the pdf
    tools_elastic.addDataDoc(es,index,doc_type,"pdf_filename",os.path.basename(file_path),"png_prefix",".".join(os.path.basename(file_path).split(".")[:-1])) # Store the number of pages

    tools.move_to_hdfs(config.get('general', 'path-pdf-input')+os.path.basename(file_path),
                       config.get('general', 'path-pdf-output')+os.path.basename(file_path))
    return 1


### Watchdog

class Watcher:
    env="local"
    config = configparser.RawConfigParser()
    config.read(env+'.config.properties')
    DIRECTORY_TO_WATCH = config.get('general', 'path-pdf-input')

    def __init__(self):
        self.observer = Observer()

    def run(self):
        event_handler = Handler()
        self.observer.schedule(event_handler, self.DIRECTORY_TO_WATCH, recursive=True)
        self.observer.start()
        try:
            while True:
                time.sleep(5)
        except:
            self.observer.stop()
            print("Error")

        self.observer.join()


class Handler(FileSystemEventHandler):

    @staticmethod
    def on_any_event(event):
        if event.is_directory:
            return None

        elif (event.event_type == 'created') or (event.event_type == 'modified'):
            time.sleep(0.5)
            # Take any action here when a file is first created.
            print("Received created event - %s." % event.src_path)
            pdfs = sparkSession.sparkContext.binaryFiles(config.get('general', 'path-pdf-input'))
            print("Mapping process for files in",config.get('general', 'path-pdf-input'))
            pdfs.map(lambda x : (x[0], pdf2png((x[0])))).count()
            #files_to_png=pdfs.map(lambda x : (x[0])).foreachPartition(pdf2png)
            #for file_p in files_to_png:
            #    pdf2png(file_p)


########################################################################
csv_path = "pdf_pages.csv"
env="local"
config = configparser.RawConfigParser()
config.read(env+'.config.properties')
sparkSession = SparkSession.builder.master(config.get('general', 'spark-master')).appName("pdf2png-job").getOrCreate()
sparkSession.sparkContext._jsc.hadoopConfiguration().set("mapreduce.input.fileinputformat.input.dir.recursive","true")

if __name__ == "__main__":
    main()
