apt update
apt install -y vim ghostscript tesseract-ocr tesseract-ocr-spa python-pip python-dev libjpeg-dev libfreetype6-dev zlib1g-dev libtiff5-dev zlib1g-dev liblcms2-dev libwebp-dev tcl8.6-dev tk8.6-dev python-tk  python3-dev python3-setuptools python-pil python-imaging
easy_install-3.4 pip
pip install python3-ghostscript ghostscript watchdog elasticsearch tools pdfminer.six Pillow numpy pytesseract configparser