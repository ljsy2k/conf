from elasticsearch import Elasticsearch

def getKeyFromDoc(es,index,key_search,value_search,key_get):
    print("Getting info from: "+value_search)
    if not checkDocExistence(es,index,key_search,value_search):
        print("Document do not exist")
        return None
    
    body={"query": {"match": {}}}
    body["query"]["match"]={key_search:value_search}
    try:
        value_get=es.search(index=index, body=body)["hits"]["hits"][0]["_source"][key_get]
        return value_get
    except:
        print("Key not found")
        return None
    
def getAllFromDoc(es,index,key_search,value_search):
    if not checkDocExistence(es,index,key_search,value_search):
        print("Document do not exist")
        return None
    
    body={"query": {"match": {}}}
    body["query"]["match"]={key_search:value_search}
    try:
        value_get=es.search(index=index, body=body)["hits"]["hits"][0]
        return value_get
    except:
        print("Error")
        return None
    
def checkDocExistence(es,index,key,value):
    body={"query": {"match": {}}}
    body["query"]["match"]={key:value}
    total=es.search(index=index, body=body)["hits"]["total"]
    if total > 0:
        return True
    return False

def createDoc(es,index,doc_type,key,value):
    if checkDocExistence(es,index,key,value):
        print("Document already exists")
        return None
    
    doc = {key:value}
    res = es.index(index=index, doc_type=doc_type, body=doc)
    if res['result'] == "created":
        print("Document added to ES successfully")
    else:
        print("ERROR: " + res['result'])
        
def getIdDoc(es,index,key_search,value_search):
    body={"query": {"match": {}}}
    body["query"]["match"]={key_search:value_search}
    try:
        value_get=es.search(index=index, body=body)["hits"]["hits"][0]["_id"]
        return value_get
    except:
        print("Document or key not found")
        return None
    
def addDataDoc(es,index,doc_type,key_search,value_search,key_add,value_add):
    if not checkDocExistence(es,index,key_search,value_search):
        print("Document does not exist!")
        return None
    
    
    _id = getIdDoc(es,index,key_search,value_search)
    
    if len(key_add.split(".")) > 1:
        doc = '{"doc": '
        for key_aux in key_add.split("."):
            doc = doc + '{"'+key_aux+'":'
        doc = doc+'"'+value_add+'"'+"}"*(len(key_add.split("."))+1)
        doc = eval(doc)
    else:
        doc = {"doc": {key_add:value_add}}
    
    res=es.update(index=index,doc_type=doc_type, id = _id, body=doc,refresh='true')

    if res['result'] == "updated":
        print("Value added to document in ES successfully")
    elif res['result'] == "noop":
        print("Value to update is equal to value currently stored. Nothing to update.")
    else:
        print("ERROR: " + res['result'])
