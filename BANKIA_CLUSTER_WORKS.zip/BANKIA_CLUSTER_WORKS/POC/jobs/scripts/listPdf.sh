hdfs dfs -ls -R hdfs://namenode:8020/${NFS_PATH}/data-input/pdf
