hdfs dfs -ls hdfs://namenode:8020/${NFS_PATH}/data-output/png
