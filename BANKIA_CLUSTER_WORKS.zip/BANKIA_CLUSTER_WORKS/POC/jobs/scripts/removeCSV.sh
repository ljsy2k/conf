hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-output/csv/*
