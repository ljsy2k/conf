hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-input/pngs/*
hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-input/pngs/*
hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-output/texts/*
hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-output/classification/*
hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-input/pdfs/*
hdfs dfs -rm -R hdfs://namenode:8020/data/input-pdf/*
hdfs dfs -rm -R hdfs://namenode:8020/data/pdf/*
hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-output/txt-pages/*
hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-output/txt-complete/*
hdfs dfs -rm -R hdfs://namenode:8020/${NFS_PATH}/data-output/hocr/pngs/*



