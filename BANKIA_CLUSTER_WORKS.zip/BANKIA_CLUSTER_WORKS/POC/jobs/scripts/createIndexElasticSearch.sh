IP=elasticsearch
port=9200
echo '---'
echo '--- Disabling the disk allocation threshold'
echo '--- Remove this on production'
curl -XPUT $IP:$port/_cluster/settings -H 'Content-Type: application/json' -d '{"transient" : {"cluster.routing.allocation.disk.threshold_enabled" : false}}' 
echo '--- Second step'
#curl -XPUT -H "Content-Type: application/json" $IP:$port/_all/_settings -d '{"index.blocks.read_only_allow_delete": false}'

echo '---'
echo '--- Creating mappings templates'
echo '---'
echo '* Lawsuit mapping'
curl -XPUT "$IP:$port/_template/bankia_lawsuit" -H 'Content-Type: application/json' -d'
{
  "template": "bankia_lawsuit*",
  "order" : 0,
  "settings": {
    "number_of_shards": 1
  },
  "mappings": {
    "lawsuit": {
      "_source": { "enabled": true },
      "_all": { "enabled": false },
      "dynamic": "strict",
      "properties": {
        "pdf_filename": { "type": "keyword" },
        "png_prefix": { "type": "keyword" },
        "txt_prefix": { "type": "keyword" },
        "txt_filename": { "type": "keyword" },
        "text": { "type": "text" },
        "pdf_num_pages": {"type": "integer" },
        "lawsuit_clasifications": { "type": "keyword" },
        "lawsuit_entities": {
          "type": "object", 
          "properties": {
            "entity_type": { "type": "keyword" },
            "entity_value": { "type": "text" }
          }
        },
        "creation_datetimes": {
          "type": "object", 
          "properties": {
            "pdf": { "type": "date", "format": "date_time" },
            "png": { "type": "date", "format": "date_time" },
            "text": { "type": "date", "format": "date_time" },
            "lawsuit_clasifications": { "type": "date", "format": "date_time" },          
            "lawsuit_entities": { "type": "date", "format": "date_time" }
          }
        }
      }
    }
  }
}
'
echo ''
echo '* Functional log mapping'
curl -X POST "$IP:$port/_template/bankia_functional_log" -H 'Content-Type: application/json' -d'
{
  "template": "bankia_functional_log*",
  "order" : 1,
  "settings": {
    "number_of_shards": 1
  },
  "mappings": {
    "logs": {
      "_source": { "enabled": true },
      "_all": { "enabled": false },
      "dynamic": "strict",
      "properties": {
        "action": { "type": "keyword" },
        "subject": { "type": "keyword" },
        "status": { "type": "keyword" },
        "more_info": { "type": "text" },
        "date_time": { "type": "date", "format": "date_time" }
      }
    }
  }
}
'
echo ''
echo '---'
echo '--- Finish OK'
echo '---'
