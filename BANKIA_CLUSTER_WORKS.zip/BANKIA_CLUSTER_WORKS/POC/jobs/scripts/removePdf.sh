hdfs dfs -rm -R hdfs://namenode:8020/data/input-pdf/*
