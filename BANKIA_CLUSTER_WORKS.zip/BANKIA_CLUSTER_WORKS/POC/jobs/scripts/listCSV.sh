hdfs dfs -ls -R hdfs://namenode:8020/${NFS_PATH}/data-output/txt-complete/
