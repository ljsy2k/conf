INPUT=${INPUT_EXTERNAL_PDF_PATH}/*.pdf
OUTPUT=${NFS_PATH}/data-input/pdf
HDFS=${CORE_CONF_fs_defaultFS}
hdfs dfs -copyFromLocal -f $INPUT $HDFS$OUTPUT