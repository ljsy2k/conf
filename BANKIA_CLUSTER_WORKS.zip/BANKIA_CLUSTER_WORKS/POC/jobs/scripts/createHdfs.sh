hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-input/pdf
hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-output/png
hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-output/pdf
hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-output/png_processed

hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-output/hocr
hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-output/csv
hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-output/txt-pages
hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-output/txt-complete
hdfs dfs -mkdir -p hdfs://namenode:8020/${NFS_PATH}/data-output/classification

mkdir -p ${NFS_PATH}/data-input/pdf
mkdir -p ${NFS_PATH}/data-output/png
mkdir -p ${NFS_PATH}/data-output/png_processed
mkdir -p ${NFS_PATH}/data-output/pdf

mkdir -p ${NFS_PATH}/data-output/hocr
mkdir -p ${NFS_PATH}/data-output/csv
mkdir -p ${NFS_PATH}/data-output/txt-pages/
mkdir -p ${NFS_PATH}/data-output/txt-complete/
mkdir -p ${NFS_PATH}/data-output/classification/

mkdir -p ${NFS_PATH}/POC/input/
mkdir -p ${NFS_PATH}/logs