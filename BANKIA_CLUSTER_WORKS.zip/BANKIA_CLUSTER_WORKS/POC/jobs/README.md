# RUNNING JOBS in AIDOC Hadoop - Spark Swarm Cluster


NOTE:
 - for running JOBS we need to install Cluster and Run it (Explained in README.md)

## Locating Jobs

Jobs are located in ``https://git.gft.com/exponential-banking/cognitive-banking/bankia_lawsuits_pipeline_jobs`` and according to ``setenv.sh`` we was copied to 

- JOBS_PATH : where we will place the FOLDER "bankia_lawsuits_pipeline_jobs"

```
[root@aidoc-05 jobs]# ls -l
total 20
drwxrwxrwx 6 lest lest 4096 Aug 21 12:24 classification
drwxrwxrwx 4 lest lest 4096 Aug 16 17:42 pdf2png
drwxrwxrwx 3 lest lest 4096 Aug 20 14:48 png2txt
drwxrwxrwx 2 lest lest 4096 Aug 21 12:28 scripts
drwxrwxrwx 2 lest lest 4096 Aug 16 13:16 tests
```

The runtime configuration is located in ``scripts/Makefile`` that is invoked from Master ``Makefile`` (for instance)

if we open the content:

```
[root@aidoc-05 scripts]# more Makefile
hdfs:
        docker run --name create-hdfs --rm -it ${DOCKER_RUN_ENV} aidoc/spark-base:latest ${JOBS_PATH}/scripts/createHdfs.sh

remove-hdfs:
        docker run --name remove-hdfs-content --rm -it ${DOCKER_RUN_ENV} aidoc/spark-base:latest ${JOBS_PATH}/scripts/removeALL.sh

bash:
        docker run --name aidoc-bash-shell-2 --rm -it ${DOCKER_RUN_ENV} aidoc/spark-base:latest bash

upload:
        docker run --name upload --rm -it ${DOCKER_RUN_ENV} aidoc/spark-base:latest ${JOBS_PATH}/scripts/uploadPDF.sh

download:
        docker run --name download --rm -it ${DOCKER_RUN_ENV} aidoc/spark-base:latest ${JOBS_PATH}/scripts/downloadCSV.sh

pdf2png:
        docker run --name pdf2png --rm -it -p 4043:4040 ${DOCKER_RUN_ENV} aidoc/spark-base:latest ${JOBS_PATH}/pdf2png/launchJob.sh ${JOBS_PATH}/pdf2png/spark.config.properties

png2txt:
        docker run --name png2txt --rm -it -p 4041:4040 ${DOCKER_RUN_ENV} aidoc/spark-base:latest ${JOBS_PATH}/png2txt/launchJob.sh ${JOBS_PATH}/png2txt/spark.config.properties

classification:
        docker run --name classification --rm -it -p 4042:4040 ${DOCKER_RUN_ENV} aidoc/spark-base:latest ${JOBS_PATH}/classification/launchJob.sh ${JOBS_PATH}/classification/spark.config.properties

```

We have some UTIL JOBS (that create a docker container and execute a Script as an Argument: ``${JOBS_PATH}/scripts/createHdfs.sh`` for instance)

- hdfs : create HDFS internal Paths for I/O between JOBS
- remove-hdfs: remove contents of HDFS Paths
- bash: create a container and a BASH Session (we can operate the CLUSTER in IT)
- upload: upload PDF files from a location to the INPUT PDF PATH that is needed by PDF2PNG job
- download: download CSV files from the HDFS location

And the PIPELINE JOBS

- pdf2png: executes PDF2PNG JOB with the execution properties as a parameter (PYTHON)
- png2txt: executes PNG2TXT JOB with the execution properties as a parameter (PYTHON)
- classification: executes CLASSIFICATION JOB with the execution properties as a parameter (SCALA: need to compile with maven)

## Running Jobs


We can Run JOBS directly in Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

if we open it:

```
hdfs:
	cd ${JOBS_PATH}/scripts && $(MAKE) hdfs

remove-hdfs:
	cd ${JOBS_PATH}/scripts && $(MAKE) remove-hdfs

bash:
	cd ${JOBS_PATH}/scripts && $(MAKE) bash		

upload:
	cd ${JOBS_PATH}/scripts && $(MAKE) upload

download:
	cd ${JOBS_PATH}/scripts && $(MAKE) download

pdf2png:
	cd ${JOBS_PATH}/scripts && $(MAKE) pdf2png

png2txt:
	cd ${JOBS_PATH}/scripts && $(MAKE) png2txt

classification:
	cd ${JOBS_PATH}/scripts && $(MAKE) classification
```

we are mapping the make jobs integrated in the Makefile

For instance we can open a bash session in the cluster:


```
make bash		
```

after executing it, we can view something like this

```
[root@aidoc-06 swarm]# make bash
cd /apps/nfs/POC/jobs/scripts && make bash
make[1]: Entering directory `/apps/nfs/POC/jobs/scripts'
docker run --name aidoc-bash-shell-2 --rm -it --network workbench --volume nfs:/apps/nfs --volume /apps/nfs/arch/swarm/spark-conf/spark-defaults.conf:/spark/conf/spark-defaults.conf --volume /apps/nfs/arch/swarm/spark-conf/log4j.properties:/spark/conf/log4j.properties -e NFS_PATH=/apps/nfs -e JOBS_PATH=/apps/nfs/POC/jobs --env-file /apps/nfs/arch/swarm/hadoop.env aidoc/spark-base:latest bash
Configuring core
 - Setting hadoop.proxyuser.hue.hosts=*
 - Setting fs.defaultFS=hdfs://namenode:8020
 - Setting io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec
 - Setting hadoop.proxyuser.hue.groups=*
 - Setting hadoop.http.staticuser.user=root
Configuring hdfs
 - Setting dfs.namenode.datanode.registration.ip-hostname-check=false
 - Setting dfs.permissions.enabled=false
 - Setting dfs.webhdfs.enabled=true
Configuring yarn
 - Setting yarn.resourcemanager.fs.state-store.uri=/rmstate
 - Setting yarn.nodemanager.vmem-check-enabled=false
 - Setting yarn.timeline-service.generic-application-history.enabled=true
 - Setting mapreduce.map.output.compress=true
 - Setting yarn.resourcemanager.recovery.enabled=true
 - Setting mapred.map.output.compress.codec=org.apache.hadoop.io.compress.SnappyCodec
 - Setting yarn.timeline-service.enabled=true
 - Setting yarn.log-aggregation-enable=true
 - Setting yarn.resourcemanager.store.class=org.apache.hadoop.yarn.server.resourcemanager.recovery.FileSystemRMStateStore
 - Setting yarn.resourcemanager.system-metrics-publisher.enabled=true
 - Setting yarn.nodemanager.pmem-check-enabled=false
 - Setting yarn.nodemanager.remote-app-log-dir=/app-logs
 - Setting yarn.nodemanager.aux-services=mapreduce_shuffle
 - Setting yarn.resourcemanager.resource.tracker.address=resourcemanager:8031
 - Setting yarn.resourcemanager.hostname=resourcemanager
 - Setting yarn.scheduler.capacity.root.default.maximum-allocation-vcores=4
 - Setting yarn.timeline-service.hostname=historyserver
 - Setting yarn.scheduler.capacity.root.default.maximum-allocation-mb=8192
 - Setting yarn.log.server.url=http://historyserver:8188/applicationhistory/logs/
 - Setting yarn.scheduler.minimum-allocation-mb=4096
 - Setting yarn.resourcemanager.scheduler.class=org.apache.hadoop.yarn.server.resourcemanager.scheduler.capacity.CapacityScheduler
 - Setting yarn.resourcemanager.scheduler.address=resourcemanager:8030
 - Setting yarn.resourcemanager.address=resourcemanager:8032
 - Setting yarn.nodemanager.disk-health-checker.max-disk-utilization-per-disk-percentage=98.5
 - Setting yarn.nodemanager.resource.memory-mb=16384
 - Setting yarn.nodemanager.resource.cpu-vcores=8
Configuring httpfs
Configuring kms
Configuring mapred
 - Setting mapreduce.map.java.opts=-Xmx6144m
 - Setting mapred.child.java.opts=-Xmx4096m
 - Setting mapreduce.framework.name=yarn
 - Setting mapreduce.reduce.java.opts=-Xmx6144m
 - Setting mapreduce.reduce.memory.mb=8192
 - Setting mapreduce.map.memory.mb=8192
Configuring hive
Configuring for multihomed network
root@0fb127780843:/#

```

Considerations:
- integrated environment variables, NFS, Spark configuration and other things:

```
docker run --name aidoc-bash-shell-2 --rm -it 
--network workbench 
--volume nfs:/apps/nfs 
--volume /apps/nfs/arch/swarm/spark-conf/spark-defaults.conf:/spark/conf/spark-defaults.conf 
--volume /apps/nfs/arch/swarm/spark-conf/log4j.properties:/spark/conf/log4j.properties 
-e NFS_PATH=/apps/nfs 
-e JOBS_PATH=/apps/nfs/POC/jobs 
--env-file /apps/nfs/arch/swarm/hadoop.env 
aidoc/spark-base:latest bash
```

- network
- NFS volume
- SPARK CONFIGURATION
- NFS_PATH and JOBS_PATH variables
- HADOOP VARIABLES

that are built from the ``setenv.sh`` script

```
export DOCKER_ENV_VOLUME="--volume nfs:${NFS_PATH} --volume ${ARCH_PATH}/spark-conf/spark-defaults.conf:/spark/conf/spark-defaults.conf --volume ${ARCH_PATH}/spark-conf/log4j.properties:/spark/conf/log4j.properties"
export DOCKER_ENV_VARIABLES="-e NFS_PATH=${NFS_PATH} -e JOBS_PATH=${JOBS_PATH} --env-file ${HADOOP_ENV}" 
export DOCKER_ENV_NETWORK="--network workbench"
export DOCKER_RUN_ENV="${DOCKER_ENV_NETWORK} ${DOCKER_ENV_VOLUME} ${DOCKER_ENV_VARIABLES}"
```


## Run Jobs in General Cases

In general cases , the regular JOBS can Run directly in Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

- pdf2png: executes PDF2PNG JOB with the execution properties as a parameter (PYTHON)
- png2txt: executes PNG2TXT JOB with the execution properties as a parameter (PYTHON)
- classification: executes CLASSIFICATION JOB with the execution properties as a parameter (SCALA: need to compile with maven)

are launched by running 

```
make pdf2png

make png2txt

make classification	
```

internally the have 
- LAUNCHJOB
- ENVIRONMENT_PARAMETER

matched with: (PNG2TXT example)

```
${JOBS_PATH}/png2txt/launchJob.sh ${JOBS_PATH}/png2txt/spark.config.properties
```

the LAUNCHJOB.SH runs ``spark-submit`` and takes ``${JOBS_PATH}/png2txt/spark.config.properties`` as a first parameter

```
#!/bin/sh
/spark/bin/spark-submit ${SPARK_PARAMS} ${JOBS_PATH}/png2txt/ocr_images_spark.py $1
```

So the ``spark.config.properties`` has

```
[general]
spark-master=spark://spark-master:7077
deploy-mode=client

path-pdf-input=hdfs://namenode:8020/apps/nfs/data-input/pdf
path-images-input=hdfs://namenode:8020/apps/nfs/data-output/png
path-pdf-output=hdfs://namenode:8020/apps/nfs/data-output/pdf/

path-hocr-output=hdfs://namenode:8020/apps/nfs/data-output/hocr
path-ocr-output=hdfs://namenode:8020/apps/nfs/data-output/csv/
path-txt-pages=/apps/nfs/data-output/txt-pages/
path-txt-complete=/apps/nfs/data-output/txt-complete/

hdfs_ip=namenode
hdfs_port=50070
```


