# OCR SPARK APP RUN INFO


## Steps:
0. check docker spark container is up (or start it /apps/jene/infra/docker_scripts/./launch-spark.sh
1. git clone project: https://jene@appverse.gftlabs.com/git/scm/ab/cognitivebanking-ocr-pdf.git
2. cd ocr_tesseract
3. build the project: /apps/jene/cognitivebanking-ocr-pdf/ocr_tesseract/mvn clean package
4. copy the jar file to spark docker: docker cp target/job-ocr-pdf-1.0.jar spark:/home/shared/python_apps/ocr
5. check pdf path folder that is shared by spark docker, usually is: /apps/jene/infra/docker_scripts/shared_vol/python_apps/ocr/pdfs/ in digitalbank host and upload pdf files there
6. SPARK EXECUTION :  /apps/jene/infra/docker_scripts/./launch-spark-ocr.sh it will start the full process getting pdf files from above folder, making ocr and classification on these files and saving all data to elk and hdfs (check kibana)
7. check ocr_documents index in kibana: http://digitalbank-ml.gft.com:5601
8. check fs directory: /apps/jene/infra/docker_scripts/shared_vol/python_apps/ocr/pdfs/txt for text files


## APPENDIX: docker installation notes

### application source:
installing tesseract 3.0.4 (from tess4j 3.3.1) assumes that leptonica version is 1.74.1 (comes from lept4j 1.3.1) ????????
as tesseract info says: 3.04	1.71	Ubuntu 16.04 (as https://github.com/tesseract-ocr/tesseract/wiki/Compiling says)

### installed libraries (steps from dockerfile)

#### server source WORKS:
but during tesseract installation, says: configure: error: Leptonica 1.74 or higher is required. Try to install libleptonica-dev package.
and leptonica 1.74 comes with libpng


- install libpng 12.5.0:
```
apt-get install -y zlib1g-dev
wget https://sourceforge.net/projects/libpng/files/libpng12/older-releases/1.2.50/libpng-1.2.50.tar.gz/download
cd libpng12.5.0
LIBS=-lpthread ./configure --prefix=/usr --disable-static && make
make install
-- check : libpng-config --version
```

- install leptonica 1.71:
```
wget http://www.leptonica.com/source/leptonica-1.71.tar.gz
tar xvf leptonica-1.71.tar.gz
cd leptonica-1.71
./configure --prefix=/usr/local
make
make install
```

- install tesseract
```
git clone https://github.com/tesseract-ocr/tesseract.git
cd tesseract
./autogen.sh
./configure
LDFLAGS="-L/usr/local/lib" CFLAGS="-I/usr/local/include" make
make install
ldconfig
cd tessdata
wget https://github.com/tesseract-ocr/tessdata/raw/master/spa.traineddata
```

- install ghostscript
```
wget https://github.com/ArtifexSoftware/ghostpdl-downloads/releases/download/gs921/ghostscript-9.21.tar.gz
tar -xvf ghostscript-9.21.tar.gz
cd ghostscript-9.21
./configure
make install
make so
cp sobin/libgs.so.9.21 /usr/lib
ln -s /usr/lib/libgs.so.9.21 /usr/lib/libgs.so
mkdir -p /etc/ld.so.conf.d/
echo "/usr/lib/libgs.so" > /etc/ld.so.conf.d/libgs.conf
ldconfig
```

#### The next steps FAILS but should work but if fails due of tesseract version from app source. It´ll be fixed if a tess4j or java tesseract dependency
is updated with leptonica 1.74 (current is 1.71...)

##### install ghostscript
```
RUN apt-get update \
cd /home \
wget https://github.com/ArtifexSoftware/ghostpdl-downloads/releases/download/gs921/ghostscript-9.21.tar.gz \
tar -xvf ghostscript-9.21.tar.gz \
cd ghostscript-9.21 \
apt-get install -y gcc \
./configure \
apt-get install -y make \
make install \
make so \
cp sobin/libgs.so.9.21 /usr/lib \
ln -s /usr/lib/libgs.so.9.21 /usr/lib/libgs.so \
mkdir -p /etc/ld.so.conf.d/ \
echo "/usr/lib/libgs.so" > /etc/ld.so.conf.d/libgs.conf \
ldconfig \
echo "Installing ghostscript finish" \
```

##### install leptonica
```
wget http://www.leptonica.org/source/leptonica-1.74.1.tar.gz \
tar xvf leptonica-1.74.1.tar.gz \
cd leptonica-1.74.1 \
./configure \
make install \
```

##### install tesseract
```
apt-get install -y git \
git clone https://github.com/tesseract-ocr/tesseract.git \ // download library
cd tesseract \
apt-get install -y g++ \
apt-get install -y autoconf automake libtool \
apt-get install -y autoconf-archive \
apt-get install -y pkg-config \
apt-get install -y libpng12-dev \
-- apt-get install -y libjpeg8-dev \
apt-get install -y libtiff5-dev \
apt-get install -y zlib1g-dev \
apt-get install -y libleptonica-dev \
./autogen.sh \
./configure \
LDFLAGS="-L/usr/local/lib" CFLAGS="-I/usr/local/include" make \
make install \
ldconfig
### install language
cd tessdata \
wget https://github.com/tesseract-ocr/tessdata/raw/master/spa.traineddata \ // download language: spa.traineddata
```

##### export tessdata folder
```
export TESSDATA_PREFIX=/apps/jene/tesseract/tessdata
```

##### Cloudera branch

The project has been updated to spark 1.6. The branch name is spark-1.6.

These are the steps:

```
git clone -b spark-1.6 https://jene@appverse.gftlabs.com/git/scm/ab/cognitivebanking-ocr-pdf.git

cd cognitivebanking-ocr-pdf/ocr_tesseract

mvn clean package
```

The following command will execute the job in cluster:
```
spark-submit  --master yarn-client --class "com.jene.cognitive.OcrTess4jSpark" --driver-java-options "-Denv=aidoc -Djna.library.path='$LD_LIBRARY_PATH:/usr/local/lib64' -Djava.library.path=$LD_LIBRARY_PATH:/usr/local/lib64 -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps" --driver-memory 6g --num-executors 8 --executor-memory 6g --conf "spark.executor.extraJavaOptions=-Djna.library.path='$LD_LIBRARY_PATH:/usr/local/lib64'"  --conf "spark.executor.extraLibraryPath=/apps/opt/cloudera/parcels/CDH-5.11.1-1.cdh5.11.1.p0.4/lib/hadoop/lib/native:/usr/local/lib" target/job-ocr-pdf-1.0.jar
```
You have to check that the project properties set are:

```
path-pdfs=/data/ocr/pdfs (hdfs)

path-output=/apps/tmp/ocr_txtfiles/ (fs)
```
You can check this file: https://appverse.gftlabs.com/git/projects/AB/repos/cognitivebanking-ocr-pdf/browse/ocr_scripts (Copy pdf files to hdfs) to upload your files







