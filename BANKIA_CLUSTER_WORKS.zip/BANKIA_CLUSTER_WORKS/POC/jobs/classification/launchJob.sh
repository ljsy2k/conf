#!/bin/sh
/spark/bin/spark-submit ${SPARK_PARAMS} --class "com.gft.exponential.ClassificationRecursive" --driver-java-options "-Denv=spark" ${JOBS_PATH}/classification/target/job-classification-1.0.jar $1

