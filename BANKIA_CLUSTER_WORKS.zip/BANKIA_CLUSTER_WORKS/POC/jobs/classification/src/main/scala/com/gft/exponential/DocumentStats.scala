package com.gft.exponential

//import java.text.SimpleDateFormat
import java.util.Date

import scala.beans.BeanProperty

/**
  * Created by jene on 06/09/2017.
  */
class DocumentStats  extends Serializable{


  @BeanProperty
  var id:String=_
  @BeanProperty
  var filename:String=_
  @BeanProperty
  var dateStart:Date=_
  @BeanProperty
  var dateEnd:Date=_
  @BeanProperty
  var dateStartPdf:Date=_
  @BeanProperty
  var dateEndPdf:Date=_
  @BeanProperty
  var numPags:Long=0
  @BeanProperty
  var dateStartOcr:Date=_
  @BeanProperty
  var dateEndOcr:Date=_
  @BeanProperty
  var dateStartFileSystem:Date=_
  @BeanProperty
  var dateEndFileSystem:Date=_
  @BeanProperty
  var dateStartClassification:Date=_
  @BeanProperty
  var dateEndClassification:Date=_
  @BeanProperty
  var totalTime:Long=0
  @BeanProperty
  var pdfTime:Long=0
  @BeanProperty
  var ocrTime:Long=0
  @BeanProperty
  var fileTime:Long=0
  @BeanProperty
  var classificationTime:Long=0
  @BeanProperty
  var numberOfExecutors:Long=0

  def DocumentStats() = {}

  def init (id : String, filename : String) = {
    // stats id, start date
    //this.setId(UUID.randomUUID().toString())
    this.setId(id)
    this.setFilename(filename)
    //val date = new Date();
    //this.setDateStart(this.dateFormat.format(date))
    this.setDateStart(new Date())
  }

  def end () = {
    val date = new Date();
//    this.setDateEnd(this.dateFormat.format(date))
    this.setDateEnd(new Date())
    this.totalTime = (this.getDateEnd.getTime-this.getDateStart.getTime)/1000;
  }

  def initPdf () = {
    this.setDateStartPdf(new Date())
  }
  def endPdf () = {
    this.setDateEndPdf(new Date())
    this.pdfTime = (this.getDateEndPdf.getTime-this.getDateStartPdf.getTime)/1000;
  }

  def initOcr () = {
    this.setDateStartOcr(new Date())
  }
  def endOcr () = {
    this.setDateEndOcr(new Date())
    this.ocrTime = (this.getDateEndOcr.getTime-this.getDateStartOcr.getTime)/1000;
  }

  def initFileSystem () = {
    this.setDateStartFileSystem(new Date())
  }
  def endFileSystem () = {
    this.setDateEndFileSystem(new Date())
    this.fileTime = (this.getDateEndFileSystem.getTime-this.getDateStartFileSystem.getTime)/1000;
  }

  def initClassification () = {
    this.setDateStartClassification(new Date())
  }
  def endClassification () = {
    this.setDateEndClassification(new Date())
    this.fileTime = (this.getDateEndClassification.getTime-this.getDateStartClassification.getTime)/1000;
  }


  def toHdfs = s"$id, $filename, $dateStart, $dateEnd, $dateStartPdf, $dateEndPdf, $numPags, $dateStartOcr, $dateEndOcr, $dateStartFileSystem, $dateEndFileSystem, $dateStartClassification, $dateEndClassification, $totalTime, $pdfTime, $ocrTime, $fileTime, $classificationTime, $numberOfExecutors"
  override def toString = s"DocumentStats($id, $filename, $dateStart, $dateEnd, $dateStartPdf, $dateEndPdf, $numPags, $dateStartOcr, $dateEndOcr, $dateStartFileSystem, $dateEndFileSystem, $dateStartClassification, $dateEndClassification, $totalTime, $pdfTime, $ocrTime, $fileTime, $classificationTime, $numberOfExecutors)"
}
