package com.gft.exponential.model

import scala.beans.BeanProperty

class Entity extends Serializable {

  @BeanProperty
  var id: String = _

  @BeanProperty
  var `type`: String = _

  @BeanProperty
  var page: Int = 0

  @BeanProperty
  var score: Double = 0

  @BeanProperty
  var value: String = _

  @BeanProperty
  var modified: Boolean = false

   @BeanProperty
  var added: Boolean = false

   @BeanProperty
  var deleted: Boolean = false

  
  def Entity () = {}

  def setTypeValue (value: String) {
    this.`type` = value;
  }

}
