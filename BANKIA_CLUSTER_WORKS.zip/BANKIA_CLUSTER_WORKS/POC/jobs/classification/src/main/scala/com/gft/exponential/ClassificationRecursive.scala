package com.gft.exponential
import java.io.File
import java.io.FileInputStream
import java.util.Calendar
import java.util.Properties
import java.util.UUID

import scala.collection.JavaConversions._
import scala.collection.mutable.ListBuffer
import scala.util.Try

import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.FileSystem
import org.apache.hadoop.fs.Path
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.DefaultHttpClient
import org.apache.http.util.EntityUtils
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{ Encoders, SparkSession, _ }
import org.elasticsearch.spark.rdd.EsSpark
import org.slf4j.LoggerFactory

import com.esotericsoftware.kryo.Kryo
import com.esotericsoftware.kryo.KryoSerializable
import com.esotericsoftware.kryo.io.Input
import com.esotericsoftware.kryo.io.Output
import com.gft.exponential.model.Entity
import com.gft.exponential.model.Procedure
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.typesafe.scalalogging.slf4j.Logger;
import java.util.Base64
import org.apache.commons.lang3.StringEscapeUtils
import org.apache.hadoop.fs.FileUtil

case class OcrSchema(PdfPath: String, Ocr: String, HocrPath: String,
  HocrPages: String, ImagesPath: String, ImagesPages: String, Classification: String, Entities: String)

case class RequestDoc(var doc: String) {
  override def toString = doc
}


object ClassificationRecursive extends KryoSerializable {

  val logger = Logger(LoggerFactory.getLogger("Classification"))
  val prop = new Properties();
  val id = UUID.randomUUID().toString
  var env = "dev"

  def main(args: Array[String]) {

    var configFile = "spark"
    // env property sent to java
    try {
      if (args.length > 0) {
        configFile = args(0)
        this.env = args(0)
        val file = new File(configFile)
        val fileIn = new FileInputStream(file)
        prop.load(fileIn)
      } else {
        this.env = "spark"
        configFile = "spark.config.properties"
        val input = Thread.currentThread().getContextClassLoader.getResourceAsStream(configFile)
        prop.load(input)

      }
    } catch {
      case e: Exception =>
        logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + e.getMessage());
        configFile = "spark.config.properties"
    }

   
     
    
    prop.setProperty("id-process", this.id)

    if (Try(prop.get("logging").toString.toBoolean).getOrElse(true))
      logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Init " + this.getClass.getName + " app")

    if (Try(prop.get("logging").toString.toBoolean).getOrElse(true))
      logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Loaded " + configFile)

    for (e <- prop.entrySet) {
      if (Try(prop.get("logging").toString.toBoolean).getOrElse(true))
        logger.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> property key: " + e.getKey.toString + " -> value: " + e.getValue.toString)
      //props += (e.getKey.toString -> e.getValue.toString)
    }

    val sparkSession = SparkSession.builder().master(prop.get("spark-master").toString).appName(this.getClass.getName).getOrCreate()
    sparkSession.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    sparkSession.sparkContext.hadoopConfiguration.set("mapreduce.input.fileinputformat.input.dir.recursive", "true")
    sparkSession.conf.set("spark.network.timeout", "6000")
    sparkSession.conf.set("spark.rpc.askTimeout", "6000")
    sparkSession.conf.set("spark.akka.timeout", "6000")
    sparkSession.conf.set("spark.worker.timeout", "6000")

    sparkSession.conf.set("es.index.auto.create", "true")
    sparkSession.conf.set("es.nodes", prop.get("elasticsearch").toString)
    sparkSession.conf.set("es.index.auto.create", "true")
    sparkSession.conf.set("es.spark.dataframe.write.null", "true")
    sparkSession.conf.set("es.spark.dataframe.write.null.values.default", "true")
    sparkSession.conf.set("es.read.field.empty.as.null", "false")
    sparkSession.conf.set("es.field.read.empty.as.null", "false")
    sparkSession.conf.set("es.read.field.empty.as.null", "false")
    sparkSession.conf.set("es.field.read.empty.as.null", "false")
    sparkSession.conf.set("es.nodes.wan.only", "true")
    sparkSession.conf.set("es.mapping.id", prop.get("elasticsearch-mapping-id").toString)

    // if(this.env != "local")
    //   sparkSession.sparkContext.setLogLevel("DEBUG")

    val config = scala.collection.Map("es.nodes" -> prop.get("elasticsearch").toString, "es.index.auto.create" -> "true",
      "es.spark.dataframe.write.null" -> "true", "es.spark.dataframe.write.null.values.default" -> "true", "es.read.field.empty.as.null" -> "false",
      "es.field.read.empty.as.null" -> "false", "es.field.read.empty.as.null" -> "false", "es.nodes.wan.only" -> "true", "es.mapping.id"->prop.get("elasticsearch-mapping-id").toString)

    //TODO: get another way to broadcast vars
    val broadcastProps = sparkSession.sparkContext.broadcast(prop)

    // TODO: change map to mapPartitions to scale better
    
    
    val uuid_key = sparkSession.conf.get("spark.app.id")

    val the_master = sparkSession.conf.get("spark.master")
    //val the_client = sparkSession.conf.get("spark.submit.deployMode")
    
   logger.info("-------------------BEGIN CLASSIFICATION EXECUTION------KEY: "+uuid_key+"-------------------")
   logger.info("CLASSIFICATION: SPARK PARAMETERS : MASTER : "+the_master )
   //logger.info("CLASSIFICATION: SPARK PARAMETERS : DEPLOY_MODE : "+the_client )
   logger.info("CLASSIFICATION: SPARK PARAMETERS : SPARK_ID : "+uuid_key )

   logger.info("Config File used " +configFile)
    
    val sqlContext = sparkSession.sqlContext

    var ocrSchema = Encoders.product[OcrSchema].schema

    val conf = new Configuration()
    val fs = FileSystem.get(conf)
    val files = fs.listFiles(new Path(prop.get("path-ocr-output").toString()), true)
    val filePaths = new ListBuffer[String]
    while (files.hasNext()) {
      val file = files.next()
      filePaths += file.getPath.toString
    }

   
    val dfOcr = sparkSession.read
      .option("header", "false")
      .option("delimiter", "\t")
      .schema(ocrSchema)
      .csv(filePaths: _*)

    /*val dfOcr = sparkSession.read
      .option("header", "false")
      .option("delimiter", "\t")
      .schema(ocrSchema)
      .csv(prop.get("path-ocr-output").toString())*/
      
      
      
    /* ORIGINAL
     *   
     *   
     *   
       val rddMl = dfOcr.rdd
      .map(row => classification(row, broadcastProps))
      .map(row => entityExtraction(row, broadcastProps))

    val dfMl = sparkSession.createDataFrame(rddMl, ocrSchema)

    dfMl.write.save(prop.get("path-classification-output").toString)

    val proc = dfMl.rdd.map(row => createElkObjects(row, broadcastProps))
    EsSpark.saveToEs(proc, "procedures/procedure", config)
     *   
     */
      
    val str1 = sparkSession.conf.getAll.toString()

    logger.info("PDF2PNG: SPARK PARAMETERS : "+str1+"------KEY: "+id+"-------------------" )
    
    val t1 = System.nanoTime
      
    logger.info("Execute Classification Job Begin")      
    logger.info("Input Path: "+prop.get("path-ocr-output").toString())
    logger.info("ElasticSearch Server: "+prop.get("elasticsearch").toString())
    logger.info("ElasticSearch Index: "+prop.get("elasticsearch-index").toString())
    logger.info("Executing Spark Master: "+prop.get("spark-master").toString())
    
    
    
    val rddMl = dfOcr.rdd
      .map(row => classification(row, broadcastProps))
      .map(row => entityExtraction(row, broadcastProps))
      .map(row => createElkObjects(row, broadcastProps))
    
    
    logger.info("Processed DataRDD " + rddMl.count())
     
    if (Try(prop.get("export_to_elasticsearch").toString.toBoolean).getOrElse(true)) {
        EsSpark.saveToEs(rddMl, prop.get("elasticsearch-index").toString(), config)
        logger.info("Exported to ElasticSearch"+prop.get("elasticsearch-index").toString())
    }
    

     if (Try(prop.get("move_to_output").toString.toBoolean).getOrElse(true))
     {
        val filesToMove = fs.listFiles(new Path(prop.get("path-ocr-output").toString()), true)
        val destPath = new Path(prop.get("path-classification-output").toString())
    
        while (filesToMove.hasNext()) {
          val file = filesToMove.next()
     
          FileUtil.copy(fs,file.getPath,fs,destPath, true, conf)
          logger.debug("FILE MOVED " + file.getPath+" TO "+destPath )
        }
     }

    logger.info("Execute Classification Job End")
    val duration = (System.nanoTime - t1) / 1e9d
    logger.info("-------------------END CLASSIFICATION EXECUTION------KEY: "+uuid_key+"-------------------TIME "+duration+" seconds ---")
    sparkSession.stop()
  }

  def createElkObjects(row: Row, prop: Broadcast[Properties]): Procedure =
    {
      val properties = prop.value

      //@transient val statDoc = new DocumentStats()

      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.info("Generate ELK Objects Method to Export Begin")

      //"PdfPath", "Ocr", "HocrPath", "HocrPages", "ImagesPath", "ImagesPages"
      val procedure = new Procedure()

      if (row(0) != null) {
        procedure.setPdfsPath(row(0).toString)
      }
		
      if (row(1) != null) {
        procedure.setText(row(1).toString)
      }

      if (row(2) != null) {
        procedure.setHocrsPath(row(2).toString)
      }
		
      if (row(4) != null) {
        procedure.setImagesPath(row(4).toString)
        
        val fileName = row(4).toString.split("/").last;
        procedure.setFilename(fileName)
      }

      if (row(5) != null) {
        val last = row(5).toString.split("-")
        procedure.setPages(last(1).toInt)
      }

      if (row(6) != null) {
        
        val classification = row(6).toString
        procedure.setClassification(classification)
        
        if  (classification.equalsIgnoreCase("OTROS") ) {
          procedure.setStatus("NOT_CLASSIFIED")
        }
        else 
          procedure.setStatus("CLASSIFIED")
        
      }

      if (row(7) != null) {
        var entitiesJsonArr = new JsonParser().parse(row(7).toString).getAsJsonArray

        var entities = entitiesJsonArr.map(entity => jsonToEntity(entity.getAsJsonObject)).toArray

        procedure.setEntities(entities)
      }
      
      procedure.setId(UUID.randomUUID().toString)
      
      val date = Calendar.getInstance.getTime
      
      procedure.setCreated(date)
      
      procedure.setModified(date)
      
      val pathHocrPrefix= properties.get("path-hocr-prefix").toString()
      val pathPngPrefix= properties.get("path-png-prefix").toString()
      val pathPdfPrefix= properties.get("path-pdf-prefix").toString()
      val hocrSuffix = properties.get("hocr-suffix").toString()
      val imagesSuffix = properties.get("images-suffix").toString()
      
      val pathWebHdfs= properties.get("path-web-hdfs").toString()
      

      procedure.setImagesSuffix(imagesSuffix)
      procedure.setHocrSuffix(hocrSuffix)

      procedure.setHocrsPath(pathHocrPrefix)
      procedure.setPdfsPath(pathPdfPrefix)
      procedure.setImagesPath(pathPngPrefix)
      procedure.setPathWebHdfs(pathWebHdfs)
      

      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.info("Generate ELK Objects Method to Export End")

      procedure
    }

  /**
   *
   * @param row
   * @param prop
   * @return
   */
  def classification(row: Row, prop: Broadcast[Properties]): Row = {
    val properties = prop.value

    if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
      logger.info("Classification Method Begin")

    var classifText: String = ""

    try {

      /*val fixed = new String(row(1).toString().getBytes(), "UTF-8")
      val doc = new RequestDoc(fixed)

      val docAsJson = new Gson().toJson(doc)*/
      
       val fixed0 = new String(row(1).toString().getBytes(), "UTF-8")
     
      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.debug("::: Classification ::: Text before Escape to HTML :" +fixed0)
      
     def escapeHtml = StringEscapeUtils.escapeHtml4(fixed0)
     val doc = new RequestDoc(escapeHtml)
     val docAsJson = new Gson().toJson(doc)
      

      //System.out.println(docAsJson.toString())

      // create an HttpPost object
      val post = new HttpPost(properties.get("url-classification").toString)

      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.debug("::: Classification :::  doc as JSON parsed used " +docAsJson.toString())


      // set the Content-type
      post.setHeader("Content-type", "application/json")

      // add the JSON as a StringEntity
      post.setEntity(new StringEntity(docAsJson))
      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.info("::: Classification ::: About to call POST classification Server ")

      // send the post request
      val response = (new DefaultHttpClient).execute(post)

      val salida = EntityUtils.toString(response.getEntity)
     
      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.debug("::: Classification ::: Returned entities :" +salida)

      val jsonStringAsObject = new JsonParser().parse(salida).getAsJsonObject

      var finalPrediction = 0.00
      val it = jsonStringAsObject.entrySet().iterator()
      while (it.hasNext) {
        val v = it.next()
        val classType = v.getKey
        val classPrediction = v.getValue
        if (classPrediction.getAsFloat >= finalPrediction) {
          finalPrediction = classPrediction.getAsFloat
          classifText = classType
        }
      }

      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.info("::: Classification :::  end http query, response: " + response.getStatusLine.getStatusCode)

    } catch {
      case e: Exception =>
        logger.error("::: Classification ::: error in get request", e)
    }
    
    if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
      logger.info("Classification Method End")

    Row(row(0), row(1), row(2), row(3), row(4), row(5), classifText)
  }

  /**
   * Method to call texts classifier
   *
   * @param row (filename, text)
   * @return
   */
  def entityExtraction(row: Row, prop: Broadcast[Properties]): Row = {

    val properties = prop.value

    if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
      logger.info("Entity Extraction Method Begin")

    var entities_extraction: String = ""

    try {

     //val fixed0 = new String(row(1).toString().getBytes("Windows-1252"),"UTF-8")
       val fixed0 = new String(row(1).toString().getBytes(), "UTF-8")
     
      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.debug("::: entityExtraction :::  READED TEXT BEFORE ESCAPE :" +fixed0)
      
     def escapeHtml = StringEscapeUtils.escapeHtml4(fixed0)
     val doc = new RequestDoc(escapeHtml)
     val docAsJson = new Gson().toJson(doc)

     if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.debug("::: entityExtraction :::   Escaped String to send :" +docAsJson.toString())

      // create an HttpPost object
      val post = new HttpPost(properties.get("url-entities-extraction").toString)

      // set the Content-type
      post.setHeader("Content-type", "application/json")

      // add the JSON as a StringEntity
      post.setEntity(new StringEntity(docAsJson))
      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.info("::: entityExtraction ::: start http query ")

      // send the post request
      val response = (new DefaultHttpClient).execute(post)

      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.info("::: entityExtraction ::: end http query , response: " + response.getStatusLine.getStatusCode)

      val salida = EntityUtils.toString(response.getEntity)
      
      if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.debug("::: entityExtraction :::   Returned entities :" +salida)

      val jsonStringAsObject = new JsonParser().parse(salida).getAsJsonObject

      val it = jsonStringAsObject.entrySet().iterator()
      
      val arrayOutput = new JsonArray()
      
      while (it.hasNext) {
        
        val output = new JsonObject()
        
        val v = it.next()
        val key = v.getKey
        
        val value = v.getValue
        
        output.addProperty("type", key)
        output.addProperty("id", UUID.randomUUID().toString)
         
        val array = value.getAsJsonArray
        val arrayJson = array.get(0).getAsJsonObject
        val newIt = arrayJson.entrySet().iterator()
        while (newIt.hasNext())
        {
           val v = newIt.next()
           val classType = v.getKey
           val classPrediction = v.getValue
           output.addProperty(classType, classPrediction.getAsString)
        }
        
        arrayOutput.add(output)
      }
      
      
        if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
        logger.debug("::: entityExtraction :::   Returned method :" +arrayOutput.toString())

      entities_extraction = arrayOutput.toString()

    } catch {
      case e: Exception =>
        logger.error("::: entityExtraction ::: error in get request", e)
    }
    
    if (Try(properties.get("logging").toString.toBoolean).getOrElse(true))
      logger.info("Entity Extraction Method End")

    Row(row(0), row(1), row(2), row(3), row(4), row(5), row(6), entities_extraction)
  }

  def jsonToEntity (json: JsonObject): Entity = {
    var entity = new Entity()

    entity.setId(json.get("id").getAsString.replaceAll("\"", ""))
    entity.setTypeValue(json.get("type").getAsString.replaceAll("\"", ""))
    entity.setPage(json.get("page").getAsInt)
    
    val score = json.get("score")
    
    if (score !=null)
    {
      val value = json.get("score").getAsString.replaceAll("\"", "")
      entity.setScore(value.toDouble)
    }
    
    
    entity.setValue(json.get("value").getAsString.replaceAll("\"", ""))
    entity.setModified(false)

    entity
  }
  /*

  /**
    * start stats
    *
    * @param file
    * @param prop
    * @return
    */
  def createStats(
                   file: String,
                   prop: Broadcast[Properties] ) :
  (String, DocumentStats) =
  {
    val properties = prop.value
    @transient val statDoc = new DocumentStats()
    statDoc.init(properties.get("id-process").toString, file)

    (file, statDoc)
  }

  /**
    * Check valid file extension (PDF)
    * @param file
    * @return
    */
  def checkFileExtension(file: (String, DocumentStats)): Boolean =
  {
    val i = file._1.lastIndexOf('.')
    val extension = file._1.substring(i+1)
    if("txt".equalsIgnoreCase(extension)) true
    else false
  }



  /**
    * Method to store data on disk
    *
    * @param file (filename, list[ (page, content)])
    * @return
    */
  def storeFs (
                file: (String, String),
                prop: Broadcast[Properties]
              ) : (String, String) =
  {

    val r = new scala.util.Random
    val fileNewPath = "C:\\dev\\workspace\\tmp\\texts-output\\"+ r.nextInt(( 30 - 20) + 1)+".txt"
    val fw = new FileWriter(fileNewPath, true)

    try {

      fw.write(file._1 + "---" + file._2)
    }
    finally fw.close()


    (file._1, file._2)
  }


  /**
    * Method to call texts classifier
    *
    * @param file (filename, text)
    * @return
    */
  def temp (
             file: ((String, DocumentStats), String),
             prop: Broadcast[Properties] )
  : (String, String) = synchronized
  {
    val f1 = file._1._1
    val f2 = file._2

    (file._1._1, file._2)
  }
*/

  override def write(kryo: Kryo, output: Output): Unit = ???

  override def read(kryo: Kryo, input: Input): Unit = ???
}
