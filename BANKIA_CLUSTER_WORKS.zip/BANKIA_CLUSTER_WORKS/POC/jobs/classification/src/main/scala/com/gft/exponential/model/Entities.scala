package com.gft.exponential.model

//import java.text.SimpleDateFormat
import scala.beans.BeanProperty
import scala.collection.mutable

/**
  * Created by jene on 06/09/2017.
  */
class Entities  extends Serializable{


  @BeanProperty
  var procedure:mutable.HashMap[String,String]=_

  @BeanProperty
  var main_claimants:Array[mutable.HashMap[String,String]]=_

  @BeanProperty
  var identity_first_claimant:Array[mutable.HashMap[String,String]]=_

  @BeanProperty
  var other_claimants:Array[mutable.HashMap[String,String]]=_

  @BeanProperty
  var identity_other_claimants:Array[mutable.HashMap[String,String]]=_

  @BeanProperty
  var court:Array[mutable.HashMap[String,String]]=_

  @BeanProperty
  var attorney:Array[mutable.HashMap[String,String]]=_

  @BeanProperty
  var lawyer:Array[mutable.HashMap[String,String]]=_

  def Entities() = {}


}
