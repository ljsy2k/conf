package com.gft.exponential.model

//import java.text.SimpleDateFormat
import scala.beans.BeanProperty
import scala.collection.mutable
import java.util.Date

class Procedure  extends Serializable{

  @BeanProperty
  var classification:String=_
 
  @BeanProperty
  var created:Date=_

  @BeanProperty
  var entities: Array[Entity] = _

  @BeanProperty
  var filename:String=_
 
  @BeanProperty
  var hocrSuffix:String=_
  
  @BeanProperty
  var hocrsPath:String=_
 
  @BeanProperty
  var imagesPath:String=_
 
  @BeanProperty
  var imagesSuffix:String=_
  
  @BeanProperty
  var modified:Date=_
  
  @BeanProperty
  var pages:Int = 0
  
  @BeanProperty
  var pdfsPath:String=_
  
    
  @BeanProperty
  var status:String=_
  
  @BeanProperty
  var text:String=_

    

   @BeanProperty
  var id:String=_
  

  @BeanProperty
  var pathWebHdfs:String=_

  
 /*  @BeanProperty
  var pathHocrPrefix:String=_
  
   @BeanProperty
  var pathPngPrefix:String=_
  
   @BeanProperty
  var pathPdfPrefix:String=_
  */
  
  
 
  
 /* @BeanProperty
  var entities:Entities=_
 
  */

  def Procedure() = {}

}
