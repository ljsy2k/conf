package com.gft.exponential.model

//import java.text.SimpleDateFormat
import scala.beans.BeanProperty
import scala.collection.mutable

/**
  * Created by jene on 06/09/2017.
  */
class ProcedureOld  extends Serializable{


  @BeanProperty
  var pdf:String=_

  @BeanProperty
  var pages:Array[mutable.HashMap[String,String]]=_

  @BeanProperty
  var classification:String=_
  
  @BeanProperty
  var entitiesRaw:String=_

  @BeanProperty
  var entities:Entities=_

  def ProcedureOld() = {}

}
