/spark/bin/spark-submit  --class "com.gft.exponential.ClassificationRecursive" --driver-java-options "-Denv=aidoc" target/job-classification-1.0.jar
