#!/bin/sh

echo /spark/bin/spark-submit --master yarn --deploy-mode cluster --num-executors 4 --executor-cores 1 --executor-memory 756m  --py-files ${JOBS_PATH}/pdf2png/yarn_logger.py --files ${JOBS_PATH}/pdf2png/$1 ${JOBS_PATH}/pdf2png/pdf2png_job.py $1
/spark/bin/spark-submit --master yarn --deploy-mode cluster --num-executors 4 --executor-cores 1 --executor-memory 756m  --py-files ${JOBS_PATH}/pdf2png/yarn_logger.py --files ${JOBS_PATH}/pdf2png/$1 ${JOBS_PATH}/pdf2png/pdf2png_job.py $1