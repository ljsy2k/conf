import os
import logging
import sys
import configparser

class YarnLogger:
    def __init__(self,env):
        self.env = env

    @staticmethod
    def setup_logger(self):

        file = '/spark/logs/PDF2PNG.log'
        logging.basicConfig(filename=file, level=logging.INFO,
                            format='%(asctime)s [%(levelname)s] %(module)s %(funcName)s - %(message)s')

    def __getattr__(self, key):
        return getattr(logging, key)

#YarnLogger.setup_logger()
