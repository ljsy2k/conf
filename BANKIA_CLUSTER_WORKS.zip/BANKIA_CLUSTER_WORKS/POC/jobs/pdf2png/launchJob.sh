#!/bin/sh
#current_path="$(pwd)"
#echo "${current_path}"
#/spark/bin/spark-submit ${SPARK_PARAMS} --py-files ${JOBS_PATH}/pdf2png/hdfs_tools.py,${JOBS_PATH}/pdf2png/logger.py --files ${JOBS_PATH}/pdf2png/$1 ${JOBS_PATH}/pdf2png/pdf2png_job.py ${JOBS_PATH}/pdf2png/$1

echo /spark/bin/spark-submit ${SPARK_PARAMS} --py-files ${JOBS_PATH}/pdf2png/yarn_logger.py --files ${JOBS_PATH}/pdf2png/$1 ${JOBS_PATH}/pdf2png/pdf2png_job.py ${JOBS_PATH}/pdf2png/$1
/spark/bin/spark-submit ${SPARK_PARAMS} --py-files ${JOBS_PATH}/pdf2png/yarn_logger.py --files ${JOBS_PATH}/pdf2png/$1 ${JOBS_PATH}/pdf2png/pdf2png_job.py ${JOBS_PATH}/pdf2png/$1