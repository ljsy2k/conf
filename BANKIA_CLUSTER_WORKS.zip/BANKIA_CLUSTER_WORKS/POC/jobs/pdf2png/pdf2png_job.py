# -*- coding: utf-8 -*-
"""
PDF2PNG spark job
Ghostscript

@author: dlri
"""

### Libraries

import pyspark
from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.streaming import StreamingContext 

import sys
import locale
#import ghostscript
import subprocess
import os
import tempfile
import time
import configparser
import re
import yarn_logger
import time
import uuid


### main function
def main():
    start_time = time.time()
    pdfs = sparkSession.sparkContext.binaryFiles(config.get('general', 'path-pdf-input'))

    #print("<o>======================= Mapping process for files in: ",config.get('general', 'path-pdf-input'))
    logger.info("<o>======================= Mapping process for files in: "+config.get('general', 'path-pdf-input'))
    
    pdfs.map(lambda x : (x[0], pdf2png(x))).count()
    
    input = config.get('general', 'path-pdf-input')
    destiny = config.get('general', 'path-pdf-output')
    
    move_in_hdfs(input+"/*.pdf",destiny)
    
    #print("<o>======================= #### PROCESS ENDED ####")
    logger.info("-------------------END PDF2PNG EXECUTION------KEY: "+uuid_key+"-------------------TIME %s seconds ---" % (time.time() - start_time))    
    
def check_file(filename):
    
    checkFile = subprocess.Popen(['hadoop', 'fs', '-test', '-e', filename])
    checkFile.wait()
    if checkFile.returncode:
        #print (filename+' not exist')
        logger.error(filename+' not exist')
        return False
    return True

def move_in_hdfs(input_filename, output_filename):
    
    out_dir = "/".join(output_filename.split("/")[:-1])
    mkdir = subprocess.Popen(["hdfs", "dfs", "-mkdir", "-p", out_dir])
    mkdir.wait()

    rename = subprocess.Popen(["hdfs", "dfs", "-mv",input_filename, output_filename])
    rename.wait()
    
    delete = subprocess.Popen(["hdfs", "dfs", "-rm",input_filename])
    delete.wait()

    if not check_file(output_filename):
        return False
    return True

def pdf2png(file_img_tuple):
    
    import yarn_logger
    import time
    logger = yarn_logger.YarnLogger(env)
    logger.setup_logger(logger) 
    start_time = time.time()
    
    aux_folder = "/tmp/"
    
    filename = file_img_tuple[0]
    pdf = file_img_tuple[1]
    
    splitted_path = filename.split("/")
    doc_id = splitted_path[-2]
    doc_name = os.path.basename(filename)

    logger.info("pdf2png BEGIN : ")
    logger.info("<o>======================= PDF2PNG with ghostscript for file: " + filename)
    
    ##logger.info("<o>======================= PDF2PNG with ghostscript for file: ")
    
    with tempfile.NamedTemporaryFile(delete=True) as temp:
        logger.info("<o>======================= processing file {} extension {}".format(doc_id, doc_name))
        ##logger.info("<o>======================= processing file {} extension {}".format(doc_id, doc_name))
        temp.write(pdf)
        temp.flush()  
        
        # Define arguments for ghostscript
        args = ["-dNOPAUSE", # Don't ask to continue
            "-dBATCH",
            "-sDEVICE=pnggray",
            "-r300", # Resolution
            "-dQUIET", # Don't print in cmd the information
            "-sProcessColorModel=DeviceGray", # Gray color
            "-sColorConversionStrategy=Gray", # Gray color
            "-dOverrideICC", 
            "-sOutputFile=" +aux_folder+".".join(doc_name.split(".")[:-1])+"_%04d.png",  temp.name] # File names
        
        
        
        try:
            logger.info("<o>======================= Sent to console: "+"gs "+" ".join(args))
            ##logger.info("<o>======================= Sent to console: "+"gs "+" ".join(args))
            os.system("gs "+" ".join(args))
            logger.info("<o>======================= Moving the pngs from local to HDFS ({})".format(config.get('general', 'path-images-input')))
            ##logger.info("<o>======================= Moving the pngs from local to HDFS ({})".format(config.get('general', 'path-images-input')))
            png_generated=[x for x in os.listdir(aux_folder) if (x.endswith(".png") and x.startswith(".".join(doc_name.split(".")[:-1])))] # Select the pngs generated for this pdf
            png_generated=[aux_folder+x for x in png_generated]

            logger.info("Moving  "+aux_folder+"    "+doc_name+"*.png")
            #os.system(" ".join(["hdfs", "dfs", "-copyFromLocal", " ".join(png_generated), config.get('general', 'path-images-input')]))
            os.system(" ".join(["hdfs", "dfs", "-copyFromLocal", aux_folder+".".join(doc_name.split(".")[:-1])+"*.png", config.get('general', 'path-images-input')]))

            for png_aux in png_generated: # Remove from local the png generated
                os.remove(png_aux)
            
            destiny = config.get('general', 'path-pdf-output')+doc_name
            logger.info("hdfs_tools.move_in_hdfs BEGIN "+filename +" TO "+destiny)
            move_in_hdfs(filename,destiny)
            logger.info("hdfs_tools.move_in_hdfs END "+filename +" TO "+destiny)
        except:
            if(filename.lower().endswith(".pdf")):
                print("<o>======================= Unexpected error in file: "+filename)
                #logger.error("<o>======================= Unexpected error in file: "+filename)
            else:
                print("<o>======================= Not a PDF file: "+filename)
                #logger.error("<o>======================= Not a PDF file: "+filename)
    
    logger.info("pdf2png END : ---TIME %s seconds ---" % (time.time() - start_time)+"-MASTER: "+the_master) 
    return 1
        
#######################################################################
if len(sys.argv) > 1:
    env = sys.argv[1]
    print("<o>=============== sent parameters:env "+env+"")
else :
    print("<o>======================= Usage:  spark-submit pdf2png_job.py  <env> (\"local\", \"dev\",...)", file=sys.stderr)
    exit(-1)



config = configparser.RawConfigParser()
config.read(env)

#master=config.get('general', 'spark-master')
app_name=config.get('general', 'app_name')
#master = os.environ['SPARK_MASTER'].split(' ')[1]

#master= sparkSession.sparkContext._jsc.hadoopConfiguration().get("spark.master")

#sparkSession = SparkSession.builder.master(master).appName(app_name).getOrCreate()
sparkSession = SparkSession.builder.appName(app_name).getOrCreate()
sparkSession.sparkContext._jsc.hadoopConfiguration().set("mapreduce.input.fileinputformat.input.dir.recursive","true")


#iterator = sparkSession.sparkContext._jsc.hadoopConfiguration().iterator()
#while iterator.hasNext():
#    prop = iterator.next()
#    item = prop.getValue()
#    key= prop.getKey()
#    print ("ITEM: KEY : "+key+" VALUE : "+item)
iterator = sparkSession.sparkContext.getConf().getAll()

str1 = ''.join(str(e) for e in iterator)
#uuid_key = str(uuid.uuid4())

#log = sparkSession.sparkContext._jvm.org.apache.log4j.Logger
#logger = log.getLogger("PDF2PNG")


logger = yarn_logger.YarnLogger(env)
logger.setup_logger(logger) 

uuid_key = sparkSession.sparkContext.getConf().get("spark.app.id")
the_master = sparkSession.sparkContext.getConf().get("spark.master")
the_client = sparkSession.sparkContext.getConf().get("spark.submit.deployMode")

logger.info("-------------------BEGIN PDF2PNG EXECUTION------KEY: "+uuid_key+"-------------------MASTER: "+the_master)


logger.info("PDF2PNG: SPARK PARAMETERS : MASTER : "+the_master )
logger.info("PDF2PNG: SPARK PARAMETERS : DEPLOY_MODE : "+the_client )
logger.info("PDF2PNG: SPARK PARAMETERS : SPARK_ID : "+uuid_key )


logger.info("PDF2PNG: SPARK PARAMETERS : "+str1+"------KEY: "+uuid_key+"-------------------" )


#current_path = os.path.dirname(os.path.abspath(__file__))

#for file in os.listdir(current_path):
#    if file.endswith(".py"):
#        print(os.path.join(current_path, file))
#        sparkSession.sparkContext.addPyFile(os.path.join(current_path, file))

if __name__ == "__main__":
    main()
