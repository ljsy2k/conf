docker build -t aidoc/livy .
