for D in *; do
    if [ -d "${D}" ]; then
        echo "${D}"   # your processing here
	cd ${D}
	chmod 777 build.sh
	./build.sh
	cd ..
    fi
done
