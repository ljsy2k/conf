docker build -t aidoc/hue .
