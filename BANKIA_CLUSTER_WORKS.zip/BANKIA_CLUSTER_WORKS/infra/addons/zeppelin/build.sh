docker build -t aidoc/zeppelin .
