#!/bin/bash
#  docker build --rm -t puckel/docker-custom-airflow .
docker rm -f airflow_webserver_1
docker rm  -f airflow_postgres_1
#docker rm -f airflow
#docker run -d -p 8090:8090 -v /apps/home/jene/bankia_lawsuits_infrastructure/airflow/apps:/usr/local/airflow/apps -v /apps/home/jene/bankia_lawsuits_infrastructure/airflow/dags:/usr/local/airflow/dags --name airflow -e LOAD_EX=y puckel/docker-custom-airflow webserver
docker-compose -f docker-compose-LocalExecutor.yml up -d
#docker cp config_hdp/* 
