# docker-airflow (1.9)

This repository contains **Dockerfile** of [apache-airflow](https://github.com/apache/incubator-airflow) for [Docker](https://www.docker.com/)'s [automated build](https://registry.hub.docker.com/u/puckel/docker-airflow/) published to the public [Docker Hub Registry](https://registry.hub.docker.com/).

## Informations

* Based on Python (3.6-slim) official Image [python:3.6-slim](https://hub.docker.com/_/python/) and uses the official [Postgres](https://hub.docker.com/_/postgres/) as backend and [Redis](https://hub.docker.com/_/redis/) as queue
* Install [Docker](https://www.docker.com/)
* Install [Docker Compose](https://docs.docker.com/compose/install/)
* Following the Airflow release from [Python Package Index](https://pypi.python.org/pypi/apache-airflow)

## Installation

* docker build --rm -t puckel/docker-custom-airflow .
* docker-compose -f docker-compose-LocalExecutor.yml up -d
* Change default spark.default in connections from yarn to spark://master:9000

NB : If you want to have DAGs example loaded (default=False), you've to set the following environment variable :

`LOAD_EX=n`

If you want to use Ad hoc query, make sure you've configured connections:
Go to Admin -> Connections and Edit "postgres_default" set this values (equivalent to values in airflow.cfg/docker-compose*.yml) :
- Host : postgres
- Schema : airflow
- Login : airflow
- Password : airflow

# UI management

* Include dags to $AIRFLOW_HOME
* add new dags `python dag-file.py` and wait until admin load the new file
* run dag from dag list (activate (Off->On)
* log it (click running link, press the dag element and click on View Log)

# Services

airflow       1      0  4 11:45 ?        00:00:01 /usr/local/bin/python /usr/local/bin/airflow webserver

airflow      21      1  1 11:45 ?        00:00:00 gunicorn: master [airflow-webserver]

airflow      27     21  1 11:45 ?        00:00:00 [ready] gunicorn: worker [airflow-webserver]

airflow      28     21  1 11:45 ?        00:00:00 [ready] gunicorn: worker [airflow-webserver]

airflow      36     21  2 11:45 ?        00:00:01 [ready] gunicorn: worker [airflow-webserver]

airflow     104     58  4 11:46 pts/0    00:00:00 /usr/local/bin/python /usr/local/bin/airflow scheduler [xN]

airflow     115     21 10 11:46 ?        00:00:01 [ready] gunicorn: worker [airflow-webserver]

## Custom Airflow plugins

Airflow allows for custom user-created plugins which are typically found in `${AIRFLOW_HOME}/plugins` folder. Documentation on plugins can be found [here](https://airflow.apache.org/plugins.html)

In order to incorporate plugins into your docker container
- Create the plugins folders `plugins/` with your custom plugins.
- Mount the folder as a volume by doing either of the following:
    - Include the folder as a volume in command-line `-v $(pwd)/plugins/:/usr/local/airflow/plugins`
    - Use docker-compose-LocalExecutor.yml or docker-compose-CeleryExecutor.yml which contains support for adding the plugins folder as a volume

## Install custom python package

- Create a file "requirements.txt" with the desired python modules
- Mount this file as a volume `-v $(pwd)/requirements.txt:/requirements.txt` (or add it as a volume in docker-compose file)
- The entrypoint.sh script execute the pip install command (with --user option)

## UI Links

- Airflow: [localhost:8090](http://localhost:8090/)

## Running other airflow commands

If you want to run other airflow sub-commands, such as `list_dags` or `clear` you can do so like this:

    docker run --rm -ti puckel/docker-airflow airflow list_dags

You can also use this to run a bash shell or any other command in the same environment that airflow would be run in:

    docker run --rm -ti puckel/docker-airflow bash
    docker run --rm -ti puckel/docker-airflow ipython

