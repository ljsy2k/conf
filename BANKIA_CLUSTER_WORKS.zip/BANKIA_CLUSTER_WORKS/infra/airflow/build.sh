#!/bin/bash
cp -R /apps/home/jene/bankia_lawsuits_architecture/docker-standalone/common/config ./config_hdp
docker build --rm -t puckel/docker-custom-airflow .
rm -rf config-hdp
