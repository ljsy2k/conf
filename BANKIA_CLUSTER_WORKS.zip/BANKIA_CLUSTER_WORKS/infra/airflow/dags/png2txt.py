from airflow import DAG

from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator
from datetime import datetime, timedelta


args = {
    'owner': 'airflow',
    'start_date': datetime(2018, 9, 1)
}
dag = DAG('png2txt', default_args=args, schedule_interval="*/10 * * * *")

operator = SparkSubmitOperator(
    task_id='png2txt',
    conn_id='spark_default',
    #java_class='org.apache.spark.examples.SparkPi',
    application='/usr/local/airflow/apps/ocr-tesseract4-py/ocr_images_spark.py',
    application_args=['local','/usr/local/airflow/apps/ocr-tesseract4-py/'],
    total_executor_cores='1',
    executor_cores='1',
    executor_memory='2g',
    num_executors='1',
    name='png2txt',
    verbose=True,
    driver_memory='1g',
    #application_args=["1000"],
    #conf={'master':'spark://master:7077'},
    run_as_user='airflow',
    dag=dag,
)

