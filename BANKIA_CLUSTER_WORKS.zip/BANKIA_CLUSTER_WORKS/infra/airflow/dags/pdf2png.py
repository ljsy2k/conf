from airflow import DAG

from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator
from datetime import datetime, timedelta


args = {
    'owner': 'airflow',
    'start_date': datetime(2018, 9, 1)
}
dag = DAG('pdf2png', default_args=args, schedule_interval="*/10 * * * *")

operator = SparkSubmitOperator(
    task_id='pdf2png',
    conn_id='spark_default',
    #java_class='org.apache.spark.examples.SparkPi',
    application='/usr/local/airflow/apps/pdf2png/pdf2png_job.py',
    application_args=['/usr/local/airflow/apps/pdf2png/'],
    total_executor_cores='1',
    executor_cores='1',
    executor_memory='2g',
    num_executors='1',
    name='pdf2png',
    verbose=True,
    driver_memory='1g',
    #application_args=["1000"],
    #conf={'master':'spark://master:7077'},
    run_as_user='airflow',
    dag=dag,
)

