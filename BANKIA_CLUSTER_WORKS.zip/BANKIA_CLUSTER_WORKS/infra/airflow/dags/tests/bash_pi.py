# airflowRedditPysparkDag.py
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta
import os



## Define the DAG object
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2016, 10, 15),
    'retries': 5,
    'retry_delay': timedelta(minutes=1),
    'run_as_user': 'airflow'
}
dag = DAG('s3RedditPyspark', default_args=default_args, schedule_interval=timedelta(1))


operator = BashOperator(
    task_id='sparkPi',
    bash_command='whoami;pwd;env',
    #bash_command='/usr/local/spark/bin/spark-submit --class org.apache.spark.examples.SparkPi --driver-java-options "-Djava.library.path=/usr/local/spark/python/lib/:/usr/local/spark/yarn/:/usr/local/spark/jars/" --conf "driver-java-options=-Djna.library.path=/usr/local/spark/python/lib/:/usr/local/spark/yarn/:/usr/local/spark/jars/" --conf "driver-library-path=/usr/local/spark/python/lib/:/usr/local/spark/yarn/:/usr/local/spark/jars/" /usr/local/spark/examples/jars/spark-examples_2.11-2.3.0.jar',
    dag=dag)

