from airflow import DAG

from airflow.contrib.operators.spark_submit_operator import SparkSubmitOperator
from datetime import datetime, timedelta


args = {
    'owner': 'airflow',
    'start_date': datetime(2018, 9, 1)
}
dag = DAG('spark_example_new', default_args=args, schedule_interval="*/10 * * * *")

operator = SparkSubmitOperator(
    task_id='spark_submit_job',
    conn_id='spark_default',
    java_class='org.apache.spark.examples.SparkPi',
    application='/usr/local/spark/examples/jars/spark-examples_2.11-2.3.0.jar',
    #driver_classpath='/usr/local/spark/python/lib/:/usr/local/spark/jars/:/usr/local/spark/yarn/',
    #packages='/usr/local/spark/yarn/spark-2.3.0-yarn-shuffle.jar',
    #jars='/usr/local/spark/yarn/spark-2.3.0-yarn-shuffle.jar',
    #repositories='/usr/local/spark/yarn/spark-2.3.0-yarn-shuffle.jar',
    #total_executor_cores='1',
    #total_executor_cores='1',
    #executor_cores='1',
    #executor_memory='2g',
    #num_executors='1',
    name='airflow-spark-example',
    verbose=True,
    #driver_memory='1g',
    #application_args=["1000"],
    conf={'master':'spark://master:7077'},
    run_as_user='airflow',
    dag=dag,
)

