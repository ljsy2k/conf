# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 13:22:13 2018

@author: dlri
"""

# Import modules

from first_page import getModel as getModel_first_page
from first_page import getClassification as getClassification_pages
from first_page import textPreprocessing # We need this import to load the first_page model
from entity_extraction import getModel as getModel_entities
from entity_extraction import getClassification as getClassification_entities
from entityPostprocessing import postProcessEntities

path_modelo_entities = "models/_all-mask-weights-improvement-64neurons-weighted-embedding300-nonoise-noaug-CV2-19-0.00.hdf5"
path_modelo_primera_pagina = "models/rf_50__LSI_100_balanced_probabilityTrue_1_2_min_df_5_l2_python3.pkl"

# Load models
#model_first_page = getModel_first_page(path_modelo_primera_pagina)
#model_entity_extraction = getModel_entities(path_modelo_entities)
model_first_page = ""
model_entity_extraction = ""
def pipeline_entExt(doc,model_first_page=model_first_page,model_entity_extraction=model_entity_extraction):
    # Get first page
    output_model_first_page = getClassification_pages(model_first_page,doc,useModel=False)
    # Get entities
    output_model_entities = getClassification_entities(model_entity_extraction,output_model_first_page[0],output_model_first_page[1])
    return postProcessEntities(output_model_entities[0],output_model_entities[1],output_model_entities[2])