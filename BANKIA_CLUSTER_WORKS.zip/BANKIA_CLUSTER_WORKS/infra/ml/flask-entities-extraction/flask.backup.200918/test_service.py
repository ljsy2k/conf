# -*- coding: utf-8 -*-
"""
Created on Mon Feb 19 09:13:15 2018

@author: dlri
"""

import json
import urllib3

json_file="doc_example.json"


def read_json(jpath):
    """Reads a json file and reutrns the data
    
    Keyword arguments:
        jpath: json file path
    """
    f = open(jpath, 'r', encoding="utf-8")
    datatxt = f.read()
    data_json = json.loads(datatxt, encoding="utf-8") # Json format
    f.close()
    return data_json


http = urllib3.PoolManager()

encoded_body = json.dumps(read_json(json_file))  #read_json(json_file)

#r = http.request('POST', 'http://localhost:5001/doc-classification/v1.0/', headers={'Content-Type': 'application/json'}, body=encoded_body)
r = http.request('POST', 'http://localhost:5002/doc-entity-extraction/v1.0/', headers={'Content-Type': 'application/json'}, body=encoded_body)
#r = http.request('POST', 'http://aidoc-01.gft.com:5002/doc-entity-extraction/v1.0/', headers={'Content-Type': 'application/json'}, body=encoded_body)

json.loads(r.data, encoding="utf-8") 
