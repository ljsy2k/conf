# -*- coding: utf-8 -*-
"""
Created on Wed Feb 14 08:41:25 2018

@author: dlri
"""

from hashlib import md5
import string
import re

import numpy as np

from nltk.stem import SnowballStemmer

from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Embedding, LSTM, Bidirectional, TimeDistributed
from keras.preprocessing.text import text_to_word_sequence
from keras.optimizers import RMSprop

def one_hot(text, n,
            filters='!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~\t\n',
            lower=True,
            split=' '):
    """One-hot encodes a text into a list of word indexes of size n.
    This is a wrapper to the `hashing_trick` function using `hash` as the
    hashing function, unicity of word to index mapping non-guaranteed.
    """
    return hashing_trick(text, n,
                         hash_function='md5',
                         filters=filters,
                         lower=lower,
                         split=split)

def hashing_trick(text, n,
                  hash_function=None,
                  filters='!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~\t\n',
                  lower=True,
                  split=' '):
    """Converts a text to a sequence of indexes in a fixed-size hashing space.
    # Arguments
        text: Input text (string).
        n: Dimension of the hashing space.
        hash_function: if `None` uses python `hash` function, can be 'md5' or
            any function that takes in input a string and returns a int.
            Note that `hash` is not a stable hashing function, so
            it is not consistent across different runs, while 'md5'
            is a stable hashing function.
        filters: Sequence of characters to filter out.
        lower: Whether to convert the input to lowercase.
        split: Sentence split marker (string).
    # Returns
        A list of integer word indices (unicity non-guaranteed).
    `0` is a reserved index that won't be assigned to any word.
    Two or more words may be assigned to the same index, due to possible
    collisions by the hashing function.
    The [probability](https://en.wikipedia.org/wiki/Birthday_problem#Probability_table)
    of a collision is in relation to the dimension of the hashing space and
    the number of distinct objects.
    """
    if hash_function is None:
        hash_function = hash
    elif hash_function == 'md5':
        hash_function = lambda w: int(md5(w.encode()).hexdigest(), 16)

    seq = text_to_word_sequence(text,
                                filters=filters,
                                lower=lower,
                                split=split)
    return [(hash_function(w) % (n - 1) + 1) for w in seq]

def cleaning(str_):
    '''Removes from the text some characters
    
    Keyword arguments:
        str_: text to preprocess'''
        
    FILTERED_SIGNS = string.punctuation + "¿¡“—"#"1234567890¿¡“—"
    for sign in FILTERED_SIGNS:   
        str_ = str_.replace(sign,"")
    while "  " in str_:
        str_ = str_.replace("  "," ")
        
    return str_

def cut(str_, textLength = 800):
    '''Cuts the text to an specified lenght (in chars)
    
    Keyword arguments:
        str_: text to cut
        textLength: desired length'''
    str_ = str_[0:textLength]
    str_ = str_[0:len(str_)-str_[::-1].find(" ")-1] #Make sure we don´t cut words
    return str_

def prepareInput(doc,mapCommas = False):
    '''Preprocessing of text to meet the requeriments of the classification 
    model. Maps some characters to a word and cuts the document to meet some 
    desired length
        
    Keyword arguments:
        doc: Text to preprocess
        mapCommas: Whether or not we want to map the commas'''
        
    doc = cut(doc)
    if mapCommas:
        doc = doc.replace(", ", " comma ")
        
    doc = doc.replace("\n", " newline ")
    doc = cleaning(doc)
    doc = doc.strip()
    return (doc)

def textPreprocessing(string):
    '''Preprocessing of text to meet the requeriments of the classification 
    model
        
    Keyword arguments:
        string: Text to preprocess'''
        
    #string = ''.join((c for c in unicodedata.normalize('NFD', unicode(string)) if unicodedata.category(c) != 'Mn'))
    token_pattern=r"(?u)\b\w\w+\b"
    pattern = re.compile(token_pattern)
    tokens = pattern.findall(string)
    
    stemmer = SnowballStemmer('spanish')

    stemmed_text = [stemmer.stem(i) for i in tokens]
    return stemmed_text

def getModel(path,max_features = 50000,maxlen = 512,batch_size = 128):
    '''Loads the model that performs the named entity recognition 
        
    Keyword arguments:
        path: path to the file that contains the weights of the model
        max_features: (integer) number of words in the embedding matrix
        maxlen: (integer) maximum length in words of the text
        batch_size: (integer) number of pages to process in a batch'''
        
    opt = RMSprop(lr=0.001, rho=0.9, epsilon=1e-08, decay=0.0)

    model = Sequential()
    model.add(Embedding(max_features, 300, input_length=maxlen, mask_zero=True))
    model.add(Bidirectional(LSTM(64,return_sequences=True)))
    model.add(TimeDistributed(Dense(8, activation='softmax')))
    
    model.compile(opt, 'mse', metrics=['categorical_accuracy'],sample_weight_mode="temporal")
    
    model.load_weights(path)
    
    return model

def getClassification(model,doc,pages,max_features = 50000, maxlen = 512):
    '''Returns the list of words that contains the document and a list of 
    probability values for each entity and each word. 
        
    Keyword arguments:
        model: model object previously loaded
        doc: (string) document to be analyzed
        max_features: (integer) number of words in the embedding matrix
        maxlen: (integer) maximum length in words of the text'''

    doc_preprocessed = prepareInput(doc)
    word_list = doc_preprocessed.lower().split(" ")
    #doc_preprocessed = textPreprocessing(doc_preprocessed)
    doc_preprocessed_onehot = list(map(lambda x: one_hot(x,max_features),word_list))
    original_len = len(doc_preprocessed_onehot)
    doc_preprocessed = sequence.pad_sequences([doc_preprocessed_onehot], maxlen=maxlen)
    doc_preprocessed=[doc_preprocessed[0][idx][0] for idx in range(len(doc_preprocessed[0]))]
    pages_list = [pages]*len(word_list) # TODO: Now is a dummy variable,
    
    return(word_list,model.predict_proba(np.array([doc_preprocessed]))[0][(maxlen-original_len):],pages_list)



