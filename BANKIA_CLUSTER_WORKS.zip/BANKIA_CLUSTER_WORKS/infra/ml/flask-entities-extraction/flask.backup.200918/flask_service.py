# -*- coding: utf-8 -*-

from flask import Flask, request
import flask
#import settings
from first_page import textPreprocessing # We need this import to load the first_page model
from pipeline import pipeline_entExt

import pipeline

USE_MODELS = False
app = Flask(__name__)

@app.route('/doc-entity-extraction/v1.0/', methods=['POST'])

def classification():
    request.get_json(force=True)
    
    
    if "doc" not in request.json:
        return  "Invalid request."
    result = {}
    try:
        
        #Read json pages and append them in a list
        list_pages=list()
        document = request.json["doc"]
        for page in document.split("SALTOPAGINA"):
            #print("DATA RECEIVED:", request.json["doc"][page])
            list_pages.append(page)
        
        # Execute the pipeline
        if USE_MODELS:
            result = pipeline.pipeline_entExt(list_pages)
        else:
            result = {'numero_procedimiento': [{'value':'0003321254', 'page':'1'}],
                      'abogado': [{'value':'Pedro Ruiz Escobar', 'score':'0.976276', 'page':'1'}],
                     'dni_otros_demandantes': [{'value':'23663210P', 'score':'0.626901', 'page':'1'}],
                     'dni_primer_demandante': [{'value':'74885633A', 'score':'0.966948', 'page':'1'}],
                     'juzgado': [{'value':'Juzgado De Primera Instancia De Valencia', 'score':'0.998645', 'page':'1'}],
                     'otros_demandantes': [{'value':'Carla Gutiérrez Blanco', 'score':'0.778814', 'page':'1'}],
                     'primer_demandante': [{'value':'Carlos Santos Vázquez', 'score':'0.98077', 'page':'1'}],
                     'procurador': [{'value':'Julia Torres Domínguez', 'score':'0.8357', 'page':'1'}]}
        print(result)
        
    except Exception as e:
        print("ERROR: ")
        print(e)

    return flask.jsonify(result)

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5002)
