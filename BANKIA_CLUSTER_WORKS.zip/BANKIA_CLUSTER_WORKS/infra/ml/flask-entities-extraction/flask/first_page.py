# -*- coding: utf-8 -*-
"""
Created on Tue Feb 13 17:47:17 2018

@author: dlri
"""

#path_modelo = "models/rf_50__LSI_100_balanced_probabilityTrue_1_2_min_df_5_l2_python3.pkl"
#modelo_first_page = loadModel(path_modelo)

#getClassification(ejemplo_doc,modelo_first_page,useModel=False)


import numpy as np
from sklearn.externals import joblib

from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer
from nltk.tokenize import RegexpTokenizer

def textPreprocessing(string):
    '''Preprocessing of text to meet the requeriments of the classification 
    model
        
    Keyword arguments:
        string: Text to preprocess'''
        
    tokenizer = RegexpTokenizer(r'\w+')
    tokens = tokenizer.tokenize(string)
    stemmer = SnowballStemmer('spanish')
    stemmed_text = [stemmer.stem(i) for i in tokens]
    return stemmed_text

def getModel(pathModelo):
    '''Loads a model from a path
        
    Keyword arguments:
        pathModelo: Path in which the model is stored'''
    return joblib.load(pathModelo)

def getClassification(model, listPages, thresh = 0, useModel = True):
    '''Returns the page with the highest probability of being the first 
    page if this probability is higher than the threshold. For development 
    uses, useModel can be flagged to False, and the output will be always 
    the first page of the list. 
        
    Keyword arguments:
        listPages: list of pages
        model: model object previously loaded
        thresh: (float from 0 to 1) probability threshold to consider a 
                page as candidate to be a first_page
        useModel: (boolean) if True, the output will use the model 
                  classification, if False, the output will be the first 
                  page of the list listPages'''
                  
    #classif_first_pages = modelo_first_page.predict(list_pages)
    #index_first_pages = np.where(classif_first_pages == "first_page")[0]
    #if len(index_first_pages)>0:
    #    return [list_pages[idx] for idx in index_first_pages]
    # print('listPages',listPages)
     
    classif_first_pages = model.predict_proba(listPages)
    
    #print('classif_first_pages',classif_first_pages)
    
    probs_first_page=[classif_first_pages[idx][0] for idx in range(len(classif_first_pages))]
    index_first_pages = np.argmax(probs_first_page)
    if useModel:
        if probs_first_page[index_first_pages] >= thresh:
            return (listPages[index_first_pages],index_first_pages)
    else:
        return (listPages[0],index_first_pages)
    



