# -*- coding: utf-8 -*-
import numpy as np 
from collections import defaultdict
import distance
import unidecode

lista_entidades=list(reversed(['none','juzgado','procurador','primer_demandante','dni_primer_demandante','otros_demandantes','dni_otros_demandantes','abogado']))   

def tokenSequences2Entity(l,doc):
    
    scores = []
    means = []
    lists = []
    newL = []
    split = False
    for i,(num,score) in enumerate(l):
        newL.append(num)
        scores.append(score)
        
        if i < len(l)-1:
            if num -l[i+1][0] < -2:
                lists.append(newL)               
                means.append(np.mean(scores))
                
                newL= []
                scores = []
        else:
            lists.append(newL)
            scores.append(score)
            means.append(np.mean(scores))
    results = []
    
    for entityIndices,entityScore  in list(sorted(zip(lists,means),reverse = True, key = lambda x: x[1])):

        
        firstEntityPos = entityIndices[0] 
        lastEntityPos = entityIndices[-1]

        postProcessedEntity = " ".join(doc.split(" ")[firstEntityPos:lastEntityPos+1])
        postProcessedEntity = postProcessedEntity.replace("newline", "")
        postProcessedEntity = postProcessedEntity.replace("comma", "")
        while ("  " in postProcessedEntity):
            postProcessedEntity =postProcessedEntity.replace("  ", " ")
        results.append((postProcessedEntity,entityScore,firstEntityPos))
    return results
    
    
    
def getDecision(l):
    return lista_entidades[np.argmax(l)],max(l) 

def compareWithDB(name,db):
    nameNoAccents = unidecode.unidecode(name)
    (levScore,candidateName) = sorted(map(lambda db_name: (distance.levenshtein(nameNoAccents,unidecode.unidecode(db_name)),db_name)
                                                  ,db)
                                        ,reverse=False)[0]
    
    candidateNameNoAccents = unidecode.unidecode(candidateName)
    
    print ("candidates: NAME ",nameNoAccents,"----- CANDIDATE ",candidateNameNoAccents," ------ SCORE ",levScore)
    
    if nameNoAccents in candidateNameNoAccents:
        return candidateName
    
    if levScore<=3:
        return candidateName
    
    return name

def postProcessEntities(words,scores,pages):
    results = defaultdict(lambda : [])
    for entity in ['juzgado','procurador','primer_demandante','dni_primer_demandante','otros_demandantes','dni_otros_demandantes','abogado']:
        entities = []
        for index,score in enumerate(scores):
            decision, prob= getDecision(score)
            if  decision == entity:
                entities.append((index,prob))


        if len(entities)>0:
            for name,score,first_position in tokenSequences2Entity(entities," ".join(words)):
                ent_name = ents[entity]
                results[ent_name].append({"value": name.title(),
                                        "score":str(score),
                                        "page":str(pages[first_position]+1)})
                
                 #results[ent_name].append({"value": compareWithDB(name.title(),namesDB),
                 #                       "score":str(score),
                 #                       "page":str(pages[first_position]+1)})
                
        else:
            #results[entity] = []
            print("entity not found",entity) 
            
    results["procedure"].append({"value":"-",
                                 "score":"1",
                                 "page":str(pages[first_position]+1)})
    return dict(results)


namesDB = ["Julia Torres Domínguez",
           "Carlos Santos Vazquez",
           "Carla Gutierrez Blanco",
           "Antonio Cases Sala",
           "Javier Ortunio Llorente"]

ents = dict({"juzgado":"court", "procurador":"attorney","primer_demandante":"firstApplicant","dni_primer_demandante":"firstApplicantId","otros_demandantes":"secondApplicant","dni_otros_demandantes":"secondApplicantId","abogado":"lawyer"}) 
        
#Example:
#data = pickle.load(open("./example_entity_extraction.pkl","rb"))
#postProcessEntities(data[0],data[1])