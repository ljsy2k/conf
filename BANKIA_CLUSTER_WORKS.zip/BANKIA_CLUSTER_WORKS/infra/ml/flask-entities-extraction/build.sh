#!/bin/bash
docker build -t aidoc/flask-entities-extraction -f Dockerfile .
#docker stop flask-entities-extraction
#docker rm flask-entities-extraction
#docker run -it --name=flask-entities-extraction -p 5002:5002 flask-entities-extraction

