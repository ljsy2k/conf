Flask service running the document classification algorithm (classifier.py), which uses sklearn (tfidf vectorizer) and xgboost classifier.

Dockerfile installs:
* Debian 8
* Anaconda3 5.0.1 (which includes Python 3.6 with scikit-learn 0.19.1)
* matplotlib 2.1.2
* Flask 
* numpy 
* pandas 0.22.0
* scipy 1.0.0
* scikit-learn 0.19.1
* tensorflow 1.1.0
* keras 2.1.3
* nltk 3.2.4
* distance 0.1.3
* unidecode 0.4.21
* h5py 2.7.1

To build the Docker image:
> docker build -t ml_entity_extraction -f .

To run the Docker image and start the flask:
> docker run --rm -p 5001:5001 -i -t ml_entity_extraction

