###################################

#Description.

#Flask service.

###################################

from flask import Flask, request
import flask
from classifier.alg_002.classifier import classifier
app = Flask(__name__)

@app.route('/doc-classification/v1.0/', methods=['POST'])
def process_doc_request():
    request.get_json(force=True)

    if "doc" not in request.json:
        return  "Invalid request."

    #Initialise classifier.
    doc_class=classifier()

    #Tokenize text into words.
    words_list=doc_class.tokenize(request.json["doc"])

    #Create vectors.
    X_vec=doc_class.vectorize(words_list)

    #Classify vectors into classes.
    classes,probs=doc_class.classify(X_vec)

    result = {}
    sorti = probs.argsort()[::-1]
    print("Categories sorted by probability:\n")
    for class_i in range(len(classes)):
        prob = probs[sorti][class_i]
        print("%s: %.3f %%" % (classes[sorti][class_i], prob * 100))
        result["%s" % classes[sorti][class_i]] = "%.6f" % prob

    y_pred = classes[sorti][0]
    print("\nPredicted class: %s." % (y_pred))

    return flask.jsonify(result)

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5001)