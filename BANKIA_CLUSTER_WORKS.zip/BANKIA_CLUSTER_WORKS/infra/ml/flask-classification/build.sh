#!/bin/bash
docker build -t aidoc/flask-classification -f Dockerfile .
#docker stop flask-classification
#docker rm flask-classification
#docker run -it --name=flask-classification -p 5001:5001 flask-classification

