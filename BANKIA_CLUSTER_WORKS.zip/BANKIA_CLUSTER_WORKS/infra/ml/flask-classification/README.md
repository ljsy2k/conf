Flask service running the document classification algorithm (classifier.py), which uses sklearn (tfidf vectorizer) and xgboost classifier.

Dockerfile installs:
Debian 8
Anaconda3 5.0.1 (which includes Python 3.6 with scikit-learn 0.19.1)
py-xgboost 0.60
unidecode 0.04.21

To build the Docker image:
> docker build -t ml_classifier -f .\Dockerfile .

To run the Docker image:
> docker run --rm -p 5001:5001 -i -t ml_classifier
