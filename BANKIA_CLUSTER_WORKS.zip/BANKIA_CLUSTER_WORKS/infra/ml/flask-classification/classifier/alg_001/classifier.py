###################################

#Description.

#Simple script that loads a document (output of Tesseract OCR) and prints its category, using an already trained model.

###################################

#Import all necessary modules.

import sys, re, argparse, pickle, time
import numpy as np
import xgboost as xgb
from sklearn.feature_extraction.text import TfidfVectorizer
sys.path.insert(0,"./classifier/alg_001/")
from common.nltk_stopwords_spanish import stopwords
from unidecode import unidecode

###################################

class classifier:
    '''Class for a document.'''

    def __init__(self):
        # Default inputs.
        self.min_length_word = 3  # Minimum number of characters that a word (or a number) must have to be considered.
        self.max_length_word = 23  # Maximum number of characters that a word (or a number) must have to be considered.
        self.min_length_doc = 10  # Minimum number of characters that a document must have to be considered.
        self.modelfolder = "./classifier/alg_001/models/"
        self.pattern = re.compile(r"(?u)\b\w\w+\b")  # This is taken from: https://stackoverflow.com/questions/29290955/token-pattern-for-n-gram-in-tfidfvectorizer-in-python
        self.stop_words = stopwords

    def tokenize(self,text):
        if len(text) > self.min_length_doc:
            words_list = [word for word in self.pattern.findall(unidecode(text).lower().replace("_", " ")) if
                          (len(word) > self.min_length_word) & (len(word) < self.max_length_word) & (word not in self.stop_words)]
        else:
            print("Document is too short!")
            words_list = []
        return words_list

    def vectorize(self, words_list):
        tfidf_model = pickle.load(open(self.modelfolder + "tfidf.pickle", "rb"))
        X_vec = tfidf_model.transform([words_list])
        return X_vec

    def classify(self,X_vec):
        xgb_model = pickle.load(open(self.modelfolder + "xgb.pickle", "rb"))
        classes=xgb_model.classes_
        probs = xgb_model.predict_proba(X_vec.todense())[0]
        return classes, probs

