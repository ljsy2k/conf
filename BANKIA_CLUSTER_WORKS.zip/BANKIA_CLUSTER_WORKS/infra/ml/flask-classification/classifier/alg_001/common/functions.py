###################################

#Description.

#Common functions used in other scripts.

###################################

#Import necessary modules.

import numpy as np
import os, sys, importlib, datetime, pickle

###################################

#Define functions.

def load_all_data(DOCS_FILE):
    '''Load all data.'''
    labels,words=[],[]
    with open(DOCS_FILE,"r") as f:
        for i,line in enumerate(f):
            cols = line.strip('\n').split(',')
            labels.append(cols[0])
            words.append(cols[1].split(' '))
    #Output data for playground (so that test set is excluded) and indices for training and cv of this fold.
    data = {'words': np.array(words,dtype=object), 'labels': np.array(labels,dtype=object)}
    return data

def load_fold(data,run):
    '''Load playground data and indices of training and cv sets for a given fold (specified in run).'''
    #Load indices of desired dataset.
    ds=importlib.import_module("pars")
    if run.fold=='TEST':
        pg_ind, test_ind = ds.pg_ind, ds.test_ind
        data_pg={'words':data['words'][pg_ind], 'labels':data['labels'][pg_ind]}
        data_test={'words':data['words'][test_ind], 'labels':data['labels'][test_ind]}
        return data_pg, data_test
    else:
        train_ind,cv_ind=eval('ds.train_ind_%s' %run.fold), eval('ds.cv_ind_%s' %run.fold)
        data_train={'words':data['words'][train_ind], 'labels':data['labels'][train_ind]}
        data_cv={'words':data['words'][cv_ind], 'labels':data['labels'][cv_ind]}
        return data_train, data_cv

def run_status(RUNSFOLDER):
    '''Find current status of runs inside "RUNSFOLDER".'''
    runslist=np.array([run for run in os.listdir(RUNSFOLDER) if (run[0:3] == 'run') & (run[-3:] == '.py')])
    runsnames=np.empty(len(runslist), dtype=object)
    status=np.empty(len(runslist), dtype=object)
    folds=np.empty(len(runslist), dtype=object)

    for run_i in range(len(runslist)):
        filename=runslist[run_i]
        folds[run_i]=filename.split('.')[0].split('_')[-1]
        runsnames[run_i]=int(runslist[run_i].split('_')[1])
        f = open(RUNSFOLDER + filename, "r")
        for line in f:
            if line.startswith("#STATUS:waiting"):
                status[run_i] = "waiting"
            if line.startswith("#STATUS:running"):
                status[run_i] = "running"
            if line.startswith("#STATUS:done"):
                status[run_i] = "done"

    #return runslist,status
    return runsnames, status, folds

def display_final_score(score_array,score_name,parlist,parlist_plot,parmat,top_runs,details):
    '''Optimal way to display results of check_status.py.'''

    #Shorten label in case it is too long.
    parlist_plot_label=[]
    for label in parlist_plot:
        if len(label)>15:
            #parlist_plot_label.append(">"+"_".join([word[0] for word in label.split("_")])+"<")
            parlist_plot_label.append(">" + "_".join([word[0] if not word.isdigit() else word for word in label.split("_")]) + "<")
        else:
            parlist_plot_label.append(label)

    mean_score=np.mean(score_array[score_name],axis=1)
    std_score=np.std(score_array[score_name],axis=1)
    sort_i = mean_score.argsort()[::-1] #Sort results by desired score.

    print("\nTop %i runs sorted by %s:" %(top_runs,score_name))
    print("\n%9s|%9s|%9s|  run|  folds|" % ('precision','recall','f1') + '|'.join(['%15s' % par_j for par_j in parlist_plot_label]) + "|")

    alg_ind = np.where(np.array(parlist) == 'algorithm')[0][0] #Index where algorithm of a run is defined.
    classes=score_array['classes']
    for top_i in range(top_runs):
        line_scores='    %.3f|    %.3f|    %.3f|' % (np.mean(score_array['precision'],axis=1)[sort_i][top_i],np.mean(score_array['recall'],axis=1)[sort_i][top_i],np.mean(score_array['f1'],axis=1)[sort_i][top_i])
        line_runs='%.5i|' %score_array['run'][sort_i][top_i]
        line_folds='%7s|' % (','.join(score_array['fold'][sort_i][top_i]))
        #line_time=' %.3f|' % (score_array['testing_time'][sort_i][top_i])

        #Show only relevant parameters for each algorithm.
        algor = parmat[sort_i][top_i][alg_ind]  # Algorithm of this run.
        line_pars=""
        for par_j in range(len(parlist_plot)):
            ind=np.where(parlist==parlist_plot[par_j])[0][0]
            if (parlist[ind].startswith(algor)) or (parlist[ind]=='algorithm'):
                line_pars+='%15s' % str(parmat[sort_i][top_i][ind])
            else:
                line_pars+='%15s' %"-"
            line_pars += "|"
        #line=line_scores+line_time+line_runs+line_folds+ line_pars
        line = line_scores + line_runs + line_folds + line_pars
        print(line)
        if details==1:
            for class_i in range(len(classes)):
                #print('      ->%s: %.3f' %(classes[class_i],score_array[score_name][sort_i][top_i][class_i]))
                print('      ->%30s: precision %.3f, recall %.3f, f1 %.3f' %(classes[class_i],score_array['precision'][sort_i][top_i][class_i],score_array['recall'][sort_i][top_i][class_i],score_array['f1'][sort_i][top_i][class_i]))

'''
def display_individual_score(score_array,score_name,parlist,parmat,top_runs,details):
    print "\nTop %i runs:" %top_runs
    print "\n%14s |  run|fold| " %('Mean '+score_name)+ '|'.join(['%20s' % par_j for par_j in parlist])
    classes=score_array['classes']
    mean_score=np.mean(score_array[score_name],axis=1)
    std_score=np.std(score_array[score_name],axis=1)
    sort_i = mean_score.argsort()[::-1]
    for top_i in range(top_runs):
        print '%.3f (%.3f)  |%.5i|%4s|' % (mean_score[sort_i][top_i], std_score[sort_i][top_i], score_array['run'][sort_i][top_i], score_array['fold'][sort_i][top_i]), '|'.join(
            ['%20s' % par_j for par_j in parmat[sort_i][top_i]])
        if details:
            for class_i in range(len(classes)):
                print '      ->%s: %.3f' %(classes[class_i],score_array[score_name][sort_i][top_i][class_i])
'''

def check_distribution_classes(labels):
    '''Check that distribution of classes is as expected.'''
    classes = np.unique(labels)
    for class_i in range(len(classes)):
        pct = len(labels[labels == classes[class_i]]) * 100. / len(labels)
        print ('    Class: %s, Percentage: %.3f %%' % (classes[class_i], pct))

def check_if_run_exists(algor, runslist,dicti):
    '''Check if there is any run inside "runslist" that has the exact set of parameters in dictionary "dicti".'''
    numpars=len(dicti.keys())
    check=False #Start by assuming that run does not exist.
    for run in runslist:
        numsame = 0 #Number of parameters that coincide for this run.
        pars=importlib.import_module("runs.%s" %run.strip('.py'))
        pars=importlib.reload(pars) #Just in case pars is not updated.
        if pars.algorithm==algor:
            for key in dicti.keys():
                if (dicti[key]==eval("pars.%s" % key)): #This parameter coincides.
                    numsame+=1
                else: #This parameter does not coincide, hence move to next run.
                    break
        if numsame==numpars: #If all parameters coincide for one run, then run already exists, stop looking.
            check=True
            break
    return check

def get_execution_time(path_to_run_file):
    '''Outputs duration of the run in seconds (old runs did not have information about seconds). The run file has to be "done", otherwise it will not work.'''
    with open(path_to_run_file, "r") as f:
        for line in f:
            if line.startswith('#STATUS:running'):
                date = np.array(line.split('DATE:')[1].split(' #TIME:')[0].split('-')).astype(int)
                hhmm = np.array(line.split('DATE:')[1].split(' #TIME:')[1].split(' #MACHINE: ')[0].split(':')).astype(int)
                #mach = line.split('DATE:')[1].split(' #TIME:')[1].split(' #MACHINE: ')[1]
                if len(hhmm)==2: #For old run files, where time did not include seconds.
                    start_time = datetime.datetime(date[0], date[1], date[2], hhmm[0], hhmm[1], 0)
                elif len(hhmm)==3:
                    start_time = datetime.datetime(date[0], date[1], date[2], hhmm[0], hhmm[1], hhmm[2])
            elif line.startswith('#STATUS:done'):
                date = np.array(line.split('DATE:')[1].split(' #TIME:')[0].split('-')).astype(int)
                hhmm = np.array(line.split('DATE:')[1].split(' #TIME:')[1].split(' #MACHINE: ')[0].split(':')).astype(int)
                if len(hhmm)==2: #For old run files, where time did not include seconds.
                    end_time = datetime.datetime(date[0], date[1], date[2], hhmm[0], hhmm[1], 0)
                elif len(hhmm)==3:
                    end_time = datetime.datetime(date[0], date[1], date[2], hhmm[0], hhmm[1], hhmm[2])
    return (end_time - start_time).total_seconds()

def get_next_file_number(fileslist):
    '''Outputs number of next file to create among fileslist (i.e. the maximum number existing plus 1).'''
    if len(fileslist)==0:
        maxnum=0
    else:
        maxnum=1+max([int(file.split('.')[0].split('_')[1]) for file in fileslist])
    return maxnum

def get_results_from_pickle(RESULTSFOLDER, results_file_number):
    '''Load results from "RESULTSFOLDER", either from file number "results_file_number", or from latest results file.'''
    resultslist = [file for file in os.listdir(RESULTSFOLDER) if file[0:2] != '__' and file[-2:] == '.p']
    if len(resultslist)==0:
        print("No results file exists! Run check_status first (without -or 0).")
        exit()
    lastresults = max([int(file.split('.')[0].split('_')[1]) for file in resultslist])
    results_ind = lastresults if results_file_number == 0 else results_file_number
    print('Loading latest results (%s).' % (lastresults))
    with open(RESULTSFOLDER+'results_%.4i.p' %results_ind, "rb") as ifile:
        score_folds = pickle.load(ifile)
    return score_folds

def get_relevant_parameters(score_array,algorithm):
    '''Delete all parameters that are irrelevant for the selected algorithm.'''
    irrelevant_keys = []
    for par_i in range(len(score_array['parameters'])):
        key = list(score_array['parameters'])[par_i]
        if not (key.startswith(algorithm) or key.startswith("algorithm")):
            irrelevant_keys.append(key)
    for key in irrelevant_keys:
        del score_array['parameters'][key]
    return score_array

def evaluate_conditions(score_folds,conditions, algorithm):
    '''Change formatting of conditions.'''
    cond=np.ones(len(score_folds['run']),dtype=bool)*False #Mask full of Falses.
    alg_sel = (score_folds['parameters']['algorithm'] == algorithm) #Select relevant runs (irrelevants are flagged '?' and would cause trouble).
    cond[alg_sel]=True
    conditions_formatted=[]
    symbols=['<','>','==','!=','<=','>=']
    for cond_i in range(len(conditions)):
        condition=conditions[cond_i]
        for symbol in symbols:
            if symbol in condition:
                line=condition.split(symbol)
                if line[0].startswith(algorithm):
                    conditions_formatted.append("(score_folds['parameters']['%s'][alg_sel]%s %s )" % (line[0], symbol, line[1]))
    #Apply condition to relevant runs (irrelevant ones will keep being False).
    if len(conditions_formatted)>0:
        cond[alg_sel]=eval('&'.join(conditions_formatted))
    return cond

def get_default_pars(defpar):
    alg_folder="./common/algorithms/"
    parfiles=[file for file in os.listdir(alg_folder) if file.endswith("_pars.py")]
    for parfile in parfiles:
        algorithm=parfile.split("_pars.py")[0] #Name of algorithm.
        newparfile=importlib.import_module("common.algorithms.%s" %parfile.strip(".py"))
        pars=[par for par in dir(newparfile) if par.startswith(algorithm)]
        for par in pars:
            value=eval("newparfile.%s" %par)
            exec("defpar.%s=%s" %(par,value))