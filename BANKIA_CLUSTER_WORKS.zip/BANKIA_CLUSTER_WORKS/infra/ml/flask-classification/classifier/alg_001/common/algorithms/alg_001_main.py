###################################

#Description.

#Different algorithms (in fact they may be combinations of algorithms) are defined in this module as independent functions.

###################################

#Import necessary modules.

import time, os
import xgboost as xgb
import numpy as np
import common.functions as fun
from common.time_estimate import time_estimate
from sklearn import utils
from sklearn import metrics
from sklearn.feature_extraction.text import TfidfVectorizer
from common.nltk_stopwords_spanish import stopwords
import dill as pickle #This seems to be the only way to be able to save pickle of the model.

###################################

#Define functions.

def main(data,run,verbose=True,savemodel=False):
    '''Tf-idf followed by XGBoost.'''

    if verbose: print ('Running Tfidf+XGB.')
    data_train, data_cv=fun.load_fold(data,run)
    if verbose: print ('Fitting pipeline.')
    tfidf_model = TfidfVectorizer(stop_words=stopwords, tokenizer=lambda i: i, norm=run.alg_001_norm,
                                 ngram_range=run.alg_001_ngram_range, max_features=run.alg_001_max_features,
                                 max_df=run.alg_001_max_df, min_df=run.alg_001_min_df, lowercase=False)
    xgb_model=xgb.XGBClassifier(max_depth=run.alg_001_max_depth, learning_rate=run.alg_001_learning_rate,
                                n_estimators=run.alg_001_n_estimators, nthread=run.cm_nthread, seed=run.ds_random_seed)
    #pipeline = Pipeline([('vectorizer', tfidf_model), ('classifier', xgb_model)])
    #pipeline.fit(data_train['words'], data_train['labels'])
    #tfidf_model.fit(data_train['words'])
    #corpus_tf_idf = tfidf_model.transform(data_train['words'])
    corpus_tf_idf = tfidf_model.fit_transform(data_train['words'])
    xgb_model.fit(corpus_tf_idf, data_train['labels'])

    if savemodel:
        modelfolder=run.cm_DATA_FOLDER+'dataset_%.3i/models/%s/' %(run.dataset,run.__name__.split(".")[1])
        if not os.path.isdir(modelfolder): os.makedirs(modelfolder)
        if verbose: print("Saving models.")
        pickle.dump(tfidf_model, open(modelfolder+"tfidf.pickle", "wb"))
        pickle.dump(xgb_model, open(modelfolder + "xgb.pickle", "wb"))

    if verbose: print ('Obtaining classification score.')
    #y_pred=pipeline.predict(data_cv['words'])
    X_pred=tfidf_model.transform(data_cv['words'])
    if np.sum(X_pred[:,-1].todense())==0: # It may happen that last column of X_pred is made of zeros (for example, if the word corresponding to that column is not found in any of the documents in data_cv); when that happens, the sparse matrix X_pred is treated as if it had one column less, and xgb will crash. The solution is to simply replace any of those zeros by a small number (or simply zero).
        X_pred[0,-1]=0.
    y_pred=xgb_model.predict(X_pred)
    y_true=data_cv['labels']
    classes = np.unique(data_train['labels'])
    precision=metrics.precision_score(y_true, y_pred, average=None, labels=classes)
    recall=metrics.recall_score(y_true, y_pred, average=None, labels=classes)
    f1=metrics.f1_score(y_true, y_pred, average=None, labels=classes)
    confmat=metrics.confusion_matrix(y_true,y_pred,labels=classes)

    results = {'precision': precision, 'recall': recall, 'f1': f1, 'classes': classes, 'confusion_matrix':confmat}
    return results

