import json
import urllib3

# Load document.
basedir="C:/Users/pord/Documents/projects/b01/data/fake_documents/"
#ifilepath=basedir+"Clausula Suelo/1/clausula_suelo_1.txt"
#ifilepath=basedir+"Preferentes/1/preferentes_1.txt"
ifilepath=basedir+"Suscripción Acciones/1/acciones_1.txt"
#with open(ifilepath, 'r', encoding="utf8") as ifile:
with open(ifilepath, 'r') as ifile:
    text_j = ifile.read().replace('\n', ' ')

data={"doc":text_j}
encoded_body = json.dumps(data)
http = urllib3.PoolManager()
r = http.request('POST', 'http://localhost:5001/doc-classification/v1.0/', headers={'Content-Type': 'application/json'}, body=encoded_body)
#r = http.request('POST', 'http://aidoc-01:5001/doc-classification/v1.0/', headers={'Content-Type': 'application/json'}, body=encoded_body)
