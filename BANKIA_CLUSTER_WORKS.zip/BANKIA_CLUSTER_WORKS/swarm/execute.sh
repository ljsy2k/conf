#!/bin/sh
source /apps/nfs/arch/swarm/setenv.sh
env
make -f /apps/nfs/POC/jobs/scripts/Makefile $1