# OTHER CONSIDERTATIONS

## Managing Import / Export Docker Images

Inside ``/images`` we have some scripts for import or export docker images:

 - ``docker_images_io.sh`` -> can import/export while doing a compression inline 


We have tested : ``docker_images_io.sh`` You can run directly the script in command line

```
[root@aidoc-06 images_output]# ./docker_images_io.sh load-images 

```
takes images.db file and loads each image to local docker registry

```
[root@aidoc-06 images_output]# ./docker_images_io.sh save-images 
Saving aidoc/spark-worker:latest ...
Saving aidoc/spark-master:latest ...
Saving aidoc/spark-base:latest ...
Saving aidoc/hadoop-resourcemanager:latest ...
Saving aidoc/hadoop-nodemanager:latest ...
Saving aidoc/hadoop-namenode:latest ...
Saving aidoc/hadoop-datanode:latest ...
Saving aidoc/hadoop-base:latest ...
Saving aidoc/flask-entities-extraction:latest ...
Saving aidoc/flask-classification:latest ...
Saving elasticsearch_elasticsearch:latest ...
Saving flask-classification:latest ...
...
```

saves all images in ``salida`` folder

## OTHER MAKEFILE TASKS

- TASKS for START Docker STACKS 

use: 

```
make NAME_TASK
```

TASKS:

```
hadoop:
	docker stack deploy -c docker-compose-hadoop.yml hadoop

yarn:
	docker stack deploy -c docker-compose-yarn.yml yarn
	
spark:
	docker stack deploy -c docker-compose-spark.yml spark

addons:
	cd ${INFRA_PATH}/addons && $(MAKE) addons	
	
services:
	cd ${INFRA_PATH}/elasticsearch && $(MAKE) services

flask:
	cd ${INFRA_PATH}/ml && $(MAKE) flask
```
	
 - TASKS for STOP Docker STACKS

```
stop-hadoop:
	docker stack rm hadoop
	
stop-addons:
	docker stack rm addons	

stop-yarn:
	docker stack rm yarn	

stop-spark:
	docker stack rm spark

stop-services:
	docker stack rm services

stop-flask:
	docker service rm flask
```

- TASKS for START/STOP ALL

```
stop-all:
	docker stack rm yarn
	docker stack rm spark
	docker stack rm hadoop
	docker stack rm services
	docker stack rm flask
	docker stack rm addons

start-all:
	make hadoop
	make spark
	make services
	make flask
	make yarn
	make addons
```


## USERFUL Docker Commands

- docker service ls (list swarm cluster status) 

```
[root@aidoc-06 swarm]# docker service ls
ID            NAME                             MODE        REPLICAS  IMAGE
5ljxkcyh66ud  services_kibana                  replicated  1/1       docker.elastic.co/kibana/kibana:6.3.2
aeotxzyyx6mc  flask_flask-entities-extraction  replicated  1/1       aidoc/flask-entities-extraction:latest
anv3alc4vniu  services_logstash                replicated  1/1       docker.elastic.co/logstash/logstash:6.3.2
l8r4m6wsdhpl  hadoop_namenode                  replicated  1/1       aidoc/hadoop-namenode:latest
mjfbfrrkqeqb  hadoop_datanode                  global      2/2       aidoc/hadoop-datanode:latest
pt869tzmz3ql  flask_flask-classification       replicated  1/1       aidoc/flask-classification:latest
ss0zkyld890w  spark_spark-master               replicated  1/1       aidoc/spark-master:latest
xgw0zg06geio  services_elasticsearch           replicated  1/1       docker.elastic.co/elasticsearch/elasticsearch:6.3.2
xxh1kvhu2vyw  spark_spark-worker               global      2/2       aidoc/spark-worker:latest
z05cf5kgb8fn  traefik                          replicated  1/1       traefik:latest
[root@aidoc-06 swarm]#
```

- docker service ps ID (inspect docker service)

```
[root@aidoc-06 swarm]# docker service ps mjfbfrrkqeqb
ID            NAME                                       IMAGE                         NODE      DESIRED STATE  CURRENT STATE              ERROR  PORTS
astrk1axw8y5  hadoop_datanode.kx8wx5vp1vtj9l6y24yz63z5h  aidoc/hadoop-datanode:latest  aidoc-05  Running        Running about an hour ago
orj90ieatoic  hadoop_datanode.gp0qe5olxkh4utugmxsb0cpa0  aidoc/hadoop-datanode:latest  aidoc-06  Running        Running about an hour ago
You have mail in /var/spool/mail/root
[root@aidoc-06 swarm]#
```

- docker stack (status for the stack: we have hadoop, spark, services, flask...) 

```
[root@aidoc-06 swarm]# docker stack ls
NAME      SERVICES
flask     2
hadoop    2
spark     2
services  3
[root@aidoc-06 swarm]# docker stack ps spark
ID            NAME                                          IMAGE                      NODE      DESIRED STATE  CURRENT STATE              ERROR  PORTS
jxk47hncq3gw  spark_spark-worker.gp0qe5olxkh4utugmxsb0cpa0  aidoc/spark-worker:latest  aidoc-06  Running        Running about an hour ago
ue5v5nv6290t  spark_spark-worker.kx8wx5vp1vtj9l6y24yz63z5h  aidoc/spark-worker:latest  aidoc-05  Running        Running about an hour ago
wr2hv51f0il2  spark_spark-master.1                          aidoc/spark-master:latest  aidoc-05  Running        Running about an hour ago
```

