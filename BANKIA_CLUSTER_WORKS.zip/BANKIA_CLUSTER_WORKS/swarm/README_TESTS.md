# Testing Aidoc Deployment End to End

## Pre Requisites

to have Completed README installation Steps... 


## Actions without Planner or Scheduler

If we don't have orchrestations, we have to run each job step by step, but we need to complete some previous actions...

first, we need to upload the PDFs that we have to process to HDFS file system...

```
INPUT=${INPUT_EXTERNAL_PDF_PATH}/*.pdf
OUTPUT=${NFS_PATH}/data-input/pdf
HDFS=${CORE_CONF_fs_defaultFS}
hdfs dfs -copyFromLocal -f $INPUT $HDFS$OUTPUT
```

the ``INPUT_EXTERNAL_PDF_PATH`` is located in ``setenv.sh``

```
export INPUT_EXTERNAL_PDF_PATH="${NFS_PATH}/POC/input"

```

so we need to put the PDF files to this PATH and execute from Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

```
make upload
```

and after that we can test if we have PDFS in HDFS with ``listPdf.sh`` command in a ``bash`` container


```
root@9763e268b2fd:/nfs/POC/jobs# ./listPdf.sh
-rw-r--r--   3 root supergroup    7372593 2018-08-06 11:02 hdfs://namenode:8020/apps/data/input-pdf/Nulidad_Acciones_Final2.pdf
root@9763e268b2fd:/nfs/POC/jobs#
```

## PDF2PNG

From Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

```
make pdf2png	
```

that starts a docker container that runs pdf2png script with spark, hadoop and aidoc environment.

Can see also the running process in this URL (take ``aidoc-06.gft.com`` as HOST ANFITRION)

```
http://aidoc-06.gft.com:4040/jobs/
```

when process is completed, we can check in bash container the hdfs status about the pdf2png output

```
root@9763e268b2fd:/nfs/POC/jobs# ./listPng.sh
Found 7 items
-rw-r--r--   3 root supergroup    1841866 2018-08-06 11:04 hdfs://namenode:8020/apps/nfs/data-output/png/Nulidad_Acciones_Final2_0001.png
-rw-r--r--   3 root supergroup    1794764 2018-08-06 11:04 hdfs://namenode:8020/apps/nfs/data-output/png/Nulidad_Acciones_Final2_0002.png
-rw-r--r--   3 root supergroup    1820473 2018-08-06 11:04 hdfs://namenode:8020/apps/nfs/data-output/png/Nulidad_Acciones_Final2_0003.png
-rw-r--r--   3 root supergroup    1761963 2018-08-06 11:04 hdfs://namenode:8020/apps/nfs/data-output/png/Nulidad_Acciones_Final2_0004.png
-rw-r--r--   3 root supergroup    1734148 2018-08-06 11:04 hdfs://namenode:8020/apps/nfs/data-output/png/Nulidad_Acciones_Final2_0005.png
-rw-r--r--   3 root supergroup    1986652 2018-08-06 11:04 hdfs://namenode:8020/apps/nfs/data-output/png/Nulidad_Acciones_Final2_0006.png
-rw-r--r--   3 root supergroup    1875621 2018-08-06 11:04 hdfs://namenode:8020/apps/nfs/data-output/png/Nulidad_Acciones_Final2_0007.png
```

in web environment we can navigate to view the PNGS

```
http://aidoc-06.gft.com:50070/explorer.html#/apps/nfs/data-output/png
```


## PNG2TXT

in host container anfitrion, in path that has ``Makefile`` file we can run

```
make png2txt
```

that starts a docker container that runs pdf2png script with spark, hadoop and aidoc environment.

Can see also the running process in this URL (take ``aidoc-06.gft.com`` as HOST ANFITRION)

```
http://aidoc-06.gft.com:4041/jobs/
```


when process is completed, we can check in bash container the hdfs status about the png2txt output

```
root@0fb127780843:/apps/nfs/POC/jobs/scripts# hdfs dfs -ls -R hdfs://namenode:8020/${NFS_PATH}/data-output/txt-complete/
-rw-r--r--   3 root supergroup      18116 2018-08-21 10:05 hdfs://namenode:8020/apps/nfs/data-output/txt-complete/ClausulaSuelo1_images_new.txt

```

Or with HTTP

```
http://aidoc-06.gft.com:50070/explorer.html#/apps/nfs/data-output/txt-complete
```


## CLASSIFICATION

From Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

```
make classification
```

that starts a docker container that runs classification script with spark, hadoop and aidoc environment.

Can see also the running process in this URL

```
http://HOST_ANFITRION_URL:4042/jobs/
```

when process is completed, we can check in kibana the output indexes in ``procedures`` index (in ElasticSearch)

```
http://HOST_ANFITRION_URL:5601/app/kibana
```

```
for example :

{
  "_index": "procedures",
  "_type": "procedure",
  "_id": "365876b4-7883-4b33-8b58-fdcd268eeab1",
  "_score": 1,
  "_source": {
    "imagesPages": "8",
    "entities": "[{\"type\":\"abogado\",\"page\":\"1\",\"score\":\"0.976276\",\"value\":\"Pedro Ruiz Escobar\"},{\"type\":\"dni_otros_demandantes\",\"page\":\"1\",\"score\":\"0.626901\",\"value\":\"23663210P\"},{\"type\":\"dni_primer_demandante\",\"page\":\"1\",\"score\":\"0.966948\",\"value\":\"74885633A\"},{\"type\":\"juzgado\",\"page\":\"1\",\"score\":\"0.998645\",\"value\":\"Juzgado De Primera Instancia De Valencia\"},{\"type\":\"numero_procedimiento\",\"page\":\"1\",\"value\":\"0003321254\"},{\"type\":\"otros_demandantes\",\"page\":\"1\",\"score\":\"0.778814\",\"value\":\"Carla Guti�rrez Blanco\"},{\"type\":\"primer_demandante\",\"page\":\"1\",\"score\":\"0.98077\",\"value\":\"Carlos Santos V�zquez\"},{\"type\":\"procurador\",\"page\":\"1\",\"score\":\"0.8357\",\"value\":\"Julia Torres Dom�nguez\"}]",
    "pathPngPrefix": "/apps/nfs/data-output/png",
    "hocrSuffix": ".hocr",
    "identification": "365876b4-7883-4b33-8b58-fdcd268eeab1",
    "hocrPath": "hdfs://namenode:8020/apps/nfs/data-output/hocr/ClausulaSuelo1_images_new",
    "hocrPages": "8",
    "pathPdfPrefix": "/apps/nfs/data-output/pdf",
    "text": "<<<< TXT>>>>>>>>>>",
    "fileName": "ClausulaSuelo1_images_new",
    "pathHocrPrefix": "/apps/nfs/data-output/hocr",
    "date": "2018-08-21T12:51:39.093+02:00",
    "pdfPath": "hdfs://namenode:8020/apps/nfs/data-input/pdf/ClausulaSuelo1_images_new.pdf",
    "pathWebHdfs": "http://aidoc-06.gft.com:50075/webhdfs/v1",
    "classification": "NULIDAD COMPRA ACCIONES",
    "imagesPath": "hdfs://namenode:8020/apps/nfs/data-output/png/ClausulaSuelo1_images_new",
    "imagesSuffix": ".png"
  }
}
```

## MAINTENANCE SCRIPTS

We have some maintenance scripts that we can execute to clean inter steps and debug processes, 
Those scripts need to run in bash container:

```
make bash		

```

Next we need to go to ``/nfs/POC/jobs``:

- ``removePdf.sh`` -> removes pdfs stored in HDFS
- ``removePng.sh`` -> removes pngs stored in HDFS
- ``removeCSV.sh`` -> removes csv (files to process in classification job) stored in HDFS

and of course listing of last ones...