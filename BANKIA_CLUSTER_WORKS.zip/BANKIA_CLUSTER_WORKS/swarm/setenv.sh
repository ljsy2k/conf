#!/bin/sh
export HTTP_PROXY="proxy.cm.es:8080"
export HTTPS_PROXY="${HTTP_PROXY}"
export http_proxy="${HTTP_PROXY}"
export https_proxy="${HTTPS_PROXY}"
export NFS_PATH=/apps/nfs
export ARCH_PATH=${NFS_PATH}/arch/swarm
export INFRA_PATH=${NFS_PATH}/arch/infra
export JOBS_PATH=${NFS_PATH}/POC/jobs
export LOGS_PATH=${ARCH_PATH}/logs
export MODELS_PATH=${INFRA_PATH}/ml/models 
export NFS_SERVER=10.64.27.11
export TRAEFIK_HOSTNAME=aidoc06.gft.com
export HADOOP_ENV=${ARCH_PATH}/hadoop.env
export INPUT_EXTERNAL_PDF_PATH="${NFS_PATH}/POC/input"
export DOCKER_ENV_VOLUME="--volume nfs:${NFS_PATH} --volume ${LOGS_PATH}:/spark/logs --volume ${ARCH_PATH}/spark-conf/spark-defaults.conf:/spark/conf/spark-defaults.conf --volume ${ARCH_PATH}/spark-conf/log4j.properties:/spark/conf/log4j.properties"
export DOCKER_ENV_NETWORK="--network workbench"
export SPARK_NUM_EXECUTORS="--num-executors\ 8" 
export SPARK_EXECUTOR_CORES="--executor-cores\ 1"
export SPARK_EXECUTOR_MEMORY="--executor-memory\ 756m"
export SPARK_DEPLOY_MODE="--deploy-mode\ client"
#export SPARK_MASTER="--master\ yarn"
export SPARK_MASTER="--master\ spark://spark-master:7077"
export SPARK_PARAMS="${SPARK_MASTER}\ ${SPARK_DEPLOY_MODE}\ ${SPARK_NUM_EXECUTORS}\ ${SPARK_EXECUTOR_CORES}\ ${SPARK_EXECUTOR_MEMORY}"
export DOCKER_ENV_VARIABLES="-e NFS_PATH=${NFS_PATH} -e JOBS_PATH=${JOBS_PATH} -e SPARK_MASTER=${SPARK_MASTER} -e SPARK_PARAMS=${SPARK_PARAMS} --env-file ${HADOOP_ENV} "
export DOCKER_RUN_ENV="${DOCKER_ENV_NETWORK} ${DOCKER_ENV_VOLUME} ${DOCKER_ENV_VARIABLES}"
