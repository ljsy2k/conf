# SCALE NODES IN SPARK - Spark Swarm Cluster


NOTE:
 - for running JOBS we need to install Cluster and Run it (Explained in README.md)

## Previous

The Docker compose that controls SPARK is ``docker-compose-spark.yml`` and is as ...


```
version: '3'
services:
  spark-master:
    image: aidoc/spark-master:latest
    volumes:
      - ${LOGS_PATH}:/spark/logs
      - ${ARCH_PATH}/spark-conf/spark-defaults.conf:/spark/conf/spark-defaults.conf
      - ${ARCH_PATH}/spark-conf/log4j.properties:/spark/conf/log4j.properties
    environment:
     - NFS_PATH=${NFS_PATH} 
     - JOBS_PATH=${JOBS_PATH}
     - INIT_DAEMON_STEP=setup_spark
    networks:
      - workbench
    ports:
      - "8082:8080"
      - "7077:7077"      
    deploy:
      replicas: 1
      mode: replicated
      restart_policy:
        condition: on-failure
      labels:
        traefik.docker.network: workbench
        traefik.port: "8080"
    env_file:
      - ${ARCH_PATH}/hadoop.env
    

  spark-worker:
    image: aidoc/spark-worker:latest
    volumes:
      - ${LOGS_PATH}:/spark/logs
      - ${ARCH_PATH}/spark-conf/spark-defaults.conf:/spark/conf/spark-defaults.conf
      - ${ARCH_PATH}/spark-conf/log4j.properties:/spark/conf/log4j.properties
      
    environment:
     - NFS_PATH=${NFS_PATH} 
     - JOBS_PATH=${JOBS_PATH}
     - SPARK_MASTER=spark://spark-master:7077

    networks:
      - workbench
    ports:
      - "8081:8081"

    deploy:
      mode: global
      restart_policy:
        condition: on-failure
      labels:
        traefik.docker.network: workbench
        traefik.port: "8081"
    env_file:
      - ${ARCH_PATH}/hadoop.env

networks:
  workbench:
    external: true
```

if we go to "spark-worker" by default Docker deploys it in "global mode" (ON CONTAINER BY EACH SWARM NODE) so if we have 4 nodes in swarm, we will have 4 workers.

But if we change "global mode" with "replicated mode" and add "replicas" with some value (8, for instance) we can start SPARK with 8 workers in SWARM.

Of course, in runtime we can scale up and down with the command

```
docker-compose scale spark-worker=N
```

where N is the number of replicas we need and SWARM will fit those replicas across SWARM Cluster...