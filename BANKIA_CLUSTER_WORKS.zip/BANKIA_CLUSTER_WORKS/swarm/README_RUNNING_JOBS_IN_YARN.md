# RUNNING JOBS in YARN - Spark Swarm Cluster


NOTE:
 - for running JOBS we need to install Cluster and Run it (Explained in README.md)
 - need to read also "README_RUNNING_JOBS" 

## Enable YARN

We have included the YARN capabilities in Platform.

So we need to start YARN docker containers 

The runtime configuration is located in ``scripts/Makefile`` that is invoked from Master ``Makefile`` (for instance)

so the only thing is to do:

```
make yarn
```

And after some time we can check if YARN containers are up and running

```
[root@aidoc-06 swarm]# docker service ls
ID            NAME                             MODE        REPLICAS  IMAGE
31b8l5ip0t7n  flask_flask-entities-extraction  replicated  1/1       aidoc/flask-entities-extraction:latest
8x457iqnt5nr  flask_flask-classification       replicated  1/1       aidoc/flask-classification:latest
d2qftaswud5w  spark_spark-worker               replicated  4/4       aidoc/spark-worker:latest
fivk8xxhai55  hadoop_namenode                  replicated  1/1       aidoc/hadoop-namenode:latest
fm7i2ok1m93w  spark_spark-master               replicated  1/1       aidoc/spark-master:latest
fwdpx2gaska4  yarn_resourcemanager             replicated  1/1       aidoc/hadoop-resourcemanager:latest
heunrduqsed6  yarn_historyserver               replicated  1/1       aidoc/hadoop-historyserver:latest
izs195blvzbj  services_logstash                replicated  1/1       docker.elastic.co/logstash/logstash:6.3.2
jpu5257d9dy4  services_kibana                  replicated  1/1       docker.elastic.co/kibana/kibana:6.3.2
n0v3pvy42njo  yarn_nodemanager                 replicated  4/4       aidoc/hadoop-nodemanager:latest
omzm4b89q38r  hadoop_datanode                  global      2/2       aidoc/hadoop-datanode:latest
ydzgjh15c9z5  services_elasticsearch           replicated  1/1       docker.elastic.co/elasticsearch/elasticsearch:6.3.2
```

We view

fwdpx2gaska4  yarn_resourcemanager             replicated  1/1       aidoc/hadoop-resourcemanager:latest
heunrduqsed6  yarn_historyserver               replicated  1/1       aidoc/hadoop-historyserver:latest
n0v3pvy42njo  yarn_nodemanager                 replicated  4/4       aidoc/hadoop-nodemanager:latest


## Run Jobs in Yarn Mode

In general cases , the regular JOBS can Run directly in Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

- pdf2png: executes PDF2PNG JOB with the execution properties as a parameter (PYTHON)
- png2txt: executes PNG2TXT JOB with the execution properties as a parameter (PYTHON)
- classification: executes CLASSIFICATION JOB with the execution properties as a parameter (SCALA: need to compile with maven)

are launched by running 

```
make pdf2png

make png2txt

make classification	
```

internally the have 
- LAUNCHJOB
- ENVIRONMENT_PARAMETER

matched with: (PNG2TXT example)

```
${JOBS_PATH}/png2txt/launchJob.sh ${JOBS_PATH}/png2txt/spark.config.properties
```

the LAUNCHJOB.SH runs ``spark-submit`` and takes ``${JOBS_PATH}/png2txt/spark.config.properties`` as a first parameter

```
#!/bin/sh
/spark/bin/spark-submit ${SPARK_PARAMS} ${JOBS_PATH}/png2txt/ocr_images_spark.py $1
```

So the ``spark.config.properties`` has

```
[general]
spark-master=spark://spark-master:7077
deploy-mode=client

path-pdf-input=hdfs://namenode:8020/apps/nfs/data-input/pdf
path-images-input=hdfs://namenode:8020/apps/nfs/data-output/png
path-pdf-output=hdfs://namenode:8020/apps/nfs/data-output/pdf/

path-hocr-output=hdfs://namenode:8020/apps/nfs/data-output/hocr
path-ocr-output=hdfs://namenode:8020/apps/nfs/data-output/csv/
path-txt-pages=/apps/nfs/data-output/txt-pages/
path-txt-complete=/apps/nfs/data-output/txt-complete/

hdfs_ip=namenode
hdfs_port=50070
```

If we have enabled YARN Nodes, we can change the key "spark-master" in ``spark.config.properties`` 

```
spark-master=spark://spark-master:7077
```

with 

```
spark-master=yarn
```

If we run some JOB we can check if is running in this URL

```
http://aidoc-06.gft.com:8088/cluster/apps
```


## Change YARN Hadoop Properties 

in "hadoop.env" we have some YARN properties we can configure


```
YARN_CONF_yarn_log___aggregation___enable=true
YARN_CONF_yarn_log_server_url=http://historyserver:8188/applicationhistory/logs/
YARN_CONF_yarn_resourcemanager_recovery_enabled=true
YARN_CONF_yarn_resourcemanager_store_class=org.apache.hadoop.yarn.server.resourcemanager.recovery.FileSystemRMStateStore
YARN_CONF_yarn_resourcemanager_scheduler_class=org.apache.hadoop.yarn.server.resourcemanager.scheduler.capacity.CapacityScheduler
#YARN_CONF_yarn_scheduler_capacity_root_default_maximum___allocation___mb=8192
#YARN_CONF_yarn_scheduler_capacity_root_default_maximum___allocation___vcores=4
YARN_CONF_yarn_resourcemanager_fs_state___store_uri=/rmstate
YARN_CONF_yarn_resourcemanager_system___metrics___publisher_enabled=true
YARN_CONF_yarn_resourcemanager_hostname=resourcemanager
YARN_CONF_yarn_resourcemanager_address=resourcemanager:8032
YARN_CONF_yarn_resourcemanager_scheduler_address=resourcemanager:8030
YARN_CONF_yarn_resourcemanager_resource__tracker_address=resourcemanager:8031
YARN_CONF_yarn_timeline___service_enabled=true
YARN_CONF_yarn_timeline___service_generic___application___history_enabled=true
YARN_CONF_yarn_timeline___service_hostname=historyserver
YARN_CONF_mapreduce_map_output_compress=true
YARN_CONF_mapred_map_output_compress_codec=org.apache.hadoop.io.compress.SnappyCodec
YARN_CONF_yarn_nodemanager_resource_memory___mb=16384
YARN_CONF_yarn_nodemanager_resource_cpu___vcores=8
YARN_CONF_yarn_nodemanager_disk___health___checker_max___disk___utilization___per___disk___percentage=98.5
YARN_CONF_yarn_nodemanager_remote___app___log___dir=/app-logs
YARN_CONF_yarn_nodemanager_aux___services=mapreduce_shuffle

YARN_CONF_yarn_nodemanager_pmem___check___enabled=false
YARN_CONF_yarn_nodemanager_vmem___check___enabled=false

YARN_CONF_yarn_scheduler_maximum___allocation___mb=1536

```

So we can change those properties and RESTART YARN NODES 

```
make stop-yarn
make yarn
```

Of course we also can change runtime properties in "setenv.sh" (for instance)

```
export SPARK_NUM_EXECUTORS="--num-executors 4" 
export SPARK_EXECUTOR_CORES="--executor-cores 8"
export SPARK_PARAMS="${SPARK_NUM_EXECUTORS} ${SPARK_EXECUTOR_CORES}"
```
