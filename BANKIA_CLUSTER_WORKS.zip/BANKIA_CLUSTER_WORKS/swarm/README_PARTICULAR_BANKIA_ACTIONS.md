# Testing Aidoc Deployment In Bankia Arquitectura 1

## Pre Requisites

to have Completed README installation Steps... 

## Configure new NODE

### Proxy

Need to include Proxy in Bash system...

```
export HTTP_PROXY="proxy.cm.es:8080"
export HTTPS_PROXY="${HTTP_PROXY}"
export http_proxy="${HTTP_PROXY}"
export https_proxy="${HTTPS_PROXY}"
```

## Docker

### Docker Installation (If needed)

If no Docker installation we need to install It before...

```
sudo yum install -y git
sudo rpm --import "https://sks-keyservers.net/pks/lookup?op=get&search=0xee6d536cf7dc86e2d7d56f59a178ac6c6238f52e"
sudo yum-config-manager --add-repo https://packages.docker.com/1.13/yum/repo/main/centos/7
sudo yum install  docker-engine.x86_64 1.13.1.cs9-1.el7.centos packages.docker.com_1.13_yum_repo_main_centos_7 
```

After that , need to config as a Service (No needed , but useful??)

```
sudo vi /usr/lib/systemd/system/docker.service
ExecStart=/usr/bin/docker daemon -g /apps/docker

sudo systemctl enable docker.service
sudo systemctl start docker.service
sudo usermod -a -G docker $USER 
```

### Docker Configuration Proxy

 Add proxy info in ``/etc/sysconfig/docker`` file:

```
HTTP_PROXY="proxy.cm.es:8080"
HTTPS_PROXY="${HTTP_PROXY}"
http_proxy="${HTTP_PROXY}"
https_proxy="${HTTPS_PROXY}"
```
Comment this line...

```
BLOCK_REGISTRY='--block-registry docker.io'
```
Save and Restart docker service:

```
service docker restart
```

### Docker Compose installation

we have included docker compose Linux with Arch x64 in package, so we can do it with online or execute it manually...

```
sudo curl -L https://github.com/docker/compose/releases/download/1.21.2/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose 
```

### Docker Import Images to local node

generally we need to import Aidoc Docker images to new Node.

So locate ``docker_images.sh`` (usually in HOME and in ImageIO or Image subfolder) and ``images`` and ``images.db`` file for executing this command

```
docker_images.sh load-images
```

So the script will locate the internal database file and process the uploading of each image to the local Docker Registry
After that, with ``docker images`` we can check if we did it correctly

```

-bash-4.2$ sudo docker images
REPOSITORY                        TAG                 IMAGE ID            CREATED             SIZE
aidoc/spark-worker                latest              fe01b93f0d1c        17 hours ago        1.82 GB
aidoc/spark-master                latest              8e254aa87166        17 hours ago        1.82 GB
aidoc/spark-base                  latest              011d80c3d31f        17 hours ago        1.82 GB
aidoc/hadoop-resourcemanager      latest              5592a343c0d8        17 hours ago        1.44 GB
aidoc/hadoop-nodemanager          latest              84dfd1a89a37        17 hours ago        1.44 GB
aidoc/hadoop-namenode             latest              c16575097de1        17 hours ago        1.44 GB
aidoc/hadoop-datanode             latest              c605717e5709        17 hours ago        1.44 GB
aidoc/hadoop-base                 latest              eae9117c97cf        17 hours ago        1.44 GB
aidoc/flask-entities-extraction   latest              5c5bf4a89563        2 days ago          3.74 GB
aidoc/flask-classification        latest              ad035169aeff        2 days ago          4.18 GB
debian                            8                   79f4bda91989        3 weeks ago         127 MB
```

## IPs and Machines Config

### NFS Client and Config

In client node/s only install the next packages and mount the holder folder

```
sudo yum install -y nfs-utils

mkdir -p /apps/nfs
mount SERVER_NFS_IP:/apps/nfs /apps/nfs
```

where SERVER_NFS_IP is the IP Adress of the NFS Server

### Maven (If needed)

Locate ``settings.xml`` by executing ``mvn -X`` and set the proxy node...

```
 <proxies>
    <proxy>
      <id>myproxy</id>
      <active>true</active>
      <protocol>http</protocol>
      <host>proxy.cm.es</host>
      <port>8080</port>
      <username>USER</username>
      <password>PASSWORD</password>
      <nonProxyHosts>*.google.com|ibiblio.org</nonProxyHosts>
    </proxy>
  </proxies>
```

where ``USER`` and ``PASSWORD`` must be configured...

### Makefile changes

Locate Makefile and change

```
nfs:
	docker volume create --driver local --opt type=nfs --opt o=addr=172.22.4.166,rw  --opt device=:/apps/nfs nfs
```

the ``o=addr=....,rw`` with the SERVER_NFS_IP