# INSTALLING Hadoop and Spark in Swarm cluster for Aidoc Deployment


## Putting project files in HOME folder

we have placed the HOME folder that holds the project files (usually ``/apps/nfs/arch/swarm``)

```
[root@aidoc-06 swarm]# ls -l
total 112
-rwxrwxrwx  1 lest lest  1336 Aug 20 14:00 docker-compose-hadoop.yml
-rwxrwxrwx  1 lest lest  1402 Aug 20 14:05 docker-compose-spark.yml
-rwxrwxrwx  1 lest lest  1533 Aug 20 14:00 docker-compose-yarn.yml
-rwxrwxrwx  1 lest lest  2502 Aug 16 15:32 hadoop.env
drwxrwxrwx 11 lest lest  4096 Aug 20 13:38 images
drwxrwxrwx  2 root root  4096 Aug 21 08:45 logs
-rwxrwxrwx  1 lest lest  2062 Aug 20 13:28 Makefile
-rwxrwxrwx  1 lest lest   780 Aug  1 13:26 nfs.txt
-rwxrwxrwx  1 lest lest  4510 Aug  9 10:00 README_BANKIA_ACTIONS.md
-rwxrwxrwx  1 lest lest 18601 Aug 13 15:38 README.md
-rwxrwxrwx  1 lest lest  5311 Aug  9 09:42 README_TESTS.md
-rwxrwxrwx  1 lest lest   930 Aug 20 14:41 setenv.sh
drwxrwxrwx  2 lest lest  4096 Aug 21 12:26 spark-conf
-rwxrwxrwx  1 lest lest 33207 Aug 14 13:18 tutorial.txt


```

The ``jobs`` folder will be stored later in NFS path because we need the jobs shared across network nodes and machines... (will be explained in README_RUNNING_JOBS)...
 

## Installing Docker Compose and Some Requisites

The Prerequisite is to have some Docker Programs ready to run

- Docker Engine

```
sudo yum install -y git
sudo rpm --import "https://sks-keyservers.net/pks/lookup?op=get&search=0xee6d536cf7dc86e2d7d56f59a178ac6c6238f52e"
sudo yum-config-manager --add-repo https://packages.docker.com/1.13/yum/repo/main/centos/7
sudo yum install  docker-engine.x86_64 1.13.1.cs9-1.el7.centos packages.docker.com_1.13_yum_repo_main_centos_7 
```

- Docker Compose

``` 
sudo curl -L https://github.com/docker/compose/releases/download/1.21.2/docker-compose-$(uname -s)-$(uname -m) -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose 
```

- Docker Service

```
sudo vi /usr/lib/systemd/system/docker.service
ExecStart=/usr/bin/docker daemon -g /apps/docker

sudo systemctl enable docker.service
sudo systemctl start docker.service
sudo usermod -a -G docker $USER 
```

## Creating Docker Images

Docker images are distributed across `images` folder.
There are some flavours depending on each infraestructure

- Hadoop (HDFS environment)
- Yarn (Yarn environment)
- Spark (Apache Spark Runtime Environment)
- Services (ElasticSearch and Kibana Runtime Environment) (in other project)
- Others (Flask Rest Services for Classification) (in other project)

We can create all by running the ``.sh`` scripts
- ``buildImages.sh`` -> that create ALL images
- ``buildHadoop.sh`` -> that create only Hadoop images
- ``buildSpark.sh`` -> that create only Spark images
- ``removeImages.sh`` -> that remove ALL images

## Minimun Docker Images

If we execute ```docker images``` we can obtain al aidoc images. We need at least HADOOP, SPARK, FLASK (in other project), and SERVICES (ELK in other project)

```
[root@aidoc-06 images]# docker images
REPOSITORY                            TAG                 IMAGE ID            CREATED             SIZE
aidoc/spark-worker                    latest              cb245b8e8359        About an hour ago   1.69 GB
aidoc/spark-master                    latest              c11655456408        About an hour ago   1.69 GB
aidoc/spark-base                      latest              e8531d960a0d        About an hour ago   1.69 GB
aidoc/zeppelin                        latest              caa9571734df        4 days ago          2.77 GB
aidoc/livy                            latest              f57ee80fa606        4 days ago          1.74 GB
aidoc/flask-entities-extraction       latest              317872e0270d        4 days ago          3.71 GB
aidoc/flask-classification            latest              6772748e9144        4 days ago          4.16 GB
aidoc/hadoop-resourcemanager          latest              1b00fb2aa36c        4 days ago          1.43 GB
aidoc/hadoop-nodemanager              latest              0d15a1d9ca7f        4 days ago          1.43 GB
aidoc/hadoop-namenode                 latest              b398efec27eb        4 days ago          1.43 GB
aidoc/hadoop-historyserver            latest              f253f745b705        4 days ago          1.43 GB
aidoc/hadoop-datanode                 latest              e0e5ea79455a        4 days ago          1.43 GB
aidoc/hadoop-base                     latest              fdde689b9fdb        4 days ago          1.43 GB
aidoc/hue                             latest              7ce8823a224b        4 days ago          2.2 GB
```

The minimal set of images is:

```
[root@aidoc-06 images]# docker images
REPOSITORY                            TAG                 IMAGE ID            CREATED             SIZE
aidoc/spark-worker                    latest              cb245b8e8359        About an hour ago   1.69 GB
aidoc/spark-master                    latest              c11655456408        About an hour ago   1.69 GB
aidoc/spark-base                      latest              e8531d960a0d        About an hour ago   1.69 GB
aidoc/flask-entities-extraction       latest              317872e0270d        4 days ago          3.71 GB
aidoc/flask-classification            latest              6772748e9144        4 days ago          4.16 GB
aidoc/hadoop-namenode                 latest              b398efec27eb        4 days ago          1.43 GB
aidoc/hadoop-datanode                 latest              e0e5ea79455a        4 days ago          1.43 GB
aidoc/hadoop-base                     latest              fdde689b9fdb        4 days ago          1.43 GB
```

and the ELK (usually 6.2.3)

```
docker.elastic.co/logstash/logstash   <none>              6e15c0212069        4 weeks ago         700 MB
docker.elastic.co/kibana/kibana       <none>              92815bd544b7        4 weeks ago         771 MB
docker.elastic.co/elasticsearch/elasticsearch   <none>              96dd1575de0f        4 weeks ago         826 MB
```


## Setup NFS for sharing Job Scripts and Files Purpose


We can install NFS environment for share Aidoc Scripts and Jobs by running some steps:

- Choose a Master (Server) Node that will host the files
- Check the IP Adress for configuring Clients Afterwards

In Server node we must install (RH or Centos Environment)

```
sudo yum install -y nfs-utils
systemctl enable nfs-server.service
systemctl start nfs-server.service


mkdir /apps/nfs
chown nfsnobody:nfsnobody /apps/nfs
chmod 755 /apps/nfs
```

After that we need to edit ``/etc/exports`` file

```
[root@aidoc-06 swarm]# vi /etc/exports
/apps/nfs       XXX.XXX.XXX.0/24(rw,sync,no_subtree_check,no_root_squash)
```

OR
 
```
/apps/nfs       *(rw,sync,no_subtree_check,no_root_squash)
```

Save file.
And Finally

```
exportfs -a
systemctl restart nfs-server.service
```

In client node/s only install the next packages and mount the holder folder

```
sudo yum install -y nfs-utils


mkdir -p /apps/nfs
mount SERVER_IP:/apps/nfs /apps/nfs
```

where SERVER_IP is the IP Adress of the NFS Server


## Initial Swarm Setup 

- In Master Node (choose one)

```
docker swarm init
```

We obtain an output message like 

```
 docker swarm join \
    --token SWMTKN-1-3yu8e3zi6spkz2daxdh1snwgxp9kkjuhm3g9iyj6h1la9vs3pd-674c83cn2ftn79v4ifsim95bj \
    172.22.4.166:2377
```

So we need to execute the output script in Slaves Nodes to add Nodes to Swarm Cluster

## Environment Variables

In Home Folder we have ``setenv.sh`` script that declares the Environment variables that we need to propagate to All Docker, Jobs and Scripts

```
#!/bin/sh
export NFS_PATH=/apps/nfs
export ARCH_PATH=${NFS_PATH}/arch/swarm
export INFRA_PATH=${NFS_PATH}/arch/infra
export JOBS_PATH=${NFS_PATH}/POC/jobs
export LOGS_PATH=${ARCH_PATH}/logs
export NFS_SERVER=172.22.4.166
export TRAEFIK_HOSTNAME=aidoc06.gft.com
export HADOOP_ENV=${ARCH_PATH}/hadoop.env
export DOCKER_ENV_VOLUME="--volume nfs:${NFS_PATH} --volume ${ARCH_PATH}/spark-conf/spark-defaults.conf:/spark/conf/spark-defaults.conf --volume ${ARCH_PATH}/spark-conf/log4j.properties:/spark/conf/log4j.properties"
export DOCKER_ENV_VARIABLES="-e NFS_PATH=${NFS_PATH} -e JOBS_PATH=${JOBS_PATH} --env-file ${HADOOP_ENV}" 
export DOCKER_ENV_NETWORK="--network workbench"
export DOCKER_RUN_ENV="${DOCKER_ENV_NETWORK} ${DOCKER_ENV_VOLUME} ${DOCKER_ENV_VARIABLES}"
export SPARK_NUM_EXECUTORS="--num-executors 4" 
export SPARK_EXECUTOR_CORES="--executor-cores 4"
export SPARK_PARAMS="${SPARK_NUM_EXECUTORS} ${SPARK_EXECUTOR_CORES}"

```

NOTE: In case that the script is not working, we need to convert to unix format by running ``dos2unix``

```
[root@aidoc-06 swarm]# dos2unix setenv.sh
```

if we look at the script, we need the BASE PATH as NFS_PATH (that is /apps/nfs)

The Main Folders we need are:

- ARCH_PATH : where we will place the HOME "bankia_lawsuits_architecture/docker-swarm-arch" 
- INFRA_PATH : where we will place the FOLDER "bankia_lawsuits_infraestructure"
- JOBS_PATH : where we will place the FOLDER "bankia_lawsuits_pipeline_jobs" 


Those Folders are corresponding to each GIT Project :
 - https://git.gft.com/exponential-banking/cognitive-banking/bankia_lawsuits_architecture
 - https://git.gft.com/exponential-banking/cognitive-banking/bankia_lawsuits_infrastructure
 - https://git.gft.com/exponential-banking/cognitive-banking/bankia_lawsuits_pipeline_jobs

After that, the last important Environment Variable is NFS_SERVER that will contain the IP of the NFS_SERVER that were configured before

```
export NFS_SERVER=172.22.4.166
```

## Initial setup

In Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located) we have the following options (firstly)

```
network:
        docker network create -d overlay --attachable workbench

nfs:
        docker volume create --driver local --opt type=nfs --opt o=addr=${NFS_SERVER},rw  --opt device=:${NFS_PATH} nfs

hdfs:
        cd ${JOBS_PATH}/scripts && $(MAKE) hdfs

remove-hdfs-volume:
        docker volume rm hadoop_namenode hadoop_datanode hadoop_historyserver
        
```

So we can execute in order:  

- Create an Overlay network:

```
make network
```

- Create the NFS Sharing Volume (we need first the NFS Server IP):

```
make nfs
```

- And then create HDFS PATHS (IF HADOOP Containers are running)

```
make hdfs
```

## Deploying HDFS (without YARN)

In Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

- To deploy HDFS run:

```
make hadoop
```

- And then create HDFS PATHS

```
make hdfs
```

## Deploying Spark

Create ``logs`` folder in ``ARCH_PATH`` (usually : /apps/nfs/arch/swarm/logs)

Deploy Spark:

```
make spark
```

## Create Images for ElasticSearch, Kibana and other Services (FLASK)

First, if we don't have the Images for those Services (ELK and FLASK) we need to build them...

 Go to ``INFRA_PATH`` (environment variable , should be (``/apps/nfs/arch/infra``)
 
 if we list it:
  
``` 
 [root@aidoc-05 infra]# ls -l
total 16
drwxr-xr-x 5 lest lest 4096 Aug 20 13:39 addons
drwxrwxrwx 6 lest lest 4096 Aug 14 11:51 airflow
drwxrwxrwx 2 lest lest 4096 Aug 14 16:52 elasticsearch
drwxrwxrwx 4 lest lest 4096 Aug 14 11:51 ml
``` 
```
we can go to ``ml`` and create Flask Images (running ``createImages.sh``) 
and  ``elasticsearch`` is deploying on the fly by running directly the official images...

## Deploying ElasticSearch, Kibana and other Services

In Home Folder (``ARCH_PATH``) (where Master Makefile is located)

- Deploy the Services (ElasticSearch and Kibana):

```
make services
```

- Deploy the Classification (Flask Classification Services):

```
make flask
```

## Check Cluster is Up and Running

We can check the status of global cluster by running

```
ID            NAME                             MODE        REPLICAS  IMAGE
5ljxkcyh66ud  services_kibana                  replicated  1/1       docker.elastic.co/kibana/kibana:6.3.2
aeotxzyyx6mc  flask_flask-entities-extraction  replicated  1/1       aidoc/flask-entities-extraction:latest
anv3alc4vniu  services_logstash                replicated  1/1       docker.elastic.co/logstash/logstash:6.3.2
l8r4m6wsdhpl  hadoop_namenode                  replicated  1/1       aidoc/hadoop-namenode:latest
mjfbfrrkqeqb  hadoop_datanode                  global      2/2       aidoc/hadoop-datanode:latest
pt869tzmz3ql  flask_flask-classification       replicated  1/1       aidoc/flask-classification:latest
ss0zkyld890w  spark_spark-master               replicated  1/1       aidoc/spark-master:latest
xgw0zg06geio  services_elasticsearch           replicated  1/1       docker.elastic.co/elasticsearch/elasticsearch:6.3.2
xxh1kvhu2vyw  spark_spark-worker               global      2/2       aidoc/spark-worker:latest
z05cf5kgb8fn  traefik                          replicated  1/1       traefik:latest

```

In this configuration, we have 2 swarm nodes, (1 master and 1 slave) and 2 types of replicated nodes (spark-worker and hadoop-datanode).

And other things for instance ElasticSearch, Kibana and so on (namenode, and spark master)

Of course, we can check by ``docker ps`` (and find the flask containers)

NODE 06

```
[root@aidoc-06 swarm]# docker ps
CONTAINER ID        IMAGE                                                                                                         COMMAND                  CREATED             STATUS                    PORTS                                                                             NAMES
4357e6ddabab        docker.elastic.co/kibana/kibana@sha256:7ae0616a5f5ddfb0f93ae4cc94038afd2d4e45fa7858fd39c506c8c682ee71f0       "/usr/local/bin/ki..."   14 minutes ago      Up 14 minutes             5601/tcp                                                                          services_kibana.1.swnlou2yutg8moxy4s0ji8sdw
f20f6ac61adf        docker.elastic.co/logstash/logstash@sha256:838e9038388e3932f23ac9c014b14f4a1093cd8e5ede7b7e0ece98e517d44fb2   "/usr/local/bin/do..."   14 minutes ago      Up 14 minutes (healthy)   5044/tcp, 9600/tcp                                                                services_logstash.1.7ckjk33h2yjxi4bctvuboitwa
a16b95a5a57c        aidoc/spark-worker:latest                                                                                     "entrypoint.sh /bi..."   14 minutes ago      Up 14 minutes (healthy)   4040/tcp, 6066/tcp, 7001-7006/tcp, 7077/tcp, 7337/tcp, 8080-8081/tcp, 18080/tcp   spark_spark-worker.gp0qe5olxkh4utugmxsb0cpa0.jxk47hncq3gw13maees7nfcpx
99ee150df235        aidoc/hadoop-datanode:latest                                                                                  "/entrypoint.sh /r..."   14 minutes ago      Up 14 minutes (healthy)   50075/tcp                                                                         hadoop_datanode.gp0qe5olxkh4utugmxsb0cpa0.orj90ieatoicfh1h9k310p7fj
857b965bcd95        aidoc/flask-entities-extraction:latest                                                                        "python flask_serv..."   15 minutes ago      Up 15 minutes                                                                                               flask_flask-entities-extraction.1.myuzzaqstfm2dycxpcud9wvk8
5384a94decc4        traefik@sha256:eabb39016917bd43e738fb8bada87be076d4553b5617037922b187c0a656f4a4                               "/traefik --docker..."   7 days ago          Up 7 days                 80/tcp                                                                            traefik.1.rqm1xwyckjhqwkmzj7jrlyn23
50f1f33c3fb1        portainer/portainer                                                                                           "/portainer"             11 days ago         Up 11 days                0.0.0.0:9000->9000/tcp                                                            priceless_hugle

```

NODE 05

```
[root@aidoc-05 infra]# docker ps
CONTAINER ID        IMAGE                                                                                                                   COMMAND                  CREATED             STATUS                    PORTS                                                                             NAMES
21413af3ed8e        docker.elastic.co/elasticsearch/elasticsearch@sha256:8f06aecf7227dbc67ee62d8d05db680f8a29d0296ecd74c60d21f1fe665e04b0   "/usr/local/bin/do..."   14 minutes ago      Up 14 minutes             9200/tcp, 9300/tcp                                                                services_elasticsearch.1.3a98l4qr5s730ambh8fm5p5wu
8fa66a81a7f7        aidoc/spark-worker:latest                                                                                               "entrypoint.sh /bi..."   14 minutes ago      Up 14 minutes (healthy)   4040/tcp, 6066/tcp, 7001-7006/tcp, 7077/tcp, 7337/tcp, 8080-8081/tcp, 18080/tcp   spark_spark-worker.kx8wx5vp1vtj9l6y24yz63z5h.ue5v5nv6290td6mneqzuonyvf
532e66d6045e        aidoc/spark-master:latest                                                                                               "entrypoint.sh /bi..."   14 minutes ago      Up 14 minutes (healthy)   4040/tcp, 6066/tcp, 7001-7006/tcp, 7077/tcp, 7337/tcp, 8080-8081/tcp, 18080/tcp   spark_spark-master.1.wr2hv51f0il2p9g6el1lb3qls
6c971b576b67        aidoc/hadoop-datanode:latest                                                                                            "/entrypoint.sh /r..."   14 minutes ago      Up 14 minutes (healthy)   50075/tcp                                                                         hadoop_datanode.kx8wx5vp1vtj9l6y24yz63z5h.astrk1axw8y5m0002bjhvf4wv
719f8670740f        aidoc/hadoop-namenode:latest                                                                                            "/entrypoint.sh /r..."   14 minutes ago      Up 14 minutes (healthy)   50070/tcp                                                                         hadoop_namenode.1.tgtbqfzz98egsqvmesz5o8jg3
e8b3ef35567f        aidoc/flask-classification:latest                                                                                       "python flask_serv..."   15 minutes ago      Up 15 minutes                                                                                               flask_flask-classification.1.ntmcmkl1fihquv7harqp4862k

```

## Spark Configuration Aspects

the Spark Infraestructure configuration is located in 2 places:

- ``ARCH_PATH/spark-conf/spark-defaults.conf``
- ``ARCH_PATH/setenv.sh`` (as a combination of environment variables)

for the ``spark-conf/spark-defaults.conf`` we have the spark-defaults CONFIGURATION variables and in  ``setenv.sh`` we have he runtime EXECUTORS AND CORES for the  ``spark-submit`` command

```
export SPARK_NUM_EXECUTORS="--num-executors 4" 
export SPARK_EXECUTOR_CORES="--executor-cores 4"
export SPARK_PARAMS="${SPARK_NUM_EXECUTORS} ${SPARK_EXECUTOR_CORES}"
```

we can modify those variables according to the CLUSTER CONFIGURATIONS

