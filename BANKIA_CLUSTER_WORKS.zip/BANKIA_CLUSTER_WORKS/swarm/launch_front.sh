docker run -d -p 19082:9080 -e "SPRING_PROFILES_ACTIVE=int" --name demands-service com.bankia.lawsuits.microservices/demands-service
docker run -d -p 19081:9080 -e "SPRING_PROFILES_ACTIVE=int" --name categories-service com.bankia.lawsuits.microservices/categories-service
docker run -d -p 19080:9080 -e "SPRING_PROFILES_ACTIVE=int" --name entities-service com.bankia.lawsuits.microservices/entities-service
docker run -d -p 19083:9080 -e "SPRING_PROFILES_ACTIVE=int" --name documents-service com.bankia.lawsuits.microservices/documents-service


