# INSTALLING Hadoop and Spark in Swarm cluster for Aidoc Deployment (ASSUME README.MD done)


# PRE REQUISITES

- All Nodes with Docker installed (also Docker Compose)
- NFS INSTALLED IN ALL NODES (no need to update)
- All Images imported to All nodes 


# FAST Installation

For only change parameters 

## 0 NFS : Architecture, Infraestructure, Jobs

1) create Main NFS PATH, Architecture, Infraestructure and Jobs Folders

- NFS_PATH=/apps/nfs
- ARCH_PATH=/apps/nfs/arch/swarm
- INFRA_PATH=/apps/nfs/arch/infra
- JOBS_PATH=/apps/nfs/POC/jobs
- LOGS_PATH=/apps/nfs/arch/swarm/logs

2) copy each content from Git Projects to each folder path


- ARCH_PATH : where we will place the HOME "bankia_lawsuits_architecture/docker-swarm-arch" 
- INFRA_PATH : where we will place the FOLDER "bankia_lawsuits_infraestructure"
- JOBS_PATH : where we will place the FOLDER "bankia_lawsuits_pipeline_jobs" 


Those Folders are corresponding to each GIT Project :
 - https://git.gft.com/exponential-banking/cognitive-banking/bankia_lawsuits_architecture
 - https://git.gft.com/exponential-banking/cognitive-banking/bankia_lawsuits_infrastructure
 - https://git.gft.com/exponential-banking/cognitive-banking/bankia_lawsuits_pipeline_jobs 

## 1 ENVIRONMENT VARIABLES

Edit In Home Folder (apps/nfs/arch/swarm) ``setenv.sh`` the NFS Server and the number of nodes in cluster

```
#!/bin/sh
export NFS_SERVER=NFS_SERVER_IP 
export SPARK_NUM_EXECUTORS="--num-executors 4" 
export SPARK_EXECUTOR_CORES="--executor-cores 4"

```

After that , execute the envionment to declare all EXPORTS

```
. ./setenv.sh
```

check that envs are created



## 2 Initial Swarm Setup 

- In Master Node (choose one)

```
docker swarm init
```

We obtain an output message like 

```
 docker swarm join \
    --token SWMTKN-1-3yu8e3zi6spkz2daxdh1snwgxp9kkjuhm3g9iyj6h1la9vs3pd-674c83cn2ftn79v4ifsim95bj \
    172.22.4.166:2377
```

So we need to execute the output script in Slaves Nodes to add Nodes to Swarm Cluster


## 3 Initial setup

In Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located) we have the following options (firstly)

- for Network

```
make network
```

- Create the NFS Sharing Volume (we need first the NFS Server IP):

```
make nfs
```

## 4 Deploying HDFS

In Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

- To deploy HDFS run:

```
make hadoop 
```

- And then create HDFS PATHS

```
make hdfs
```

if ERROR or not expected results, do the following

```
make remove-hdfs-volume
```

MUST be RUN in ALL NODES

AND again 

```
make hadoop 
```


## 5 Deploying Spark

In Home Folder (``ARCH_PATH``) (where Master ``Makefile`` is located)

Deploy Spark:

```
make spark
```

(IF spark nodes are giving errors, try to create the logs folder

Create ``logs`` folder in ``ARCH_PATH`` (usually : /apps/nfs/arch/swarm/logs)

## 6 Deploy FLASK and ELK

In Home Folder (``ARCH_PATH``) (where Master Makefile is located)

- Deploy the Services (ElasticSearch and Kibana):

```
make services
```

- Deploy the Classification (Flask Classification Services):

```
make flask
```

## 7 Check Cluster is Up and Running

We can check the status of global cluster by running

```
ID            NAME                             MODE        REPLICAS  IMAGE
5ljxkcyh66ud  services_kibana                  replicated  1/1       docker.elastic.co/kibana/kibana:6.3.2
aeotxzyyx6mc  flask_flask-entities-extraction  replicated  1/1       aidoc/flask-entities-extraction:latest
anv3alc4vniu  services_logstash                replicated  1/1       docker.elastic.co/logstash/logstash:6.3.2
l8r4m6wsdhpl  hadoop_namenode                  replicated  1/1       aidoc/hadoop-namenode:latest
mjfbfrrkqeqb  hadoop_datanode                  global      2/2       aidoc/hadoop-datanode:latest
pt869tzmz3ql  flask_flask-classification       replicated  1/1       aidoc/flask-classification:latest
ss0zkyld890w  spark_spark-master               replicated  1/1       aidoc/spark-master:latest
xgw0zg06geio  services_elasticsearch           replicated  1/1       docker.elastic.co/elasticsearch/elasticsearch:6.3.2
xxh1kvhu2vyw  spark_spark-worker               global      2/2       aidoc/spark-worker:latest
z05cf5kgb8fn  traefik                          replicated  1/1       traefik:latest

```


## 8 Classfication Job Properties

 - Go to ``JOBS_PATH=/apps/nfs/POC/jobs`` and locate ``classification`` 

- edit ``spark.config.properties`` and put the master node of the cluster in MASTER_NODE 

```
path-web-hdfs=http://MASTER_NODE:50075/webhdfs/v1
```