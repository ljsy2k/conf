docker build -t aidoc/spark-master .
