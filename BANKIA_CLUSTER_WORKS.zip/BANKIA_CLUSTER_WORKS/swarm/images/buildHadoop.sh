cd hadoop-base
./build.sh
cd ..
cd hadoop-datanode  
./build.sh
cd ..
cd hadoop-namenode
./build.sh
cd ..
