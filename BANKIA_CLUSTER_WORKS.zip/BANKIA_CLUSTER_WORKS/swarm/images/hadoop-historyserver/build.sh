docker build -t aidoc/hadoop-historyserver .
