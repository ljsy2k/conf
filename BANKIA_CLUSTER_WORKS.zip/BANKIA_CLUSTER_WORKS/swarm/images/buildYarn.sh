cd hadoop-nodemanager
./build.sh
cd ..
cd hadoop-historyserver  
./build.sh
cd ..
cd hadoop-resourcemanager
./build.sh
cd ..