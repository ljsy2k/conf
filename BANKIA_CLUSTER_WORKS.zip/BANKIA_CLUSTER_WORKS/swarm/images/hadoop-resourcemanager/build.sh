docker build -t aidoc/hadoop-resourcemanager .
