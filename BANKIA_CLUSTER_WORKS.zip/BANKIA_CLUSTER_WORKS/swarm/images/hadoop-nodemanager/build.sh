docker build -t aidoc/hadoop-nodemanager .
