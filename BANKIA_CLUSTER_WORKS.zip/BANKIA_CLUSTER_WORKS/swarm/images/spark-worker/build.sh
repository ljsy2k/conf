docker build -t aidoc/spark-worker .
