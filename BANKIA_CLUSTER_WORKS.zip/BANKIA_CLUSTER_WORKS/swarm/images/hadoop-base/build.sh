docker build -t aidoc/hadoop-base-experimental .
