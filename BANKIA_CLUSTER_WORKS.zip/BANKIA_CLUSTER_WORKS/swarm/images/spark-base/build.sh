docker build -t aidoc/spark-base .
