docker build -t aidoc/hadoop-datanode .
