cd spark-base
./build.sh
cd ..
cd spark-master  
./build.sh
cd ..
cd spark-worker
./build.sh
cd ..
