docker build -t aidoc/hadoop-namenode .
